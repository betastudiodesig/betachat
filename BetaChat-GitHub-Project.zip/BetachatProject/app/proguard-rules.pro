# Keep cryptographic key and Room entities safe from accidental minification changes.
# Release minification is disabled in this starter project until a release build is tested.
