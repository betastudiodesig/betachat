package com.betastudio.betachat.network

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.betastudio.betachat.MainActivity
import com.betastudio.betachat.R

object NotificationHelper {
    private const val CHANNEL_ID = "betachat_messages"

    fun show(context: Context, title: String, body: String, notificationId: Int) {
        runCatching {
            val manager = context.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Mensajes ẞetaChat", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = PendingIntent.getActivity(
                context, notificationId,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_betachat)
                .setContentTitle(title.take(80))
                .setContentText(body.take(180))
                .setStyle(NotificationCompat.BigTextStyle().bigText(body.take(800)))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            manager.notify(notificationId, notification)
        }
    }
}
