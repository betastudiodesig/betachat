package com.betastudio.betachat.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.ParcelUuid
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import com.betastudio.betachat.MainActivity
import com.betastudio.betachat.R
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.security.IdentityCrypto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.nio.ByteBuffer
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.CRC32

/**
 * BLE GATT transport and bounded store-and-forward mesh prototype.
 * Messages are signed and encrypted end-to-end by IdentityCrypto. Relays see only the envelope.
 */
class MeshBleService : Service() {
    companion object {
        const val ACTION_START = "com.betastudio.betachat.action.START_MESH"
        const val ACTION_SEND = "com.betastudio.betachat.action.SEND_MESSAGE"
        const val ACTION_PROFILE = "com.betastudio.betachat.action.PROFILE_CHANGED"
        const val ACTION_REQUEST = "com.betastudio.betachat.action.CHAT_REQUEST"
        const val ACTION_CONTROL = "com.betastudio.betachat.action.CHAT_CONTROL"
        const val ACTION_SEND_MEDIA = "com.betastudio.betachat.action.SEND_MEDIA"
        const val ACTION_PEER = "com.betastudio.betachat.action.PEER_FOUND"
        const val ACTION_INCOMING_REQUEST = "com.betastudio.betachat.action.INCOMING_REQUEST"
        const val ACTION_PEER_ACCEPTED = "com.betastudio.betachat.action.PEER_ACCEPTED"
        const val ACTION_PEER_REJECTED = "com.betastudio.betachat.action.PEER_REJECTED"
        const val EXTRA_PEER_ID = "peer_id"
        const val EXTRA_PEER_NAME = "peer_name"
        const val EXTRA_PEER_PHONE = "peer_phone"
        const val EXTRA_PEER_BIO = "peer_bio"
        const val EXTRA_PEER_PHOTO = "peer_photo"
        const val EXTRA_PEER_STATUS = "peer_status"
        const val EXTRA_PEER_STATUS_AT = "peer_status_at"
        const val EXTRA_REQUEST_KIND = "request_kind"
        private const val CHANNEL_ID = "betachat_mesh"
        private const val NOTIFICATION_ID = 2026
        private val SERVICE_UUID: UUID = UUID.fromString("e7d2a170-6b9a-4bd2-a247-7ca8b3c0f001")
        private val RX_UUID: UUID = UUID.fromString("e7d2a171-6b9a-4bd2-a247-7ca8b3c0f001")
        private const val MAX_LINKS = 5
        private const val MAX_PACKET_BYTES = 3000
        private const val MAX_TTL = 6
        private const val MAX_MEDIA_BYTES = 128 * 1024
        private const val MEDIA_CHUNK_BYTES = 1400
        private const val STATUS_TTL_MS = 24L * 60L * 60L * 1000L
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var identity: IdentityCrypto
    private val prefs by lazy { getSharedPreferences("betachat_profile", Context.MODE_PRIVATE) }
    private val peerKeys = ConcurrentHashMap<String, String>()
    private val peerNames = ConcurrentHashMap<String, String>()
    private val clients = ConcurrentHashMap<String, BluetoothGatt>()
    private val clientRx = ConcurrentHashMap<String, BluetoothGattCharacteristic>()
    private val mtuByAddress = ConcurrentHashMap<String, Int>()
    private val writeQueues = ConcurrentHashMap<String, ArrayDeque<ByteArray>>()
    private val writesInFlight = ConcurrentHashMap.newKeySet<String>()
    private val seenPacketIds = ConcurrentHashMap.newKeySet<String>()
    private val lastMessageAttemptAt = ConcurrentHashMap<String, Long>()
    private val assemblies = ConcurrentHashMap<String, FrameAssembly>()
    private val mediaAssemblies = ConcurrentHashMap<String, MediaAssembly>()
    private val pendingMedia = ArrayDeque<PendingMedia>()
    private val pendingPackets = ArrayDeque<String>()
    private val pendingMessages = ArrayDeque<PendingMessage>()
    private val lock = Any()
    private var gattServer: BluetoothGattServer? = null
    private var initializationFailed = false
    private var advertiser: android.bluetooth.le.BluetoothLeAdvertiser? = null
    private var scanning = false
    private var advertising = false
    private var bluetoothAdapter: BluetoothAdapter? = null
    private val connectingAddresses = ConcurrentHashMap.newKeySet<String>()
    private val heartbeatHandler = Handler(mainLooper)
    private var heartbeatScheduled = false
    private val heartbeat = object : Runnable {
        override fun run() {
            if (scanning && advertising) runCatching { broadcastOwnHello() }
            heartbeatHandler.postDelayed(this, 20_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            identity = IdentityCrypto(this)
            val manager = getSystemService(BluetoothManager::class.java)
            bluetoothAdapter = manager?.adapter
            loadSavedPeers()
            createNotificationChannel()
        } catch (error: Exception) {
            Log.e("BetaChat/BLE", "Service initialization failed", error)
            initializationFailed = true
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (initializationFailed) return START_NOT_STICKY
        return try {
            dispatchStartCommand(intent)
        } catch (error: Exception) {
            Log.e("BetaChat/BLE", "Service start command failed (action=${intent?.action ?: "null"})", error)
            stopSelf(startId)
            START_NOT_STICKY
        }
    }

    private fun dispatchStartCommand(intent: Intent?): Int {
        when (intent?.action) {
            ACTION_SEND_MEDIA -> {
                if (gattServer == null) startTransport()
                val to = intent.getStringExtra("to").orEmpty()
                val name = intent.getStringExtra("name").orEmpty()
                val nickname = intent.getStringExtra("nickname").orEmpty()
                val transferId = intent.getStringExtra("transfer_id").orEmpty()
                val fileName = intent.getStringExtra("file_name").orEmpty().ifBlank { "archivo" }
                val mime = intent.getStringExtra("mime_type").orEmpty().ifBlank { "application/octet-stream" }
                val bytes = intent.getByteArrayExtra("media_bytes")
                if (to.isNotBlank() && transferId.isNotBlank() && bytes != null && bytes.isNotEmpty() && bytes.size <= MAX_MEDIA_BYTES) {
                    sendMedia(to, name, nickname.ifBlank { currentNickname() }, transferId, fileName, mime, bytes)
                } else {
                    ioScope.launch { if (transferId.isNotBlank()) ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(transferId, "failed") }
                }
            }
            ACTION_CONTROL -> {
                if (gattServer == null) startTransport()
                val to = intent.getStringExtra("to").orEmpty()
                val kind = intent.getStringExtra("control_kind").orEmpty()
                val reference = intent.getStringExtra("reference").orEmpty()
                if (to.isNotBlank()) sendControl(to, kind, reference)
            }
            ACTION_SEND -> {
                if (gattServer == null) startTransport()
                val to = intent.getStringExtra("to").orEmpty()
                val name = intent.getStringExtra("name").orEmpty()
                val body = intent.getStringExtra("body").orEmpty()
                val messageId = intent.getStringExtra("message_id").orEmpty().ifBlank { UUID.randomUUID().toString() }
                if (to.isNotBlank() && body.isNotBlank()) sendChat(to, name, body, messageId)
            }
            ACTION_PROFILE -> {
                startTransport()
                broadcastOwnHello()
            }
            ACTION_REQUEST -> {
                if (gattServer == null) startTransport()
                val to = intent.getStringExtra("to").orEmpty()
                val kind = intent.getStringExtra(EXTRA_REQUEST_KIND).orEmpty()
                if (to.isNotBlank()) {
                    val requestPrefs = getSharedPreferences("betachat_requests", MODE_PRIVATE)
                    val acceptedPrefs = getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE)
                    if (kind == "CHAT_REQUEST") requestPrefs.edit().putLong("outgoing:$to", System.currentTimeMillis()).apply()
                    if (kind == "REQUEST_ACCEPT") acceptedPrefs.edit().putBoolean(to, true).apply()
                    if (kind == "REQUEST_REJECT") acceptedPrefs.edit().remove(to).apply()
                    if (kind == "REQUEST_ACCEPT" || kind == "REQUEST_REJECT") requestPrefs.edit().remove("incoming:$to").apply()
                    sendControl(to, kind, intent.getStringExtra("reference").orEmpty())
                }
            }
            else -> startTransport()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopTransport()
        ioScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        super.onDestroy()
    }

    private fun startTransport() {
        // A foreground-service restriction or missing runtime permission must not crash the app.
        // Some Android versions throw while promoting the service, before BLE setup begins.
        try {
            startForegroundCompat()
        } catch (error: Exception) {
            Log.e("BetaChat/BLE", "Could not promote BLE service to foreground", error)
            stopSelf()
            return
        }
        try {
            val adapter = bluetoothAdapter ?: return
            if (!adapter.isEnabled) return
            val manager = getSystemService(BluetoothManager::class.java) ?: return
            if (gattServer == null) {
                gattServer = manager.openGattServer(this, serverCallback)
                val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
                val rx = BluetoothGattCharacteristic(
                    RX_UUID,
                    BluetoothGattCharacteristic.PROPERTY_WRITE,
                    BluetoothGattCharacteristic.PERMISSION_WRITE
                )
                service.addCharacteristic(rx)
                val accepted = gattServer?.addService(service) ?: false
                if (!accepted) startAdvertisingAndScan()
            } else {
                startAdvertisingAndScan()
            }
        } catch (_: SecurityException) {
            // Runtime permissions may have been revoked while the service was alive.
        } catch (_: IllegalStateException) {
            // BLE advertising is unavailable on some devices or when Bluetooth is restarting.
        }
    }

    private fun startAdvertisingAndScan() {
        scheduleHeartbeat()
        try {
            val adapter = bluetoothAdapter ?: return
            advertiser = adapter.bluetoothLeAdvertiser
            if (advertiser != null && !advertising) {
                val settings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build()
                val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(SERVICE_UUID)).build()
                advertiser?.startAdvertising(settings, data, advertiseCallback)
            }
            startScan()
        } catch (_: SecurityException) {
        } catch (_: IllegalStateException) {
        }
    }

    private fun startScan() {
        try {
            val scanner = bluetoothAdapter?.bluetoothLeScanner ?: return
            if (scanning) return
            val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0)
                .build()
            scanner.startScan(listOf(filter), settings, scanCallback)
            scanning = true
        } catch (_: SecurityException) {
        } catch (_: IllegalStateException) {
        }
    }

    private fun scheduleHeartbeat() {
        if (!heartbeatScheduled) {
            heartbeatScheduled = true
            heartbeatHandler.postDelayed(heartbeat, 20_000L)
        }
    }

    private fun stopTransport() {
        heartbeatHandler.removeCallbacks(heartbeat)
        heartbeatScheduled = false
        try { if (scanning) bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { if (advertising) advertiser?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        scanning = false
        advertising = false
        clients.values.forEach { runCatching { it.disconnect(); it.close() } }
        clients.clear()
        clientRx.clear()
        try { gattServer?.close() } catch (_: Exception) {}
        gattServer = null
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) { advertising = true }
        override fun onStartFailure(errorCode: Int) { advertising = false }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val address = runCatching { device.address }.getOrNull() ?: return
            if (clients.containsKey(address) || connectingAddresses.contains(address) || clients.size + connectingAddresses.size >= MAX_LINKS) return
            connectingAddresses.add(address)
            try {
                val gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    device.connectGatt(this@MeshBleService, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                } else {
                    @Suppress("DEPRECATION")
                    device.connectGatt(this@MeshBleService, false, gattCallback)
                }
                if (gatt == null) connectingAddresses.remove(address)
            } catch (_: SecurityException) {
                connectingAddresses.remove(address)
            }
        }

        override fun onScanFailed(errorCode: Int) { scanning = false }
    }

    private val serverCallback = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(status: Int, service: BluetoothGattService?) {
            if (status == BluetoothGatt.GATT_SUCCESS && service?.uuid == SERVICE_UUID) startAdvertisingAndScan()
        }

        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                // Incoming server-side links are managed by Android. The same peer may also
                // establish an outgoing central link; only outgoing links can be used for writes.
                runCatching { gattServer?.cancelConnection(device) }
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            val ok = characteristic.uuid == RX_UUID && !preparedWrite && offset == 0 && acceptFrame(device.address, value)
            if (responseNeeded) {
                try {
                    gattServer?.sendResponse(
                        device,
                        requestId,
                        if (ok) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE,
                        0,
                        null
                    )
                } catch (_: SecurityException) {}
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                clients[address] = gatt
                connectingAddresses.remove(address)
                mtuByAddress[address] = 23
                try { gatt.discoverServices() } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                clients.remove(address)
                clientRx.remove(address)
                mtuByAddress.remove(address)
                connectingAddresses.remove(address)
                writesInFlight.remove(address)
                writeQueues.remove(address)
                runCatching { gatt.close() }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) return
            val address = runCatching { gatt.device.address }.getOrDefault("")
            val characteristic = gatt.getService(SERVICE_UUID)?.getCharacteristic(RX_UUID) ?: return
            clientRx[address] = characteristic
            try { gatt.requestMtu(247) } catch (_: SecurityException) {}
            sendPacketToGatt(gatt, createHello().toString())
            flushPending()
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            if (status == BluetoothGatt.GATT_SUCCESS) mtuByAddress[address] = mtu.coerceIn(23, 517)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            synchronized(lock) { writeQueues[address]?.pollFirst() }
            writesInFlight.remove(address)
            writeNext(gatt)
        }
    }

    private fun sendChat(toId: String, peerName: String, body: String, messageId: String) {
        val now = System.currentTimeMillis()
        val previousAttempt = lastMessageAttemptAt[messageId] ?: 0L
        // Retries are throttled, while the message itself remains in Room until delivery is acknowledged.
        if (previousAttempt > 0L && now - previousAttempt < 30_000L) return
        lastMessageAttemptAt[messageId] = now
        val accepted = getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).getBoolean(toId, false)
        if (!accepted) {
            ioScope.launch { ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(messageId, "failed") }
            sendBroadcast(Intent(ACTION_PEER_REJECTED).setPackage(packageName)
                .putExtra(EXTRA_PEER_ID, toId).putExtra(EXTRA_PEER_NAME, peerName)
                .putExtra("reason", "Primero debes aceptar la solicitud de chat."))
            return
        }
        val pub = peerKeys[toId] ?: getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString(toId, null)
        if (pub.isNullOrBlank()) {
            synchronized(lock) {
                if (pendingMessages.size < 50) pendingMessages.addLast(PendingMessage(toId, peerName, body.take(1000), messageId))
            }
            broadcastOwnHello()
            return
        }
        runCatching {
            val packet = identity.createEncryptedChat(toId, pub, currentNickname(), body.take(1000), messageId)
            rememberPacket(packet.optString("id"))
            sendPacketToNetwork(packet.toString(), null)
        }.onFailure {
            // The UI has already saved the local message; transport errors are retried on reconnect.
        }
    }

    private fun createHello(): JSONObject {
        val phone = prefs.getString("phone", "").orEmpty()
        val phonePublic = prefs.getBoolean("phone_public", false)
        val bio = prefs.getString("bio", "").orEmpty()
        val rawStatus = prefs.getString("status_text", "").orEmpty().trim().take(180)
        val storedAt = prefs.getLong("status_at", 0L)
        val validStatus = rawStatus.takeIf { it.isNotBlank() && storedAt > 0L && System.currentTimeMillis() - storedAt in 0..STATUS_TTL_MS }.orEmpty()
        return identity.helloPacket(currentNickname(), phone, phonePublic, bio, ownAvatarBase64(), validStatus, if (validStatus.isNotBlank()) storedAt else 0L)
    }

    private fun ownAvatarBase64(): String = runCatching {
        val stored = prefs.getString("photo_uri", "").orEmpty()
        if (stored.isBlank()) return ""
        val file = File(android.net.Uri.parse(stored).path ?: return "")
        if (!file.isFile) return ""
        val original = BitmapFactory.decodeFile(file.absolutePath) ?: return ""
        val small = Bitmap.createScaledBitmap(original, 64, 64, true)
        val bytes = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 38, bytes)
        if (small !== original) small.recycle()
        if (!original.isRecycled) original.recycle()
        val encoded = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
        encoded.takeIf { it.length <= 1500 }.orEmpty()
    }.getOrDefault("")

    private fun savePeerAvatar(peerId: String, encoded: String): String {
        if (encoded.isBlank() || encoded.length > 1500) return ""
        return runCatching {
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            if (bytes.size !in 1..1125) return ""
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth !in 1..128 || bounds.outHeight !in 1..128) return ""
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }) ?: return ""
            val directory = File(filesDir, "peer_profiles").apply { mkdirs() }
            val file = File(directory, "$peerId.jpg")
            file.writeBytes(bytes)
            bitmap.recycle()
            android.net.Uri.fromFile(file).toString()
        }.getOrDefault("")
    }

    private fun broadcastOwnHello() {
        val hello = createHello()
        rememberPacket(hello.optString("id"))
        sendPacketToNetwork(hello.toString(), null)
    }

    private fun sendControl(toId: String, kind: String, reference: String = "") {
        if (kind !in setOf("CHAT_REQUEST", "REQUEST_ACCEPT", "REQUEST_REJECT", "MESSAGE_ACK", "MESSAGE_READ")) return
        val pub = peerKeys[toId] ?: getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString(toId, null)
        if (pub.isNullOrBlank()) {
            broadcastOwnHello()
            return
        }
        runCatching {
            val packet = identity.createControlPacket(kind, toId, currentNickname(), reference)
            rememberPacket(packet.optString("id"))
            if (kind == "REQUEST_ACCEPT") {
                getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).edit().putBoolean(toId, true).apply()
            } else if (kind == "REQUEST_REJECT") {
                getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).edit().remove(toId).apply()
            }
            sendPacketToNetwork(packet.toString(), null)
        }
    }

    private fun acceptFrame(address: String, frame: ByteArray): Boolean {
        if (frame.size < 9 || frame[0] != 0x42.toByte() || frame[1] != 0x43.toByte()) return false
        val buffer = ByteBuffer.wrap(frame, 2, 6)
        val token = buffer.int
        val index = buffer.get().toInt() and 0xff
        val total = buffer.get().toInt() and 0xff
        if (total < 1 || index >= total) return false
        val key = "$address:$token"
        val payload = frame.copyOfRange(8, frame.size)
        var assembled: ByteArray? = null
        synchronized(lock) {
            var entry = assemblies[key]
            if (entry == null || entry.total != total) {
                entry = FrameAssembly(total)
                assemblies[key] = entry
            }
            if (entry.parts[index] == null) {
                entry.parts[index] = payload
                entry.count++
            }
            if (entry.count == entry.total) {
                val output = java.io.ByteArrayOutputStream()
                entry.parts.forEach { part -> output.write(part ?: ByteArray(0)) }
                assembled = output.toByteArray()
                assemblies.remove(key)
            }
            if (assemblies.size > 100) assemblies.clear()
        }
        assembled?.let { bytes ->
            if (bytes.size <= MAX_PACKET_BYTES) runCatching { processPacket(JSONObject(String(bytes, Charsets.UTF_8)), address) }
        }
        return true
    }

    private fun processPacket(packet: JSONObject, incomingAddress: String) {
        val packetId = packet.optString("id")
        val kind = packet.optString("kind")
        val from = packet.optString("from")
        if (packetId.isBlank() || from.isBlank() || from == identity.deviceId) return

        when (kind) {
            "HELLO" -> {
                if (!identity.isValidHello(packet) || !rememberPacket(packetId)) return
                val pub = packet.getString("pub")
                val name = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
                val phone = packet.optString("phone", "").take(24)
                val bio = packet.optString("bio", "").take(160)
                val status = packet.optString("status", "").take(180)
                val statusAt = packet.optLong("statusAt", 0L)
                val freshStatus = status.takeIf { it.isNotBlank() && statusAt > 0L && System.currentTimeMillis() - statusAt in 0..STATUS_TTL_MS }.orEmpty()
                val photoPath = savePeerAvatar(from, packet.optString("avatar", ""))
                peerKeys[from] = pub
                peerNames[from] = name
                val peerPrefs = getSharedPreferences("betachat_peer_keys", MODE_PRIVATE)
                val editor = peerPrefs.edit().putString(from, pub)
                if (phone.isNotBlank()) editor.putString("phone:$from", phone) else editor.remove("phone:$from")
                editor.putString("bio:$from", bio).putString("status:$from", freshStatus)
                    .putLong("statusAt:$from", if (freshStatus.isNotBlank()) statusAt else 0L).apply()
                getSharedPreferences("betachat_peer_names", MODE_PRIVATE).edit().putString(from, name).apply()
                sendBroadcast(Intent(ACTION_PEER).setPackage(packageName)
                    .putExtra(EXTRA_PEER_ID, from).putExtra(EXTRA_PEER_NAME, name)
                    .putExtra(EXTRA_PEER_PHONE, phone).putExtra(EXTRA_PEER_BIO, bio)
                    .putExtra(EXTRA_PEER_PHOTO, photoPath).putExtra(EXTRA_PEER_STATUS, freshStatus)
                    .putExtra(EXTRA_PEER_STATUS_AT, if (freshStatus.isNotBlank()) statusAt else 0L))
                ioScope.launch {
                    ChatDatabase.get(this@MeshBleService).chatDao().updateRecipientPhone(from, phone.takeIf { it.isNotBlank() })
                }
                processPendingMessages(from)
                processPendingMedia(from)
                // Discovery is local: do not relay HELLO packets or expose a public phone number
                // beyond the Bluetooth neighborhood where the owner chose to publish it.
            }
            "CHAT_REQUEST", "REQUEST_ACCEPT", "REQUEST_REJECT", "MESSAGE_ACK", "MESSAGE_READ" -> {
                if (!identity.verifyControlPacket(packet) || !rememberPacket(packetId)) return
                if (packet.optString("to") == identity.deviceId) {
                    val name = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
                    when (kind) {
                        "CHAT_REQUEST" -> {
                            val phone = getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString("phone:$from", "").orEmpty()
                            val requestJson = JSONObject().put("name", name).put("phone", phone).toString()
                            getSharedPreferences("betachat_requests", MODE_PRIVATE).edit().putString("incoming:$from", requestJson).apply()
                            NotificationHelper.show(this@MeshBleService, "Solicitud de chat", "$name quiere iniciar una conversación.", from.hashCode())
                            sendBroadcast(Intent(ACTION_INCOMING_REQUEST).setPackage(packageName)
                                .putExtra(EXTRA_PEER_ID, from).putExtra(EXTRA_PEER_NAME, name)
                                .putExtra(EXTRA_PEER_PHONE, phone))
                        }
                        "REQUEST_ACCEPT" -> {
                            val requestPrefs = getSharedPreferences("betachat_requests", MODE_PRIVATE)
                            val pendingOutgoing = requestPrefs.contains("outgoing:$from")
                            if (pendingOutgoing) {
                                getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).edit().putBoolean(from, true).apply()
                                requestPrefs.edit().remove("outgoing:$from").apply()
                                sendBroadcast(Intent(ACTION_PEER_ACCEPTED).setPackage(packageName)
                                    .putExtra(EXTRA_PEER_ID, from).putExtra(EXTRA_PEER_NAME, name))
                            }
                        }
                        "REQUEST_REJECT" -> {
                            val requestPrefs = getSharedPreferences("betachat_requests", MODE_PRIVATE)
                            if (requestPrefs.contains("outgoing:$from")) {
                                requestPrefs.edit().remove("outgoing:$from").apply()
                                getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).edit().remove(from).apply()
                                sendBroadcast(Intent(ACTION_PEER_REJECTED).setPackage(packageName)
                                    .putExtra(EXTRA_PEER_ID, from).putExtra(EXTRA_PEER_NAME, name))
                            }
                        }
                        "MESSAGE_ACK", "MESSAGE_READ" -> {
                            val messageId = packet.optString("ref")
                            if (messageId.isNotBlank()) ioScope.launch {
                                val dao = ChatDatabase.get(this@MeshBleService).chatDao()
                                val outgoing = dao.findMessage(messageId)
                                // Receipt must be signed by the actual recipient of this message.
                                if (outgoing != null && outgoing.outgoing && outgoing.chatId == from) {
                                    dao.updateMessageStatus(messageId, if (kind == "MESSAGE_READ") "read" else "delivered")
                                    lastMessageAttemptAt.remove(messageId)
                                }
                            }
                        }
                    }
                }
                relay(packet, incomingAddress)
            }
            "CHAT" -> {
                if (!identity.verifyPacket(packet)) return
                val recipient = packet.optString("to")
                if (!rememberPacket(packetId)) {
                    // A sender retries unacknowledged messages. Re-acknowledge duplicates that were
                    // already persisted, so a lost receipt cannot leave the sender stuck on one tick.
                    if (recipient == identity.deviceId && getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).getBoolean(from, false)) {
                        ioScope.launch {
                            val existing = ChatDatabase.get(this@MeshBleService).chatDao().findMessage(packetId)
                            if (existing != null && !existing.outgoing) {
                                sendControl(from, if (existing.status == "read") "MESSAGE_READ" else "MESSAGE_ACK", packetId)
                            }
                        }
                    }
                    return
                }
                if (recipient == identity.deviceId) {
                    if (!getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).getBoolean(from, false)) return
                    val text = runCatching { identity.decryptChat(packet) }.getOrNull() ?: return
                    val senderName = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
                    persistIncoming(from, senderName, text, packetId)
                }
                relay(packet, incomingAddress)
            }
            "MEDIA" -> {
                if (!identity.verifyMediaPacket(packet) || !rememberPacket(packetId)) return
                if (packet.optString("to") == identity.deviceId) {
                    if (!getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).getBoolean(from, false)) return
                    val chunk = runCatching { identity.decryptMediaChunk(packet) }.getOrNull() ?: return
                    persistIncomingMediaChunk(packet, chunk)
                }
                relay(packet, incomingAddress)
            }
        }
    }

    private fun relay(packet: JSONObject, incomingAddress: String) {
        if (packet.optString("kind") == "HELLO") return
        // ttl is a mutable remaining-hop counter; maxTtl is signed by the sender and is immutable.
        val maxTtl = packet.optInt("maxTtl", 0).coerceIn(0, MAX_TTL)
        val ttl = packet.optInt("ttl", 0).coerceAtMost(maxTtl)
        if (ttl <= 0 || maxTtl <= 0) return
        packet.put("ttl", ttl - 1)
        sendPacketToNetwork(packet.toString(), incomingAddress)
    }

    private fun persistIncoming(from: String, name: String, text: String, messageId: String) {
        ioScope.launch {
            val dao = ChatDatabase.get(this@MeshBleService).chatDao()
            val existing = dao.findMessage(messageId)
            if (existing != null) {
                if (!existing.outgoing) sendControl(from, if (existing.status == "read") "MESSAGE_READ" else "MESSAGE_ACK", messageId)
                return@launch
            }
            val current = System.currentTimeMillis()
            val chat = dao.findChat(from)
            if (chat != null) {
                dao.upsertChat(chat.copy(title = name, lastMessage = text, updatedAt = current, unreadCount = chat.unreadCount + 1))
            } else {
                dao.upsertChat(ChatEntity(from, from, name, text, current, 1, "MESH", null))
            }
            dao.insertMessage(MessageEntity(messageId, from, from, text, current, false, "received", "MESH"))
            NotificationHelper.show(this@MeshBleService, "Mensaje de $name", text, messageId.hashCode())
            sendControl(from, "MESSAGE_ACK", messageId)
        }
    }

    private fun sendMedia(toId: String, peerName: String, nickname: String, transferId: String, fileName: String, mimeType: String, bytes: ByteArray) {
        if (!getSharedPreferences("betachat_accepted_peers", MODE_PRIVATE).getBoolean(toId, false)) {
            ioScope.launch { ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(transferId, "failed") }
            return
        }
        val pub = peerKeys[toId] ?: getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString(toId, null)
        if (pub.isNullOrBlank()) {
            synchronized(lock) {
                if (pendingMedia.size < 3) pendingMedia.addLast(PendingMedia(toId, peerName, nickname, transferId, fileName, mimeType, bytes.copyOf()))
                else ioScope.launch { ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(transferId, "failed") }
            }
            broadcastOwnHello()
            return
        }
        sendMediaPackets(toId, nickname, transferId, fileName, mimeType, bytes, pub)
    }

    private fun sendMediaPackets(toId: String, nickname: String, transferId: String, fileName: String, mimeType: String, bytes: ByteArray, publicKey: String) {
        if (bytes.size > MAX_MEDIA_BYTES) {
            ioScope.launch { ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(transferId, "failed") }
            return
        }
        runCatching {
            val total = (bytes.size + MEDIA_CHUNK_BYTES - 1) / MEDIA_CHUNK_BYTES
            require(total in 1..100)
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
            for (index in 0 until total) {
                val start = index * MEDIA_CHUNK_BYTES
                val chunk = bytes.copyOfRange(start, minOf(bytes.size, start + MEDIA_CHUNK_BYTES))
                val packet = identity.createEncryptedMediaChunk(toId, publicKey, nickname, transferId, fileName, mimeType, index, total, digest, chunk)
                rememberPacket(packet.optString("id"))
                sendPacketToNetwork(packet.toString(), null)
            }
        }.onFailure {
            Log.e("BetaChat/BLE", "Media packet creation failed", it)
            ioScope.launch { ChatDatabase.get(this@MeshBleService).chatDao().updateMessageStatus(transferId, "failed") }
        }
    }

    private fun processPendingMedia(targetId: String) {
        val ready = mutableListOf<PendingMedia>()
        synchronized(lock) {
            val iterator = pendingMedia.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item.toId == targetId) { ready.add(item); iterator.remove() }
            }
        }
        val pub = peerKeys[targetId] ?: getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString(targetId, null) ?: return
        ready.forEach { sendMediaPackets(it.toId, it.nickname, it.transferId, it.fileName, it.mimeType, it.bytes, pub) }
    }

    private fun persistIncomingMediaChunk(packet: JSONObject, bytes: ByteArray) {
        if (bytes.isEmpty() || bytes.size > MEDIA_CHUNK_BYTES) return
        val from = packet.optString("from")
        val transfer = packet.optString("transfer")
        val index = packet.optInt("idx", -1)
        val total = packet.optInt("total", 0)
        val fileName = packet.optString("fileName", "archivo")
            .map { ch -> if (ch.isLetterOrDigit() || ch in " ._-()") ch else '_' }
            .joinToString("").trim().take(100).ifBlank { "archivo" }
        val mime = packet.optString("mime", "application/octet-stream").take(120)
        val digest = packet.optString("sha256", "")
        val senderName = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
        val validTransferId = runCatching { UUID.fromString(transfer); true }.getOrDefault(false)
        if (from.isBlank() || !validTransferId || total !in 1..100 || index !in 0 until total || digest.length != 64 || !digest.all { it in "0123456789abcdefABCDEF" }) return
        var complete: ByteArray? = null
        synchronized(lock) {
            val key = "$from:$transfer"
            if (!mediaAssemblies.containsKey(key) && mediaAssemblies.size >= 4) return
            var assembly = mediaAssemblies[key]
            if (assembly == null) {
                assembly = MediaAssembly(total, fileName, mime, digest, senderName)
                mediaAssemblies[key] = assembly
            }
            if (assembly.total != total || assembly.fileName != fileName || assembly.mimeType != mime || assembly.digest != digest) {
                mediaAssemblies.remove(key)
                return
            }
            if (assembly.parts[index] == null) {
                assembly.parts[index] = bytes
                assembly.count++
                assembly.size += bytes.size
            }
            if (assembly.size > MAX_MEDIA_BYTES) {
                mediaAssemblies.remove(key)
                return
            }
            if (assembly.count == assembly.total) {
                val output = ByteArrayOutputStream(assembly.size)
                assembly.parts.forEach { part -> output.write(part ?: ByteArray(0)) }
                complete = output.toByteArray()
                mediaAssemblies.remove(key)
            }
        }
        val assembled = complete ?: return
        val actualDigest = MessageDigest.getInstance("SHA-256").digest(assembled).joinToString("") { "%02x".format(it) }
        if (!actualDigest.equals(digest, ignoreCase = true)) return
        ioScope.launch {
            val dao = ChatDatabase.get(this@MeshBleService).chatDao()
            if (dao.findMessage(transfer) == null) {
                val directory = File(filesDir, "received_media").apply { mkdirs() }
                val extension = fileName.substringAfterLast('.', "bin").filter { it.isLetterOrDigit() }.take(8).ifBlank { "bin" }
                val file = File(directory, "${transfer}.$extension")
                file.writeBytes(assembled)
                val now = System.currentTimeMillis()
                val chat = dao.findChat(from)
                if (chat != null) dao.upsertChat(chat.copy(title = senderName, lastMessage = "Archivo · $fileName", updatedAt = now, unreadCount = chat.unreadCount + 1))
                else dao.upsertChat(ChatEntity(from, from, senderName, "Archivo · $fileName", now, 1, "MESH", null))
                dao.insertMessage(MessageEntity(transfer, from, from, fileName, now, false, "received", "MESH", "MEDIA", file.absolutePath, fileName, mime))
                NotificationHelper.show(this@MeshBleService, "Archivo de $senderName", fileName, transfer.hashCode())
            }
            sendControl(from, "MESSAGE_ACK", transfer)
        }
    }

    private fun processPendingMessages(targetId: String) {
        val ready = mutableListOf<PendingMessage>()
        synchronized(lock) {
            val iterator = pendingMessages.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item.toId == targetId) { ready.add(item); iterator.remove() }
            }
        }
        ready.forEach { sendChat(it.toId, it.name, it.body, it.messageId) }
        // Recover unsent/unacknowledged text messages after a process restart. Room is the durable queue;
        // BLE queues are only an optimization and may disappear when Android kills the service.
        ioScope.launch {
            val dao = ChatDatabase.get(this@MeshBleService).chatDao()
            val name = peerNames[targetId] ?: getSharedPreferences("betachat_peer_names", MODE_PRIVATE).getString(targetId, "Usuario").orEmpty()
            dao.pendingTextForPeer(targetId).forEach { message ->
                sendChat(targetId, name, message.text, message.id)
            }
        }
    }

    private fun sendPacketToNetwork(json: String, excludedAddress: String?) {
        val eligible = clients.values.filter { gatt ->
            val address = runCatching { gatt.device.address }.getOrDefault("")
            address != excludedAddress && clientRx.containsKey(address)
        }
        if (eligible.isEmpty()) {
            synchronized(lock) {
                if (pendingPackets.size >= 256) pendingPackets.removeFirst()
                pendingPackets.addLast(json)
            }
            return
        }
        eligible.forEach { sendPacketToGatt(it, json) }
    }

    private fun sendPacketToGatt(gatt: BluetoothGatt, json: String) {
        val address = runCatching { gatt.device.address }.getOrDefault("")
        if (address.isBlank()) return
        val bytes = json.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty() || bytes.size > MAX_PACKET_BYTES) return
        val mtu = mtuByAddress[address] ?: 23
        val sliceSize = (mtu - 3 - 8).coerceAtLeast(1)
        val total = (bytes.size + sliceSize - 1) / sliceSize
        if (total > 255) return
        val crc = CRC32().apply { update(bytes) }.value.toInt()
        val frames = ArrayList<ByteArray>(total)
        for (index in 0 until total) {
            val start = index * sliceSize
            val end = minOf(bytes.size, start + sliceSize)
            val chunk = bytes.copyOfRange(start, end)
            val frame = ByteBuffer.allocate(8 + chunk.size)
                .put(0x42.toByte()).put(0x43.toByte()).putInt(crc)
                .put(index.toByte()).put(total.toByte()).put(chunk).array()
            frames.add(frame)
        }
        synchronized(lock) {
            val queue = writeQueues.getOrPut(address) { ArrayDeque() }
            frames.forEach { queue.addLast(it) }
        }
        writeNext(gatt)
    }

    private fun writeNext(gatt: BluetoothGatt) {
        val address = runCatching { gatt.device.address }.getOrDefault("")
        if (address.isBlank() || !writesInFlight.add(address)) return
        val frame = synchronized(lock) { writeQueues[address]?.peekFirst() }
        if (frame == null) {
            writesInFlight.remove(address)
            return
        }
        val characteristic = clientRx[address]
        if (characteristic == null) {
            writesInFlight.remove(address)
            return
        }
        val initiated = try {
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(characteristic, frame, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                characteristic.value = frame
                @Suppress("DEPRECATION")
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                gatt.writeCharacteristic(characteristic)
            }
        } catch (_: SecurityException) { false }
        if (!initiated) {
            synchronized(lock) { writeQueues[address]?.pollFirst() }
            writesInFlight.remove(address)
            gatt.postWriteContinue()
        }
    }

    private fun BluetoothGatt.postWriteContinue() {
        // Retry the next frame after a failed start; avoid recursive queue growth.
        android.os.Handler(mainLooper).post { writeNext(this) }
    }

    private fun flushPending() {
        val packets = mutableListOf<String>()
        synchronized(lock) { while (pendingPackets.isNotEmpty()) packets.add(pendingPackets.removeFirst()) }
        packets.forEach { sendPacketToNetwork(it, null) }
    }

    private fun rememberPacket(id: String): Boolean {
        if (id.isBlank()) return false
        val added = seenPacketIds.add(id)
        if (seenPacketIds.size > 5000) seenPacketIds.clear()
        return added
    }

    private fun loadSavedPeers() {
        getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).all.forEach { (id, pub) ->
            if (!id.startsWith("phone:") && !id.startsWith("bio:") && !id.startsWith("status:") && !id.startsWith("statusAt:") && pub is String) peerKeys[id] = pub
        }
        getSharedPreferences("betachat_peer_names", MODE_PRIVATE).all.forEach { (id, name) ->
            if (name is String) peerNames[id] = name
        }
    }

    private fun currentNickname(): String = prefs.getString("nickname", "Usuario")?.trim().orEmpty().ifBlank { "Usuario" }

    private fun startForegroundCompat() {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_betachat)
            .setContentTitle("ẞetaChat está activo")
            .setContentText("Buscando dispositivos cercanos")
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Red Bluetooth de ẞetaChat", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private data class PendingMessage(val toId: String, val name: String, val body: String, val messageId: String)
    private data class PendingMedia(val toId: String, val name: String, val nickname: String, val transferId: String, val fileName: String, val mimeType: String, val bytes: ByteArray)
    private class MediaAssembly(val total: Int, val fileName: String, val mimeType: String, val digest: String, val senderName: String) {
        val parts: Array<ByteArray?> = arrayOfNulls(total)
        var count: Int = 0
        var size: Int = 0
    }
    private class FrameAssembly(val total: Int) {
        val parts: Array<ByteArray?> = arrayOfNulls(total)
        var count: Int = 0
    }
}
