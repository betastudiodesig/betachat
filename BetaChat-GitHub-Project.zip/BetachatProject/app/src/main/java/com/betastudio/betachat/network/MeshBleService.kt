package com.betastudio.betachat.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.ParcelUuid
import android.util.Base64
import androidx.core.app.NotificationCompat
import com.betastudio.betachat.MainActivity
import com.betastudio.betachat.R
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.security.IdentityCrypto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.nio.ByteBuffer
import java.util.ArrayDeque
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.CRC32

/**
 * BLE GATT transport and bounded store-and-forward mesh prototype.
 * Messages are signed and encrypted end-to-end by IdentityCrypto. Relays see only the envelope.
 */
class MeshBleService : Service() {
    companion object {
        const val ACTION_START = "com.betastudio.betachat.action.START_MESH"
        const val ACTION_SEND = "com.betastudio.betachat.action.SEND_MESSAGE"
        const val ACTION_PROFILE = "com.betastudio.betachat.action.PROFILE_CHANGED"
        const val ACTION_PEER = "com.betastudio.betachat.action.PEER_FOUND"
        const val EXTRA_PEER_ID = "peer_id"
        const val EXTRA_PEER_NAME = "peer_name"
        private const val CHANNEL_ID = "betachat_mesh"
        private const val NOTIFICATION_ID = 2026
        private val SERVICE_UUID: UUID = UUID.fromString("e7d2a170-6b9a-4bd2-a247-7ca8b3c0f001")
        private val RX_UUID: UUID = UUID.fromString("e7d2a171-6b9a-4bd2-a247-7ca8b3c0f001")
        private const val MAX_LINKS = 5
        private const val MAX_PACKET_BYTES = 3000
        private const val MAX_TTL = 6
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var identity: IdentityCrypto
    private val prefs by lazy { getSharedPreferences("betachat_profile", Context.MODE_PRIVATE) }
    private val peerKeys = ConcurrentHashMap<String, String>()
    private val peerNames = ConcurrentHashMap<String, String>()
    private val clients = ConcurrentHashMap<String, BluetoothGatt>()
    private val clientRx = ConcurrentHashMap<String, BluetoothGattCharacteristic>()
    private val mtuByAddress = ConcurrentHashMap<String, Int>()
    private val writeQueues = ConcurrentHashMap<String, ArrayDeque<ByteArray>>()
    private val writesInFlight = ConcurrentHashMap.newKeySet<String>()
    private val seenPacketIds = ConcurrentHashMap.newKeySet<String>()
    private val assemblies = ConcurrentHashMap<String, FrameAssembly>()
    private val pendingPackets = ArrayDeque<String>()
    private val pendingMessages = ArrayDeque<PendingMessage>()
    private val lock = Any()
    private var gattServer: BluetoothGattServer? = null
    private var advertiser: android.bluetooth.le.BluetoothLeAdvertiser? = null
    private var scanning = false
    private var advertising = false
    private var bluetoothAdapter: BluetoothAdapter? = null
    private val connectingAddresses = ConcurrentHashMap.newKeySet<String>()

    override fun onCreate() {
        super.onCreate()
        identity = IdentityCrypto(this)
        val manager = getSystemService(BluetoothManager::class.java)
        bluetoothAdapter = manager?.adapter
        loadSavedPeers()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SEND -> {
                if (gattServer == null) startTransport()
                val to = intent.getStringExtra("to").orEmpty()
                val name = intent.getStringExtra("name").orEmpty()
                val body = intent.getStringExtra("body").orEmpty()
                if (to.isNotBlank() && body.isNotBlank()) sendChat(to, name, body)
            }
            ACTION_PROFILE -> {
                startTransport()
                broadcastOwnHello()
            }
            else -> startTransport()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopTransport()
        ioScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        super.onDestroy()
    }

    private fun startTransport() {
        startForegroundCompat()
        try {
            val adapter = bluetoothAdapter ?: return
            if (!adapter.isEnabled) return
            val manager = getSystemService(BluetoothManager::class.java) ?: return
            if (gattServer == null) {
                gattServer = manager.openGattServer(this, serverCallback)
                val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
                val rx = BluetoothGattCharacteristic(
                    RX_UUID,
                    BluetoothGattCharacteristic.PROPERTY_WRITE,
                    BluetoothGattCharacteristic.PERMISSION_WRITE
                )
                service.addCharacteristic(rx)
                val accepted = gattServer?.addService(service) ?: false
                if (!accepted) startAdvertisingAndScan()
            } else {
                startAdvertisingAndScan()
            }
        } catch (_: SecurityException) {
            // Runtime permissions may have been revoked while the service was alive.
        } catch (_: IllegalStateException) {
            // BLE advertising is unavailable on some devices or when Bluetooth is restarting.
        }
    }

    private fun startAdvertisingAndScan() {
        try {
            val adapter = bluetoothAdapter ?: return
            advertiser = adapter.bluetoothLeAdvertiser
            if (advertiser != null && !advertising) {
                val settings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                    .setConnectable(true)
                    .setTimeout(0)
                    .build()
                val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(SERVICE_UUID)).build()
                advertiser?.startAdvertising(settings, data, advertiseCallback)
            }
            startScan()
        } catch (_: SecurityException) {
        } catch (_: IllegalStateException) {
        }
    }

    private fun startScan() {
        try {
            val scanner = bluetoothAdapter?.bluetoothLeScanner ?: return
            if (scanning) return
            val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0)
                .build()
            scanner.startScan(listOf(filter), settings, scanCallback)
            scanning = true
        } catch (_: SecurityException) {
        } catch (_: IllegalStateException) {
        }
    }

    private fun stopTransport() {
        try { if (scanning) bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { if (advertising) advertiser?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        scanning = false
        advertising = false
        clients.values.forEach { runCatching { it.disconnect(); it.close() } }
        clients.clear()
        clientRx.clear()
        try { gattServer?.close() } catch (_: Exception) {}
        gattServer = null
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) { advertising = true }
        override fun onStartFailure(errorCode: Int) { advertising = false }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val address = runCatching { device.address }.getOrNull() ?: return
            if (clients.containsKey(address) || connectingAddresses.contains(address) || clients.size + connectingAddresses.size >= MAX_LINKS) return
            connectingAddresses.add(address)
            try {
                val gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    device.connectGatt(this@MeshBleService, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                } else {
                    @Suppress("DEPRECATION")
                    device.connectGatt(this@MeshBleService, false, gattCallback)
                }
                if (gatt == null) connectingAddresses.remove(address)
            } catch (_: SecurityException) {
                connectingAddresses.remove(address)
            }
        }

        override fun onScanFailed(errorCode: Int) { scanning = false }
    }

    private val serverCallback = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(status: Int, service: BluetoothGattService?) {
            if (status == BluetoothGatt.GATT_SUCCESS && service?.uuid == SERVICE_UUID) startAdvertisingAndScan()
        }

        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                // Incoming server-side links are managed by Android. The same peer may also
                // establish an outgoing central link; only outgoing links can be used for writes.
                runCatching { gattServer?.cancelConnection(device) }
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            val ok = characteristic.uuid == RX_UUID && !preparedWrite && offset == 0 && acceptFrame(device.address, value)
            if (responseNeeded) {
                try {
                    gattServer?.sendResponse(
                        device,
                        requestId,
                        if (ok) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE,
                        0,
                        null
                    )
                } catch (_: SecurityException) {}
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                clients[address] = gatt
                connectingAddresses.remove(address)
                mtuByAddress[address] = 23
                try { gatt.discoverServices() } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                clients.remove(address)
                clientRx.remove(address)
                mtuByAddress.remove(address)
                connectingAddresses.remove(address)
                writesInFlight.remove(address)
                writeQueues.remove(address)
                runCatching { gatt.close() }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) return
            val address = runCatching { gatt.device.address }.getOrDefault("")
            val characteristic = gatt.getService(SERVICE_UUID)?.getCharacteristic(RX_UUID) ?: return
            clientRx[address] = characteristic
            try { gatt.requestMtu(247) } catch (_: SecurityException) {}
            sendPacketToGatt(gatt, identity.helloPacket(currentNickname()).toString())
            flushPending()
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            if (status == BluetoothGatt.GATT_SUCCESS) mtuByAddress[address] = mtu.coerceIn(23, 517)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            val address = runCatching { gatt.device.address }.getOrDefault("")
            synchronized(lock) { writeQueues[address]?.pollFirst() }
            writesInFlight.remove(address)
            writeNext(gatt)
        }
    }

    private fun sendChat(toId: String, peerName: String, body: String) {
        val pub = peerKeys[toId] ?: getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).getString(toId, null)
        if (pub.isNullOrBlank()) {
            synchronized(lock) {
                if (pendingMessages.size < 50) pendingMessages.addLast(PendingMessage(toId, peerName, body.take(250)))
            }
            broadcastOwnHello()
            return
        }
        runCatching {
            val packet = identity.createEncryptedChat(toId, pub, currentNickname(), body.take(250))
            rememberPacket(packet.optString("id"))
            sendPacketToNetwork(packet.toString(), null)
        }.onFailure {
            // The UI has already saved the local message; transport errors are retried on reconnect.
        }
    }

    private fun broadcastOwnHello() {
        val hello = identity.helloPacket(currentNickname()).toString()
        rememberPacket(JSONObject(hello).optString("id"))
        sendPacketToNetwork(hello, null)
    }

    private fun acceptFrame(address: String, frame: ByteArray): Boolean {
        if (frame.size < 9 || frame[0] != 0x42.toByte() || frame[1] != 0x43.toByte()) return false
        val buffer = ByteBuffer.wrap(frame, 2, 6)
        val token = buffer.int
        val index = buffer.get().toInt() and 0xff
        val total = buffer.get().toInt() and 0xff
        if (total < 1 || index >= total) return false
        val key = "$address:$token"
        val payload = frame.copyOfRange(8, frame.size)
        var assembled: ByteArray? = null
        synchronized(lock) {
            var entry = assemblies[key]
            if (entry == null || entry.total != total) {
                entry = FrameAssembly(total)
                assemblies[key] = entry
            }
            if (entry.parts[index] == null) {
                entry.parts[index] = payload
                entry.count++
            }
            if (entry.count == entry.total) {
                val output = java.io.ByteArrayOutputStream()
                entry.parts.forEach { part -> output.write(part ?: ByteArray(0)) }
                assembled = output.toByteArray()
                assemblies.remove(key)
            }
            if (assemblies.size > 100) assemblies.clear()
        }
        assembled?.let { bytes ->
            if (bytes.size <= MAX_PACKET_BYTES) runCatching { processPacket(JSONObject(String(bytes, Charsets.UTF_8)), address) }
        }
        return true
    }

    private fun processPacket(packet: JSONObject, incomingAddress: String) {
        val packetId = packet.optString("id")
        val kind = packet.optString("kind")
        val from = packet.optString("from")
        if (packetId.isBlank() || from.isBlank() || from == identity.deviceId) return
        if (!rememberPacket(packetId)) return

        when (kind) {
            "HELLO" -> {
                if (!identity.isValidHello(packet)) return
                val pub = packet.getString("pub")
                val name = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
                peerKeys[from] = pub
                peerNames[from] = name
                getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).edit().putString(from, pub).apply()
                getSharedPreferences("betachat_peer_names", MODE_PRIVATE).edit().putString(from, name).apply()
                sendBroadcast(Intent(ACTION_PEER).setPackage(packageName)
                    .putExtra(EXTRA_PEER_ID, from).putExtra(EXTRA_PEER_NAME, name))
                processPendingMessages(from)
                relay(packet, incomingAddress)
            }
            "CHAT" -> {
                if (!identity.verifyPacket(packet)) return
                val recipient = packet.optString("to")
                if (recipient == identity.deviceId) {
                    val text = runCatching { identity.decryptChat(packet) }.getOrNull() ?: return
                    val senderName = packet.optString("fromName", "Usuario").ifBlank { "Usuario" }.take(32)
                    persistIncoming(from, senderName, text, packetId)
                }
                relay(packet, incomingAddress)
            }
        }
    }

    private fun relay(packet: JSONObject, incomingAddress: String) {
        val ttl = packet.optInt("ttl", 0)
        if (ttl <= 0) return
        packet.put("ttl", ttl - 1)
        sendPacketToNetwork(packet.toString(), incomingAddress)
    }

    private fun persistIncoming(from: String, name: String, text: String, messageId: String) {
        ioScope.launch {
            val dao = ChatDatabase.get(this@MeshBleService).chatDao()
            if (dao.findMessage(messageId) != null) return@launch
            val current = System.currentTimeMillis()
            val chat = dao.findChat(from)
            dao.upsertChat(ChatEntity(from, from, name, text, current, (chat?.unreadCount ?: 0) + 1))
            dao.insertMessage(MessageEntity(messageId, from, from, text, current, false, "received"))
        }
    }

    private fun processPendingMessages(targetId: String) {
        val ready = mutableListOf<PendingMessage>()
        synchronized(lock) {
            val iterator = pendingMessages.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item.toId == targetId) { ready.add(item); iterator.remove() }
            }
        }
        ready.forEach { sendChat(it.toId, it.name, it.body) }
    }

    private fun sendPacketToNetwork(json: String, excludedAddress: String?) {
        val eligible = clients.values.filter { gatt ->
            val address = runCatching { gatt.device.address }.getOrDefault("")
            address != excludedAddress && clientRx.containsKey(address)
        }
        if (eligible.isEmpty()) {
            synchronized(lock) {
                if (pendingPackets.size >= 100) pendingPackets.removeFirst()
                pendingPackets.addLast(json)
            }
            return
        }
        eligible.forEach { sendPacketToGatt(it, json) }
    }

    private fun sendPacketToGatt(gatt: BluetoothGatt, json: String) {
        val address = runCatching { gatt.device.address }.getOrDefault("")
        if (address.isBlank()) return
        val bytes = json.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty() || bytes.size > MAX_PACKET_BYTES) return
        val mtu = mtuByAddress[address] ?: 23
        val sliceSize = (mtu - 3 - 8).coerceAtLeast(1)
        val total = (bytes.size + sliceSize - 1) / sliceSize
        if (total > 255) return
        val crc = CRC32().apply { update(bytes) }.value.toInt()
        val frames = ArrayList<ByteArray>(total)
        for (index in 0 until total) {
            val start = index * sliceSize
            val end = minOf(bytes.size, start + sliceSize)
            val chunk = bytes.copyOfRange(start, end)
            val frame = ByteBuffer.allocate(8 + chunk.size)
                .put(0x42.toByte()).put(0x43.toByte()).putInt(crc)
                .put(index.toByte()).put(total.toByte()).put(chunk).array()
            frames.add(frame)
        }
        synchronized(lock) {
            val queue = writeQueues.getOrPut(address) { ArrayDeque() }
            frames.forEach { queue.addLast(it) }
        }
        writeNext(gatt)
    }

    private fun writeNext(gatt: BluetoothGatt) {
        val address = runCatching { gatt.device.address }.getOrDefault("")
        if (address.isBlank() || !writesInFlight.add(address)) return
        val frame = synchronized(lock) { writeQueues[address]?.peekFirst() }
        if (frame == null) {
            writesInFlight.remove(address)
            return
        }
        val characteristic = clientRx[address]
        if (characteristic == null) {
            writesInFlight.remove(address)
            return
        }
        val initiated = try {
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(characteristic, frame, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                characteristic.value = frame
                @Suppress("DEPRECATION")
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                gatt.writeCharacteristic(characteristic)
            }
        } catch (_: SecurityException) { false }
        if (!initiated) {
            synchronized(lock) { writeQueues[address]?.pollFirst() }
            writesInFlight.remove(address)
            gatt.postWriteContinue()
        }
    }

    private fun BluetoothGatt.postWriteContinue() {
        // Retry the next frame after a failed start; avoid recursive queue growth.
        android.os.Handler(mainLooper).post { writeNext(this) }
    }

    private fun flushPending() {
        val packets = mutableListOf<String>()
        synchronized(lock) { while (pendingPackets.isNotEmpty()) packets.add(pendingPackets.removeFirst()) }
        packets.forEach { sendPacketToNetwork(it, null) }
    }

    private fun rememberPacket(id: String): Boolean {
        if (id.isBlank()) return false
        val added = seenPacketIds.add(id)
        if (seenPacketIds.size > 5000) seenPacketIds.clear()
        return added
    }

    private fun loadSavedPeers() {
        getSharedPreferences("betachat_peer_keys", MODE_PRIVATE).all.forEach { (id, pub) ->
            if (pub is String) peerKeys[id] = pub
        }
        getSharedPreferences("betachat_peer_names", MODE_PRIVATE).all.forEach { (id, name) ->
            if (name is String) peerNames[id] = name
        }
    }

    private fun currentNickname(): String = prefs.getString("nickname", "Usuario")?.trim().orEmpty().ifBlank { "Usuario" }

    private fun startForegroundCompat() {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_betachat)
            .setContentTitle("ẞetaChat está activo")
            .setContentText("Buscando dispositivos cercanos")
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Red Bluetooth de ẞetaChat", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private data class PendingMessage(val toId: String, val name: String, val body: String)
    private class FrameAssembly(val total: Int) {
        val parts: Array<ByteArray?> = arrayOfNulls(total)
        var count: Int = 0
    }
}
