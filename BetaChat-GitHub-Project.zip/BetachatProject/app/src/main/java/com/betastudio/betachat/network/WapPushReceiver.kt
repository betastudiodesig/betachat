package com.betastudio.betachat.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Declared for Android's SMS-handler role eligibility. MMS decoding/attachments are deliberately
 * not claimed by this alpha. The UI documents that MMS is not yet supported.
 */
class WapPushReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Preserve privacy: don't log MMS payloads or sender metadata. Full MMS support is a later phase.
    }
}
