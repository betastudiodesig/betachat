package com.betastudio.betachat.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.provider.Telephony
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.UUID

/** Receives carrier SMS broadcasts. It does not read or upload the system SMS database. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION &&
            intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val isDefaultSms = Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
        if (isDefaultSms && intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!isDefaultSms && intent.action == Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val parts = runCatching { Telephony.Sms.Intents.getMessagesFromIntent(intent) }.getOrNull() ?: return
        if (parts.isEmpty()) return
        val phone = parts.firstOrNull()?.originatingAddress?.trim().orEmpty()
        val body = parts.joinToString(separator = "") { it.messageBody.orEmpty() }.take(4000)
        val timestamp = parts.minOfOrNull { it.timestampMillis } ?: System.currentTimeMillis()
        if (phone.isBlank() || body.isBlank()) return
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val dao = ChatDatabase.get(context).chatDao()
                val normalized = phone.replace("[\\s().-]".toRegex(), "").take(24)
                val smsChatId = "sms:$normalized"
                val messageId = "sms-in:$normalized:$timestamp:${UUID.nameUUIDFromBytes(body.toByteArray()).toString().take(8)}"
                if (dao.findMessage(messageId) != null) return@launch
                // If this phone was previously published and linked to a nearby ẞeta identity,
                // keep carrier SMS in that existing conversation instead of creating a duplicate.
                val linkedMeshChat = dao.findMeshChatByPhone(normalized)
                val chatId = linkedMeshChat?.id ?: smsChatId
                if (isDefaultSms) {
                    runCatching {
                        val values = ContentValues().apply {
                            put(Telephony.Sms.ADDRESS, phone)
                            put(Telephony.Sms.BODY, body)
                            put(Telephony.Sms.DATE, timestamp)
                            put(Telephony.Sms.READ, 0)
                            put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
                        }
                        context.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, values)
                    }
                }
                val old = linkedMeshChat ?: dao.findChat(chatId)
                if (old != null) {
                    dao.upsertChat(old.copy(
                        lastMessage = body.take(120), updatedAt = timestamp,
                        unreadCount = old.unreadCount + 1,
                        recipientPhone = normalized
                    ))
                } else {
                    dao.upsertChat(ChatEntity(
                        id = chatId, peerId = chatId, title = normalized,
                        lastMessage = body.take(120), updatedAt = timestamp, unreadCount = 1,
                        route = "SMS", recipientPhone = normalized
                    ))
                }
                dao.insertMessage(MessageEntity(messageId, chatId, normalized, body, timestamp, false, "received", "SMS"))
                NotificationHelper.show(context, "SMS de $normalized", body, messageId.hashCode())
            } catch (_: Exception) {
                // Do not crash the telephony broadcast if storage is temporarily unavailable.
            } finally { pending.finish() }
        }
    }
}
