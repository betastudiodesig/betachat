package com.betastudio.betachat

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val Bg = Color(0xFF080809)
private val Surface1 = Color(0xFF1C1C1E)
private val Surface2 = Color(0xFF29292C)
private val Orange = Color(0xFFF47721)
private val MainText = Color(0xFFF4F4F5)
private val MutedText = Color(0xFF9B9BA1)
private val DividerColor = Color(0xFF242427)
private val Green = Color(0xFF71D6AD)

class MainActivity : ComponentActivity() {
    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Orange,
                onPrimary = Color.Black,
                background = Bg,
                onBackground = MainText,
                surface = Surface1,
                onSurface = MainText,
                secondary = Orange
            )) {
                Surface(modifier = Modifier.fillMaxSize().background(Bg).windowInsetsPadding(WindowInsets.safeDrawing), color = Bg) { BetaChatApp(chatViewModel) }
            }
        }
    }
}

private data class NearbyPeer(
    val id: String,
    val name: String,
    val phone: String = "",
    val bio: String = "",
    val photoUri: String = "",
    val status: String = "",
    val statusAt: Long = 0L,
    val lastSeen: Long = System.currentTimeMillis()
)
private data class PendingRequest(val id: String, val name: String, val phone: String = "")
private enum class AppTab(val label: String, val icon: ImageVector) {
    PEOPLE("Personas", Icons.Default.Groups),
    STATES("Estados", Icons.Default.Visibility),
    CHATS("Chats", Icons.Default.ChatBubbleOutline),
    SETTINGS("Ajustes", Icons.Default.Settings)
}

@Composable
private fun BetaChatApp(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profilePrefs = remember { context.getSharedPreferences("betachat_profile", Context.MODE_PRIVATE) }
    var nickname by remember { mutableStateOf(profilePrefs.getString("nickname", "") ?: "") }
    var phone by remember { mutableStateOf(profilePrefs.getString("phone", "") ?: "") }
    var bio by remember { mutableStateOf(profilePrefs.getString("bio", "") ?: "") }
    var phonePublic by remember { mutableStateOf(profilePrefs.getBoolean("phone_public", false)) }
    var photoUri by remember { mutableStateOf(profilePrefs.getString("photo_uri", "") ?: "") }
    var statusText by remember { mutableStateOf(profilePrefs.getString("status_text", "") ?: "") }
    var statusAt by remember { mutableStateOf(profilePrefs.getLong("status_at", 0L)) }
    var cropSourceUri by remember { mutableStateOf<Uri?>(null) }
    var profileDone by remember { mutableStateOf(profilePrefs.getBoolean("onboarding_done", false)) }
    var savingProfile by remember { mutableStateOf(false) }
    val peers = remember { mutableStateMapOf<String, NearbyPeer>() }
    // A published status is cached locally for its 24-hour lifetime, even after its author
    // leaves Bluetooth range. Only `peers` represents devices currently seen on BLE.
    val knownStatuses = remember {
        mutableStateMapOf<String, NearbyPeer>().apply {
            val peerPrefs = context.getSharedPreferences("betachat_peer_keys", Context.MODE_PRIVATE)
            val names = context.getSharedPreferences("betachat_peer_names", Context.MODE_PRIVATE).all
            val now = System.currentTimeMillis()
            names.forEach { (id, value) ->
                val name = value as? String ?: return@forEach
                val status = peerPrefs.getString("status:$id", "").orEmpty()
                val timestamp = peerPrefs.getLong("statusAt:$id", 0L)
                if (status.isNotBlank() && timestamp > 0L && now - timestamp in 0..(24L * 60L * 60L * 1000L)) {
                    val avatarFile = File(context.filesDir, "peer_profiles/$id.jpg")
                    val avatar = if (avatarFile.isFile) Uri.fromFile(avatarFile).toString() else ""
                    this[id] = NearbyPeer(
                        id = id, name = name,
                        phone = peerPrefs.getString("phone:$id", "").orEmpty(),
                        bio = peerPrefs.getString("bio:$id", "").orEmpty(),
                        photoUri = avatar, status = status, statusAt = timestamp, lastSeen = 0L
                    )
                }
            }
        }
    }
    val requests = remember { mutableStateMapOf<String, PendingRequest>() }
    val sentRequests = remember { mutableStateMapOf<String, Boolean>() }
    var currentTab by remember { mutableStateOf(AppTab.CHATS) }
    var openedChat by remember { mutableStateOf<ChatEntity?>(null) }
    val chatList by viewModel.chats.collectAsStateWithLifecycle()
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        // Open a crop preview first; only the cropped, app-owned image is persisted.
        if (uri != null) cropSourceUri = uri
    }
    val requestPermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val btGranted = bluetoothPermissions().all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (btGranted) startMeshService(context)
        else Toast.makeText(context, "Permite Bluetooth para descubrir usuarios cercanos.", Toast.LENGTH_LONG).show()
    }


    LaunchedEffect(profileDone) {
        if (profileDone) {
            // Do not request permissions or start a foreground service as a side effect of
            // finishing onboarding. The main UI must remain usable when every permission is
            // denied; BLE is activated only after the user explicitly asks to enable it.
            // Restore incoming chat requests that arrived while the UI was not visible.
            context.getSharedPreferences("betachat_requests", Context.MODE_PRIVATE).all.forEach { (key, value) ->
                if (key.startsWith("incoming:") && value is String) {
                    runCatching {
                        val obj = org.json.JSONObject(value)
                        val id = key.removePrefix("incoming:")
                        requests[id] = PendingRequest(id, obj.optString("name", "Usuario"), obj.optString("phone", ""))
                    }
                }
            }
        }
    }

    DisposableEffect(context, profileDone) {
        if (!profileDone) return@DisposableEffect onDispose { }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                val id = intent.getStringExtra(MeshBleService.EXTRA_PEER_ID).orEmpty()
                val name = intent.getStringExtra(MeshBleService.EXTRA_PEER_NAME).orEmpty().ifBlank { "Usuario" }
                val publicPhone = intent.getStringExtra(MeshBleService.EXTRA_PEER_PHONE).orEmpty()
                val peerBio = intent.getStringExtra(MeshBleService.EXTRA_PEER_BIO).orEmpty()
                val peerPhoto = intent.getStringExtra(MeshBleService.EXTRA_PEER_PHOTO).orEmpty()
                val peerStatus = intent.getStringExtra(MeshBleService.EXTRA_PEER_STATUS).orEmpty()
                val peerStatusAt = intent.getLongExtra(MeshBleService.EXTRA_PEER_STATUS_AT, 0L)
                when (intent.action) {
                    MeshBleService.ACTION_PEER -> if (id.isNotBlank()) {
                        val peer = NearbyPeer(id, name, publicPhone, peerBio, peerPhoto, peerStatus, peerStatusAt, System.currentTimeMillis())
                        peers[id] = peer
                        val statusIsFresh = peerStatus.isNotBlank() && peerStatusAt > 0L && System.currentTimeMillis() - peerStatusAt in 0..(24L * 60L * 60L * 1000L)
                        if (statusIsFresh) knownStatuses[id] = peer else knownStatuses.remove(id)
                    }
                    MeshBleService.ACTION_INCOMING_REQUEST -> if (id.isNotBlank()) {
                        val item = PendingRequest(id, name, publicPhone)
                        requests[id] = item
                    }
                    MeshBleService.ACTION_PEER_ACCEPTED -> if (id.isNotBlank()) {
                        sentRequests.remove(id)
                        scope.launch {
                            val phoneFromPeer = peers[id]?.phone.orEmpty()
                            openedChat = viewModel.ensureMeshChat(id, name, phoneFromPeer)
                            currentTab = AppTab.CHATS
                            Toast.makeText(context, "$name aceptó tu solicitud.", Toast.LENGTH_LONG).show()
                        }
                    }
                    MeshBleService.ACTION_PEER_REJECTED -> {
                        sentRequests.remove(id)
                        val reason = intent.getStringExtra("reason")
                        Toast.makeText(context, reason ?: "La solicitud no fue aceptada.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(MeshBleService.ACTION_PEER)
            addAction(MeshBleService.ACTION_INCOMING_REQUEST)
            addAction(MeshBleService.ACTION_PEER_ACCEPTED)
            addAction(MeshBleService.ACTION_PEER_REJECTED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    LaunchedEffect(profileDone) {
        while (profileDone) {
            delay(12_000)
            val now = System.currentTimeMillis()
            val cutoff = now - 50_000
            peers.entries.removeAll { it.value.lastSeen < cutoff }
            knownStatuses.entries.removeAll { it.value.statusAt <= 0L || now - it.value.statusAt !in 0..(24L * 60L * 60L * 1000L) }
        }
    }

    LaunchedEffect(openedChat?.id) { openedChat?.let { viewModel.markRead(it.id) } }

    cropSourceUri?.let { sourceUri ->
        PhotoCropDialog(
            sourceUri = sourceUri,
            onDismiss = { cropSourceUri = null },
            onUsePhoto = { zoom, panX, panY, viewportPx ->
                scope.launch {
                    val savedUri = withContext(Dispatchers.IO) {
                        cropAndSaveProfilePhoto(context, sourceUri, zoom, panX, panY, viewportPx)
                    }
                    if (savedUri != null) {
                        photoUri = savedUri.toString()
                        profilePrefs.edit().putString("photo_uri", photoUri).apply()
                    } else {
                        Toast.makeText(context, "No se pudo recortar esa imagen. Prueba con otra foto.", Toast.LENGTH_LONG).show()
                    }
                    cropSourceUri = null
                }
            }
        )
    }

    fun sendChatRequest(peer: NearbyPeer) {
        if (viewModel.isAccepted(peer.id)) {
            scope.launch { openedChat = viewModel.ensureMeshChat(peer.id, peer.name, peer.phone); currentTab = AppTab.CHATS }
            return
        }
        if (sentRequests[peer.id] == true) {
            Toast.makeText(context, "Ya enviaste una solicitud a ${peer.name}.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(context, MeshBleService::class.java)
            .setAction(MeshBleService.ACTION_REQUEST)
            .putExtra("to", peer.id)
            .putExtra(MeshBleService.EXTRA_REQUEST_KIND, "CHAT_REQUEST")
        runCatching { ContextCompat.startForegroundService(context, intent) }
            .onSuccess {
                sentRequests[peer.id] = true
                Toast.makeText(context, "Solicitud de chat enviada a ${peer.name}.", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(context, "No se pudo enviar la solicitud. Comprueba Bluetooth.", Toast.LENGTH_LONG).show() }
    }

    fun respondToRequest(request: PendingRequest, accept: Boolean) {
        val kind = if (accept) "REQUEST_ACCEPT" else "REQUEST_REJECT"
        val intent = Intent(context, MeshBleService::class.java)
            .setAction(MeshBleService.ACTION_REQUEST)
            .putExtra("to", request.id)
            .putExtra(MeshBleService.EXTRA_REQUEST_KIND, kind)
        runCatching { ContextCompat.startForegroundService(context, intent) }
        requests.remove(request.id)
        context.getSharedPreferences("betachat_requests", Context.MODE_PRIVATE).edit().remove("incoming:${request.id}").apply()
        if (accept) {
            context.getSharedPreferences("betachat_accepted_peers", Context.MODE_PRIVATE).edit().putBoolean(request.id, true).apply()
            scope.launch {
                openedChat = viewModel.ensureMeshChat(request.id, request.name, request.phone)
                currentTab = AppTab.CHATS
            }
        }
    }

    if (!profileDone) {
        WelcomeProfileScreen(
            nickname = nickname,
            phone = phone,
            bio = bio,
            phonePublic = phonePublic,
            photoUri = photoUri,
            onNickname = { nickname = it },
            onPhone = { phone = it },
            onBio = { bio = it },
            onPhonePublic = { phonePublic = it },
            onChoosePhoto = { pickPhoto.launch(arrayOf("image/*")) },
            onCreate = {
                // Prevent a double tap from starting onboarding completion more than once.
                if (!savingProfile) {
                    savingProfile = true
                    val savedName = nickname.trim().ifBlank { "Usuario" }.take(32)
                    val savedPhone = ChatViewModel.normalizePhone(phone)
                    val savedBio = bio.trim().take(160)
                    val savedPhoto = photoUri
                    val savedPublic = phonePublic
                    val persisted = runCatching {
                        profilePrefs.edit()
                            .putString("nickname", savedName)
                            .putString("phone", savedPhone)
                            .putString("bio", savedBio)
                            .putBoolean("phone_public", savedPublic)
                            .putString("photo_uri", savedPhoto)
                            .putBoolean("onboarding_done", true)
                            .commit()
                    }.onFailure { Log.e("BetaChat/Profile", "Profile persistence failed", it) }.getOrDefault(false)
                    if (persisted) {
                        nickname = savedName
                        phone = savedPhone
                        bio = savedBio
                        profileDone = true
                    } else {
                        profilePrefs.edit().putBoolean("onboarding_done", false).apply()
                        Toast.makeText(context, "No se pudo guardar el perfil. Comprueba el espacio disponible e inténtalo de nuevo.", Toast.LENGTH_LONG).show()
                    }
                    savingProfile = false
                }
            }
        )
        return
    }

    if (openedChat != null) {
        val activeChat = openedChat!!
        val peerPrefs = context.getSharedPreferences("betachat_peer_keys", Context.MODE_PRIVATE)
        val cachedPhoto = File(context.filesDir, "peer_profiles/${activeChat.peerId}.jpg")
            .takeIf { it.isFile }?.let { Uri.fromFile(it).toString() }.orEmpty()
        val peerProfile = peers[activeChat.peerId] ?: NearbyPeer(
            id = activeChat.peerId,
            name = context.getSharedPreferences("betachat_peer_names", Context.MODE_PRIVATE)
                .getString(activeChat.peerId, activeChat.title).orEmpty().ifBlank { activeChat.title },
            phone = peerPrefs.getString("phone:${activeChat.peerId}", "").orEmpty(),
            bio = peerPrefs.getString("bio:${activeChat.peerId}", "").orEmpty(),
            photoUri = cachedPhoto,
            status = peerPrefs.getString("status:${activeChat.peerId}", "").orEmpty(),
            statusAt = peerPrefs.getLong("statusAt:${activeChat.peerId}", 0L),
            lastSeen = 0L
        )
        ChatScreen(
            chat = activeChat,
            myNickname = nickname,
            nearby = peers.containsKey(activeChat.peerId),
            accepted = viewModel.isAccepted(activeChat.peerId),
            peerPhotoUri = peers[activeChat.peerId]?.photoUri.orEmpty().ifBlank { cachedPhoto },
            peerProfile = peerProfile,
            viewModel = viewModel,
            onBack = { openedChat = null }
        )
        return
    }


    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(
            Modifier.weight(1f).pointerInput(currentTab) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (abs(drag) > 110f) {
                            val order = listOf(AppTab.PEOPLE, AppTab.STATES, AppTab.CHATS, AppTab.SETTINGS)
                            val index = order.indexOf(currentTab)
                            currentTab = order[(index + if (drag < 0) 1 else -1).coerceIn(0, order.lastIndex)]
                        }
                        drag = 0f
                    }
                )
            }
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    val order = listOf(AppTab.PEOPLE, AppTab.STATES, AppTab.CHATS, AppTab.SETTINGS)
                    val forward = order.indexOf(targetState) > order.indexOf(initialState)
                    if (forward) {
                        (slideInHorizontally(tween(230)) { it } + fadeIn(tween(180))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 3 } + fadeOut(tween(150)))
                    } else {
                        (slideInHorizontally(tween(230)) { -it } + fadeIn(tween(180))) togetherWith
                            (slideOutHorizontally(tween(200)) { it / 3 } + fadeOut(tween(150)))
                    }
                }, label = "tab-transition"
            ) { tab ->
                when (tab) {
                    AppTab.CHATS -> ChatsScreen(
                        chats = chatList,
                        peers = peers.values.toList().sortedBy { it.name.lowercase() },
                        photoUri = photoUri,
                        nickname = nickname,
                        onOpenChat = { openedChat = it },
                        onCreateChat = { currentTab = AppTab.PEOPLE },
                        onLongChat = { chat -> openedChat = chat }
                    )
                    AppTab.PEOPLE -> PeopleScreen(
                        peers = peers.values.toList().sortedBy { it.name.lowercase() },
                        requests = requests.values.toList().sortedBy { it.name.lowercase() },
                        accepted = { viewModel.isAccepted(it) },
                        onPeerClick = { sendChatRequest(it) },
                        onAccept = { respondToRequest(it, true) },
                        onReject = { respondToRequest(it, false) },
                        onRefresh = { startMeshService(context) },
                        onPermissionClick = {
                            val missing = runtimeBluetoothPermissions(context).filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                            if (missing.isNotEmpty()) requestPermissions.launch(missing.toTypedArray()) else startMeshService(context)
                        }
                    )
                    AppTab.STATES -> StatesScreen(
                        ownName = nickname, ownPhoto = photoUri, ownStatus = statusText, ownStatusAt = statusAt,
                        peers = knownStatuses.values.toList().sortedByDescending { it.statusAt },
                        onPublish = { value ->
                            statusText = value.trim().take(180)
                            statusAt = if (statusText.isBlank()) 0L else System.currentTimeMillis()
                            profilePrefs.edit().putString("status_text", statusText).putLong("status_at", statusAt).apply()
                            val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_PROFILE)
                            runCatching { ContextCompat.startForegroundService(context, intent) }
                            Toast.makeText(context, if (statusText.isBlank()) "Estado eliminado." else "Estado publicado para dispositivos Bluetooth cercanos durante 24 horas.", Toast.LENGTH_LONG).show()
                        }
                    )
                    AppTab.SETTINGS -> SettingsScreen(
                        nickname = nickname,
                        phone = phone,
                        bio = bio,
                        phonePublic = phonePublic,
                        photoUri = photoUri,
                        onNicknameChange = { nickname = it },
                        onPhoneChange = { phone = it },
                        onBioChange = { bio = it },
                        onPhonePublicChange = { phonePublic = it },
                        onChoosePhoto = { pickPhoto.launch(arrayOf("image/*")) },
                        onSave = {
                            val saved = nickname.trim().ifBlank { "Usuario" }.take(32)
                            val normalized = ChatViewModel.normalizePhone(phone)
                            nickname = saved
                            phone = normalized
                            profilePrefs.edit().putString("nickname", saved).putString("phone", normalized)
                                .putString("bio", bio.trim().take(160)).putBoolean("phone_public", phonePublic)
                                .putString("photo_uri", photoUri).apply()
                            val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_PROFILE)
                            runCatching { ContextCompat.startForegroundService(context, intent) }
                            Toast.makeText(context, "Perfil actualizado.", Toast.LENGTH_SHORT).show()
                        },
                        onRestartMesh = { startMeshService(context) }
                    )
                }
            }
        }
        BottomBar(selected = currentTab, onSelect = { currentTab = it })
    }
}

@Composable
private fun WelcomeProfileScreen(
    nickname: String, phone: String, bio: String, phonePublic: Boolean, photoUri: String,
    onNickname: (String) -> Unit, onPhone: (String) -> Unit, onBio: (String) -> Unit,
    onPhonePublic: (Boolean) -> Unit, onChoosePhoto: () -> Unit, onCreate: () -> Unit
) {
    var showExplanation by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedVisibility(visible = true, enter = fadeIn(tween(650)) + slideInVertically(tween(650)) { it / 6 }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(78.dp).clip(RoundedCornerShape(27.dp)).background(Orange), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Color.Black, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(13.dp))
                Text("ẞetaChat", color = MainText, fontSize = 31.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
                Text("Mensajes privados por Bluetooth, sin Internet.", color = MutedText, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ProfilePhoto(photoUri, nickname, 74)
            Column(Modifier.weight(1f)) {
                Text("Crea tu perfil", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Así te verán otros usuarios cuando tu perfil sea visible.", color = MutedText, fontSize = 12.sp, lineHeight = 17.sp)
            }
            IconButton(onClick = onChoosePhoto) { Icon(Icons.Default.Edit, contentDescription = "Elegir foto", tint = Orange) }
        }
        Spacer(Modifier.height(15.dp))
        OutlinedTextField(value = nickname, onValueChange = { onNickname(it.take(32)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Apodo") }, singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = phone, onValueChange = { onPhone(it.take(24)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Tu número de teléfono") }, placeholder = { Text("+1 555 123 4567") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = bio, onValueChange = { onBio(it.take(160)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Biografía (opcional)") }, minLines = 2, maxLines = 3, colors = fieldColors())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Surface1).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (phonePublic) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Orange)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Número público", color = MainText, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(if (phonePublic) "Los usuarios cercanos podrán verlo." else "Tu número no se compartirá en el descubrimiento.", color = MutedText, fontSize = 11.sp)
            }
            Switch(checked = phonePublic, onCheckedChange = onPhonePublic)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { showExplanation = !showExplanation }) {
            Icon(Icons.Default.Info, contentDescription = null, tint = Orange, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(if (showExplanation) "Ocultar cómo funciona" else "Cómo funciona ẞetaChat", color = Orange)
        }
        AnimatedVisibility(showExplanation, enter = fadeIn() + slideInVertically { it / 5 }, exit = fadeOut()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExplainRow(Icons.Default.Bluetooth, "Cerca", "Descubre perfiles y envía mensajes, estados y archivos cuando los dispositivos están conectados por Bluetooth.")
                ExplainRow(Icons.Default.Lock, "Privacidad", "El número solo se anuncia si activas la opción pública. Los chats usan cifrado autenticado entre las identidades de los dispositivos.")
                ExplainRow(Icons.Default.Visibility, "Estados", "Los estados de texto expiran en 24 horas y solo se anuncian a dispositivos Bluetooth cercanos.")
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
            Text("Crear perfil y continuar", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, contentDescription = null)
        }
        Text("Tu perfil y tus mensajes se guardan localmente en este teléfono.", color = MutedText, fontSize = 10.sp, modifier = Modifier.padding(top = 9.dp))
    }
}

@Composable
private fun ExplainRow(icon: ImageVector, title: String, body: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(20.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(body, color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

private fun bluetoothPermissions(): List<String> = if (Build.VERSION.SDK_INT >= 31) {
    listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
} else listOf(Manifest.permission.ACCESS_FINE_LOCATION)

private fun runtimeBluetoothPermissions(context: Context): List<String> = buildList {
    addAll(bluetoothPermissions())
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.distinct()

private fun startMeshService(context: Context) {
    val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_START)
    runCatching { ContextCompat.startForegroundService(context, intent) }
        .onFailure { Toast.makeText(context, "No se pudo iniciar Bluetooth. Comprueba los permisos y que Bluetooth esté activado.", Toast.LENGTH_LONG).show() }
}

@Composable
private fun ChatsScreen(
    chats: List<ChatEntity>, peers: List<NearbyPeer>, photoUri: String, nickname: String,
    onOpenChat: (ChatEntity) -> Unit, onCreateChat: () -> Unit, onLongChat: (ChatEntity) -> Unit
) {
    val context = LocalContext.current
    var search by remember { mutableStateOf("") }
    val filtered = chats.filter { it.title.contains(search, true) || it.lastMessage.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(top = 4.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 15.dp, top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ẞetaChat", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
                Text("Mensajería privada por Bluetooth", color = MutedText, fontSize = 12.sp)
            }
            IconButton(onClick = onCreateChat, modifier = Modifier.size(44.dp).clip(CircleShape).background(Surface1)) {
                Icon(Icons.Default.Edit, contentDescription = "Encontrar personas", tint = Orange, modifier = Modifier.size(22.dp))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.width(68.dp).clickable(onClick = onCreateChat), horizontalAlignment = Alignment.CenterHorizontally) {
                Box {
                    ProfilePhoto(photoUri, nickname, 58)
                    Box(Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(Orange).border(2.dp, Bg, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                    }
                }
                Spacer(Modifier.height(5.dp)); Text("Tu perfil", color = MainText, fontSize = 11.sp, maxLines = 1)
            }
            peers.take(12).forEach { peer ->
                Column(Modifier.width(68.dp).clickable(onClick = onCreateChat), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        ProfilePhoto(peer.photoUri, peer.name, 58)
                        Box(Modifier.align(Alignment.BottomEnd).size(11.dp).clip(CircleShape).background(if (peer.status.isNotBlank() && System.currentTimeMillis() - peer.statusAt in 0..(24L * 60 * 60 * 1000)) Orange else Green).border(1.5.dp, Bg, CircleShape))
                    }
                    Spacer(Modifier.height(5.dp)); Text(peer.name, color = MainText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(15.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(15.dp)).background(Surface1).padding(horizontal = 13.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, contentDescription = null, tint = MutedText, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(9.dp))
            BasicTextField(value = search, onValueChange = { search = it }, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp), cursorBrush = SolidColor(Orange), singleLine = true, decorationBox = { inner -> Box { if (search.isEmpty()) Text("Buscar conversaciones", color = MutedText, fontSize = 14.sp); inner() } })
        }
        Spacer(Modifier.height(15.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("CONVERSACIONES", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.weight(1f)); Text("${filtered.size}", color = MutedText, fontSize = 11.sp)
        }
        Spacer(Modifier.height(4.dp))
        if (filtered.isEmpty()) EmptyChats(onFindPeople = onCreateChat, hasSearch = search.isNotBlank())
        else LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            items(filtered, key = { it.id }) { chat ->
                val cachedPhoto = File(context.filesDir, "peer_profiles/${chat.peerId}.jpg")
                    .takeIf { it.isFile }?.let { Uri.fromFile(it).toString() }.orEmpty()
                ChatRow(chat, peers.firstOrNull { it.id == chat.peerId }?.photoUri.orEmpty().ifBlank { cachedPhoto }, onClick = { onOpenChat(chat) }, onLongClick = { onLongChat(chat) })
            }
        }
    }
}

@Composable
private fun EmptyChats(onFindPeople: () -> Unit, hasSearch: Boolean) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(78.dp).clip(RoundedCornerShape(27.dp)).background(Surface1), contentAlignment = Alignment.Center) {
            Icon(if (hasSearch) Icons.Default.Search else Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Orange, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(17.dp))
        Text(if (hasSearch) "Sin resultados" else "Todavía no tienes chats", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text(if (hasSearch) "Prueba con otro nombre." else "Busca a alguien que tenga ẞetaChat y Bluetooth activado. El chat empieza cuando acepta tu solicitud.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onFindPeople, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
            Icon(Icons.Default.BluetoothSearching, contentDescription = null); Spacer(Modifier.width(7.dp)); Text("Encontrar personas")
        }
    }
}

@Composable
private fun ChatRow(chat: ChatEntity, photoUri: String, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).animateContentSize().padding(horizontal = 19.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProfilePhoto(photoUri, chat.title, 55)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.title, color = MainText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(formatTime(chat.updatedAt), color = MutedText, fontSize = 10.sp)
            }
            Text(chat.lastMessage, color = MutedText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                RouteChip("MESH")
                if (chat.unreadCount > 0) Box(Modifier.clip(CircleShape).background(Orange).padding(horizontal = 7.dp, vertical = 3.dp)) { Text(chat.unreadCount.toString(), color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.width(6.dp)); Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color(0xFF5F5F65), modifier = Modifier.size(16.dp))
    }
    Divider(color = DividerColor, modifier = Modifier.padding(start = 87.dp))
}

@Composable
private fun RouteChip(route: String) {
    Row(Modifier.clip(RoundedCornerShape(7.dp)).background(Surface1).padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Orange, modifier = Modifier.size(11.dp))
        Text("BLUETOOTH", color = MutedText, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun PeopleScreen(
    peers: List<NearbyPeer>, requests: List<PendingRequest>, accepted: (String) -> Boolean,
    onPeerClick: (NearbyPeer) -> Unit, onAccept: (PendingRequest) -> Unit, onReject: (PendingRequest) -> Unit,
    onRefresh: () -> Unit, onPermissionClick: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var selectedProfile by remember { mutableStateOf<NearbyPeer?>(null) }
    val filtered = peers.filter { it.name.contains(search, true) || it.phone.contains(search, true) || it.bio.contains(search, true) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 14.dp, top = 17.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Personas", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
                Text("Perfiles en el alcance de Bluetooth", color = MutedText, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "Volver a buscar", tint = Orange) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(17.dp)).background(Surface1).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF142D26)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Green, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Bluetooth Mesh", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("Funciona sin Internet", color = MutedText, fontSize = 12.sp)
            }
            Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
        }
        if (requests.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text("SOLICITUDES DE CHAT · ${requests.size}", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, modifier = Modifier.padding(horizontal = 22.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 180.dp)) {
                items(requests, key = { it.id }) { request ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).clip(RoundedCornerShape(15.dp)).background(Surface1).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(request.name, 42, true); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(request.name, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Quiere iniciar un chat", color = MutedText, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onReject(request) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Close, contentDescription = "Rechazar", tint = MutedText) }
                        IconButton(onClick = { onAccept(request) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Check, contentDescription = "Aceptar", tint = Green) }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedText) }, placeholder = { Text("Buscar personas cercanas") }, singleLine = true, shape = RoundedCornerShape(15.dp), colors = fieldColors())
        Spacer(Modifier.height(16.dp))
        Text("CERCA DE TI", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 5.dp))
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.BluetoothSearching, contentDescription = null, tint = MutedText, modifier = Modifier.size(43.dp))
                Spacer(Modifier.height(12.dp))
                Text(if (search.isBlank()) "Buscando dispositivos" else "No hay coincidencias", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Ambos teléfonos deben tener ẞetaChat y Bluetooth activo. Toca un perfil para ver su información antes de solicitar un chat.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
                Spacer(Modifier.height(14.dp))
                TextButton(onClick = onPermissionClick) { Text("Revisar permisos Bluetooth", color = Orange) }
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.id }) { peer ->
                Row(Modifier.fillMaxWidth().clickable { selectedProfile = peer }.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box { ProfilePhoto(peer.photoUri, peer.name, 52); if (peer.status.isNotBlank()) Box(Modifier.align(Alignment.BottomEnd).size(12.dp).clip(CircleShape).background(Orange).border(2.dp, Bg, CircleShape)) }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(peer.name, color = MainText, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (peer.phone.isNotBlank()) peer.phone else peer.bio.ifBlank { "ID ${peer.id.take(8)}… · Bluetooth" }, color = MutedText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (peer.status.isNotBlank() && System.currentTimeMillis() - peer.statusAt in 0..(24L * 60 * 60 * 1000)) Text(peer.status, color = Orange, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    TextButton(onClick = { selectedProfile = peer }) { Text("Perfil", color = Orange, fontWeight = FontWeight.SemiBold) }
                }
                Divider(color = DividerColor, modifier = Modifier.padding(start = 85.dp))
            }
        }
    }
    selectedProfile?.let { peer ->
        Dialog(onDismissRequest = { selectedProfile = null }) {
            Surface(shape = RoundedCornerShape(27.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF343438))) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ProfilePhoto(peer.photoUri, peer.name, 104)
                    Text(peer.name, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Identidad Bluetooth · ${peer.id.take(12)}…", color = MutedText, fontSize = 10.sp)
                    if (peer.phone.isNotBlank()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Surface2).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = Orange); Spacer(Modifier.width(10.dp)); Column { Text("Número público", color = MutedText, fontSize = 10.sp); Text(peer.phone, color = MainText, fontSize = 14.sp) }
                    }
                    if (peer.bio.isNotBlank()) Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Surface2).padding(12.dp)) {
                        Text("Información", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(peer.bio, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                    if (peer.status.isNotBlank() && System.currentTimeMillis() - peer.statusAt in 0..(24L * 60 * 60 * 1000)) Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color(0xFF302116)).padding(12.dp)) {
                        Text("ESTADO · ${formatTime(peer.statusAt)}", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(peer.status, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                    Button(onClick = { selectedProfile = null; onPeerClick(peer) }, modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
                        Icon(if (accepted(peer.id)) Icons.Default.ChatBubbleOutline else Icons.Default.Send, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(if (accepted(peer.id)) "Abrir conversación" else "Solicitar conversación", fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { selectedProfile = null }) { Text("Cerrar", color = MutedText) }
                }
            }
        }
    }
}

@Composable
private fun StatesScreen(
    ownName: String, ownPhoto: String, ownStatus: String, ownStatusAt: Long,
    peers: List<NearbyPeer>, onPublish: (String) -> Unit
) {
    var draft by remember(ownStatus) { mutableStateOf(ownStatus) }
    val activeStates = peers.filter { it.status.isNotBlank() && it.statusAt > 0L && System.currentTimeMillis() - it.statusAt in 0..(24L * 60 * 60 * 1000) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("Estados", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
        Text("Publicaciones de texto que desaparecen a las 24 horas. Solo se anuncian por Bluetooth a personas cercanas.", color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp)).background(Surface1).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            ProfilePhoto(ownPhoto, ownName, 56); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Mi estado", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(if (ownStatus.isBlank() || System.currentTimeMillis() - ownStatusAt !in 0..(24L * 60 * 60 * 1000)) "Todavía no has publicado" else "Publicado · ${formatTime(ownStatusAt)}", color = MutedText, fontSize = 11.sp)
            }
        }
        OutlinedTextField(value = draft, onValueChange = { draft = it.take(180) }, modifier = Modifier.fillMaxWidth(), label = { Text("¿Qué quieres compartir?") }, placeholder = { Text("Escribe una actualización breve…") }, minLines = 2, maxLines = 4, colors = fieldColors())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { onPublish(draft.trim()) }, enabled = draft.trim() != ownStatus.trim() || ownStatusAt <= 0L || System.currentTimeMillis() - ownStatusAt !in 0..(24L * 60 * 60 * 1000), modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Text("Publicar estado", fontWeight = FontWeight.Bold) }
            TextButton(onClick = { draft = ""; onPublish("") }, enabled = ownStatus.isNotBlank()) { Text("Eliminar", color = MutedText) }
        }
        Divider(color = DividerColor)
        Text("ESTADOS CERCANOS · ${activeStates.size}", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
        if (activeStates.isEmpty()) {
            Text("Todavía no hay estados recibidos. Los demás usuarios deben estar cerca y tener Bluetooth activo.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(vertical = 16.dp))
        } else activeStates.forEach { peer ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface1).padding(13.dp), verticalAlignment = Alignment.Top) {
                ProfilePhoto(peer.photoUri, peer.name, 48); Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(peer.name, color = MainText, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(formatTime(peer.statusAt), color = MutedText, fontSize = 10.sp)
                    }
                    Text(peer.status, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    if (peer.lastSeen == 0L || System.currentTimeMillis() - peer.lastSeen > 50_000L) {
                        Text("Estado guardado · usuario fuera de alcance Bluetooth", color = MutedText, fontSize = 10.sp)
                    }
                }
            }
        }
        Text("En esta versión los estados son de texto. Fotos y vídeos de estado quedan para una siguiente fase; los archivos de chat se pueden enviar desde una conversación.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun SettingsScreen(
    nickname: String, phone: String, bio: String, phonePublic: Boolean, photoUri: String,
    onNicknameChange: (String) -> Unit, onPhoneChange: (String) -> Unit, onBioChange: (String) -> Unit,
    onPhonePublicChange: (Boolean) -> Unit, onChoosePhoto: () -> Unit, onSave: () -> Unit,
    onRestartMesh: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 17.dp)) {
        Text("Ajustes", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(19.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box { ProfilePhoto(photoUri, nickname, 66); Box(Modifier.align(Alignment.BottomEnd).clip(CircleShape).background(Orange).size(22.dp).clickable(onClick = onChoosePhoto), contentAlignment = Alignment.Center) { Icon(Icons.Default.Edit, contentDescription = "Cambiar foto", tint = Color.Black, modifier = Modifier.size(13.dp)) } }
            Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
                Text(nickname.ifBlank { "Usuario" }, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(if (phonePublic && phone.isNotBlank()) "Número visible a usuarios cercanos" else "Número oculto en el descubrimiento", color = MutedText, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(22.dp)); Text("TU PERFIL", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = nickname, onValueChange = { onNicknameChange(it.take(32)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Apodo") }, singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(value = phone, onValueChange = { onPhoneChange(it.take(24)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Número de teléfono (opcional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), colors = fieldColors())
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(value = bio, onValueChange = { onBioChange(it.take(160)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Biografía e información de contacto pública") }, minLines = 2, maxLines = 4, colors = fieldColors())
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface1).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (phonePublic) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Orange)
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
                Text("Número público", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(if (phonePublic) "Se anuncia a usuarios Bluetooth cercanos." else "No se incluye en tu perfil público cercano.", color = MutedText, fontSize = 10.sp)
            }
            Switch(checked = phonePublic, onCheckedChange = onPhonePublicChange)
        }
        Spacer(Modifier.height(11.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Icon(Icons.Default.Check, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Guardar perfil", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(19.dp)); Text("PRIVACIDAD Y CONEXIÓN", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        SettingInfoRow(Icons.Default.Shield, "Identidad del dispositivo", "Clave privada guardada y protegida mediante Android Keystore")
        SettingInfoRow(Icons.Default.Lock, "Cifrado de mensajes", "ECDH P-256, HKDF-SHA-256, AES-256-GCM y firmas ECDSA")
        SettingInfoRow(Icons.Default.Bluetooth, "Solo Bluetooth", "Sin servidores. Ambos dispositivos deben estar en alcance de la red BLE Mesh.")
        TextButton(onClick = onRestartMesh) { Icon(Icons.Default.Refresh, contentDescription = null, tint = Orange); Spacer(Modifier.width(7.dp)); Text("Reiniciar búsqueda Bluetooth", color = Orange) }
        Spacer(Modifier.height(12.dp))
        Text("ẞetaChat 0.3.0 · Vista previa", color = MutedText, fontSize = 11.sp)
        Text("Cifrado autenticado experimental: todavía no implementa Double Ratchet ni secreto hacia adelante. Prueba con dos teléfonos antes de usarlo para información sensible.", color = MutedText, fontSize = 10.sp, lineHeight = 15.sp)
    }
}

@Composable
private fun SettingInfoRow(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(12.dp)).background(Surface1), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.width(11.dp)); Column { Text(title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium); Text(subtitle, color = MutedText, fontSize = 10.sp) }
    }
}

@Composable
private fun ChatScreen(
    chat: ChatEntity, myNickname: String, nearby: Boolean, accepted: Boolean,
    peerPhotoUri: String, peerProfile: NearbyPeer, viewModel: ChatViewModel, onBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val messages by viewModel.messages(chat.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var input by remember(chat.id) { mutableStateOf("") }
    var showPeerProfile by remember(chat.id) { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            if (!accepted) Toast.makeText(context, "Primero debes aceptar la solicitud de chat.", Toast.LENGTH_LONG).show()
            else viewModel.sendMedia(chat, uri, myNickname)
        }
    }
    LaunchedEffect(chat.id, messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
        if (accepted) viewModel.markRead(chat.id)
    }
    fun sendCurrent() {
        if (input.isBlank()) return
        if (!accepted) {
            Toast.makeText(context, "Debes tener una solicitud aceptada para usar este chat.", Toast.LENGTH_LONG).show()
            return
        }
        viewModel.sendMessage(chat, input, myNickname)
        input = ""
    }
    Column(Modifier.fillMaxSize().background(Bg).pointerInput(chat.id) {
        var drag = 0f
        detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = { if (drag > 110f) onBack(); drag = 0f })
    }) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 11.dp, top = 5.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = MainText) }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { showPeerProfile = true }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfilePhoto(peerPhotoUri, chat.title, 42); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(chat.title, color = MainText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (!accepted) "Solicitud pendiente" else if (nearby) "Bluetooth · cerca" else "Bluetooth · esperando conexión", color = if (nearby && accepted) Green else MutedText, fontSize = 10.sp)
                }
            }
            Icon(Icons.Default.Shield, contentDescription = "Identidad cifrada", tint = Orange, modifier = Modifier.size(20.dp))
        }
        Divider(color = DividerColor)
        if (!accepted) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Orange, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp)); Text("Chat todavía no aceptado", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("La otra persona debe aceptar la solicitud antes de enviar mensajes o archivos.", color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(68.dp).clip(RoundedCornerShape(24.dp)).background(Surface1), contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, contentDescription = null, tint = Orange, modifier = Modifier.size(31.dp)) }
                Spacer(Modifier.height(12.dp)); Text("Conversación protegida", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp)); Text("Los mensajes se envían por Bluetooth. Si el destinatario está desconectado, verás una sola marca hasta que el mensaje llegue.", color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { message ->
                MessageBubble(
                    message = message,
                    onLongClick = { clipboard.setText(AnnotatedString(message.text)); Toast.makeText(context, "Copiado.", Toast.LENGTH_SHORT).show() },
                    onAttachmentClick = { openMediaFile(context, message.attachmentPath.orEmpty(), message.attachmentMimeType.orEmpty()) }
                )
            }
        }
        if (accepted) Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            IconButton(onClick = { pickMedia.launch(arrayOf("*/*")) }, modifier = Modifier.size(43.dp).clip(CircleShape).background(Surface1)) {
                Icon(Icons.Default.AttachFile, contentDescription = "Adjuntar archivo", tint = Orange, modifier = Modifier.size(22.dp))
            }
            Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Surface2).padding(horizontal = 16.dp, vertical = 13.dp)) {
                BasicTextField(value = input, onValueChange = { input = it.take(1000) }, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp), cursorBrush = SolidColor(Orange), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { sendCurrent() }), decorationBox = { inner -> Box { if (input.isEmpty()) Text("Mensaje", color = MutedText, fontSize = 15.sp); inner() } })
            }
            IconButton(onClick = { sendCurrent() }, modifier = Modifier.size(48.dp).clip(CircleShape).background(Orange)) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.Black, modifier = Modifier.size(22.dp)) }
        }
        Text("Archivos de hasta 128 KiB · ambos dispositivos deben estar en la red Bluetooth", color = MutedText, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp))
    }
    if (showPeerProfile) {
        Dialog(onDismissRequest = { showPeerProfile = false }) {
            Surface(shape = RoundedCornerShape(27.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF343438))) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    ProfilePhoto(peerProfile.photoUri.ifBlank { peerPhotoUri }, peerProfile.name, 104)
                    Text(peerProfile.name, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(if (nearby) "Bluetooth · cerca" else "Bluetooth · fuera de alcance", color = if (nearby) Green else MutedText, fontSize = 11.sp)
                    Text("Identidad Bluetooth · ${peerProfile.id.take(12)}…", color = MutedText, fontSize = 10.sp)
                    if (peerProfile.phone.isNotBlank()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Surface2).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = Orange); Spacer(Modifier.width(10.dp)); Column { Text("Número público", color = MutedText, fontSize = 10.sp); Text(peerProfile.phone, color = MainText, fontSize = 14.sp) }
                    }
                    if (peerProfile.bio.isNotBlank()) Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Surface2).padding(12.dp)) {
                        Text("Información", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(peerProfile.bio, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                    if (peerProfile.status.isNotBlank() && peerProfile.statusAt > 0L && System.currentTimeMillis() - peerProfile.statusAt in 0..(24L * 60L * 60L * 1000L)) Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color(0xFF302116)).padding(12.dp)) {
                        Text("ESTADO · ${formatTime(peerProfile.statusAt)}", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(peerProfile.status, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                    TextButton(onClick = { showPeerProfile = false }) { Text("Cerrar", color = Orange) }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageEntity, onLongClick: () -> Unit, onAttachmentClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.outgoing) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 292.dp).combinedClickable(
                onClick = { if (message.type == "MEDIA") onAttachmentClick() }, onLongClick = onLongClick
            ).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (message.outgoing) 18.dp else 5.dp, bottomEnd = if (message.outgoing) 5.dp else 18.dp))
                .background(if (message.outgoing) Color(0xFF4E2B19) else Surface1).padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (message.type == "MEDIA") {
                val mime = message.attachmentMimeType.orEmpty()
                val path = message.attachmentPath.orEmpty()
                if (mime.startsWith("image/") && path.isNotBlank()) {
                    AsyncImage(model = File(path), contentDescription = message.attachmentName ?: "Imagen adjunta", modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(7.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.AttachFile, contentDescription = "Archivo", tint = Orange, modifier = Modifier.size(19.dp))
                    Column(Modifier.weight(1f)) {
                        Text(message.attachmentName ?: message.text, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(if (path.isNotBlank()) "Toca para abrir" else "Archivo", color = MutedText, fontSize = 10.sp)
                    }
                }
            } else Text(message.text, color = MainText, fontSize = 15.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.align(Alignment.End)) {
                Icon(Icons.Default.Bluetooth, contentDescription = "Bluetooth", tint = MutedText, modifier = Modifier.size(11.dp))
                Text(formatTime(message.timestamp), color = MutedText, fontSize = 9.sp)
                if (message.outgoing) {
                    val (ticks, tint) = when (message.status) {
                        "failed" -> "!" to Color(0xFFFF7A76)
                        "read" -> "✓✓✓" to Color(0xFF50B6FF)
                        "delivered" -> "✓✓" to MutedText
                        "sent" -> "✓" to MutedText
                        else -> "◷" to MutedText
                    }
                    Text(ticks, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun openMediaFile(context: Context, path: String, mimeType: String) {
    if (path.isBlank()) return
    runCatching {
        val file = File(path)
        if (!file.isFile) throw IllegalStateException("El archivo ya no está disponible.")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeType.ifBlank { "*/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(intent)
    }.onFailure {
        Toast.makeText(context, it.message ?: "No hay una aplicación que pueda abrir este archivo.", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun PhotoCropDialog(
    sourceUri: Uri,
    onDismiss: () -> Unit,
    onUsePhoto: (zoom: Float, panX: Float, panY: Float, viewportPx: Float) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val viewportPx = with(density) { 260.dp.toPx() }
    var bitmap by remember(sourceUri) { mutableStateOf<Bitmap?>(null) }
    var zoom by remember(sourceUri) { mutableStateOf(1f) }
    var panX by remember(sourceUri) { mutableStateOf(0f) }
    var panY by remember(sourceUri) { mutableStateOf(0f) }
    var loading by remember(sourceUri) { mutableStateOf(true) }

    LaunchedEffect(sourceUri) {
        loading = true
        bitmap = withContext(Dispatchers.IO) { decodeProfileImage(context, sourceUri) }
        loading = false
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFF171719),
            border = BorderStroke(1.dp, Color(0xFF343438)),
            tonalElevation = 8.dp
        ) {
            Column(
                Modifier.padding(horizontal = 22.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Ajustar foto", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Arrastra para centrar y pellizca para acercar.", color = MutedText, fontSize = 12.sp)
                Box(
                    Modifier.size(260.dp).shadow(15.dp, CircleShape, clip = false)
                        .clip(CircleShape).background(Color(0xFF242428))
                        .border(2.dp, Brush.linearGradient(listOf(Color(0xFFFFD5A5), Orange, Color(0xFF9B3B08))), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val image = bitmap
                    if (image != null) {
                        Image(
                            bitmap = image.asImageBitmap(),
                            contentDescription = "Vista previa de recorte de perfil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                                .graphicsLayer {
                                    scaleX = zoom
                                    scaleY = zoom
                                    translationX = panX
                                    translationY = panY
                                }
                                .pointerInput(image) {
                                    detectTransformGestures { _, pan, zoomChange, _ ->
                                        val nextZoom = (zoom * zoomChange).coerceIn(1f, 4f)
                                        zoom = nextZoom
                                        val baseScale = maxOf(viewportPx / image.width, viewportPx / image.height)
                                        val maxOffsetX = (image.width * baseScale * nextZoom - viewportPx).coerceAtLeast(0f) / 2f
                                        val maxOffsetY = (image.height * baseScale * nextZoom - viewportPx).coerceAtLeast(0f) / 2f
                                        panX = (panX + pan.x).coerceIn(-maxOffsetX, maxOffsetX)
                                        panY = (panY + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                                    }
                                }
                        )
                    } else {
                        Text(if (loading) "Cargando foto…" else "No se pudo abrir la imagen", color = MutedText, fontSize = 12.sp)
                    }
                }
                Text("La foto se guardará en formato cuadrado y se mostrará dentro del círculo.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancelar", color = MutedText)
                    }
                    Button(
                        onClick = { if (bitmap != null && !loading) onUsePhoto(zoom, panX, panY, viewportPx) },
                        enabled = bitmap != null && !loading,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                    ) {
                        Text("Usar foto", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun decodeProfileImage(context: Context, uri: Uri): Bitmap? {
    return runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 2048) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }.getOrNull()
}

private fun cropAndSaveProfilePhoto(
    context: Context,
    uri: Uri,
    zoom: Float,
    panX: Float,
    panY: Float,
    viewportPx: Float
): Uri? {
    return runCatching {
        val source = decodeProfileImage(context, uri) ?: return null
        val baseScale = maxOf(viewportPx / source.width, viewportPx / source.height)
        val effectiveScale = baseScale * zoom.coerceIn(1f, 4f)
        val side = (viewportPx / effectiveScale).toInt().coerceIn(1, minOf(source.width, source.height))
        val centerX = source.width / 2f - panX / effectiveScale
        val centerY = source.height / 2f - panY / effectiveScale
        val left = (centerX - side / 2f).toInt().coerceIn(0, source.width - side)
        val top = (centerY - side / 2f).toInt().coerceIn(0, source.height - side)
        val cropped = Bitmap.createBitmap(source, left, top, side, side)
        val output = if (cropped.width > 512) Bitmap.createScaledBitmap(cropped, 512, 512, true) else cropped
        val file = java.io.File(context.filesDir, "profile_avatar.jpg")
        file.outputStream().use { output.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (output !== cropped) output.recycle()
        if (cropped !== source) cropped.recycle()
        if (!source.isRecycled) source.recycle()
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
private fun ProfilePhoto(uri: String, name: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(avatarColor(name)), contentAlignment = Alignment.Center) {
        if (uri.isNotBlank()) AsyncImage(model = uri, contentDescription = "Foto de perfil", modifier = Modifier.fillMaxSize().clip(CircleShape))
        else Text(initials(name), color = Color.White, fontSize = (size / 3.2f).sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Avatar(name: String, size: Int, outlined: Boolean) {
    Box(Modifier.size(size.dp).then(if (outlined) Modifier.border(2.dp, Orange, CircleShape).padding(3.dp) else Modifier).clip(CircleShape).background(avatarColor(name)), contentAlignment = Alignment.Center) {
        Text(initials(name), color = Color.White, fontSize = (size / 3.2f).sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun initials(name: String) = name.trim().split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("").ifBlank { "?" }
private fun avatarColor(name: String): Color {
    val palette = listOf(Color(0xFF31434D), Color(0xFF40334D), Color(0xFF4B3829), Color(0xFF2E4940), Color(0xFF353D57), Color(0xFF4C3438))
    return palette[(name.hashCode().ushr(1) % palette.size).coerceAtLeast(0)]
}

@Composable
private fun BottomBar(selected: AppTab, onSelect: (AppTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF050506))
            .border(BorderStroke(1.dp, Color(0xFF19191D)))
            .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 9.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = selected == tab
            val scale by animateFloatAsState(if (isSelected) 1.04f else 1f, animationSpec = tween(220), label = "nav-scale")
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { onSelect(tab) }
                    .padding(vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    Modifier.size(44.dp).scale(scale)
                        .then(if (isSelected) Modifier.shadow(11.dp, CircleShape, clip = false) else Modifier)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) Brush.radialGradient(
                                colors = listOf(Color(0xFFFFD39D), Color(0xFFF47721), Color(0xFF783207)),
                                radius = 90f
                            ) else Brush.radialGradient(listOf(Color(0xFF151518), Color.Transparent))
                        )
                        .then(
                            if (isSelected) Modifier.border(
                                1.dp,
                                Brush.linearGradient(listOf(Color(0xFFFFE5C4), Color(0xFFB64B12), Color(0xFFFFB76D))),
                                CircleShape
                            ) else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Box(
                            Modifier.align(Alignment.TopCenter).padding(top = 4.dp)
                                .size(width = 15.dp, height = 2.dp).clip(CircleShape)
                                .background(Color(0xFFFFE9CE))
                        )
                    }
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        tint = if (isSelected) Color(0xFFFFF5E9) else Color(0xFF85858D),
                        modifier = Modifier.size(if (isSelected) 24.dp else 23.dp)
                            .graphicsLayer { shadowElevation = if (isSelected) 2.dp.toPx() else 0f }
                    )
                }
                Text(
                    tab.label,
                    color = if (isSelected) Color(0xFFFFAA61) else Color(0xFF85858D),
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Orange,
    focusedLabelColor = Orange,
    cursorColor = Orange,
    focusedTextColor = MainText,
    unfocusedTextColor = MainText,
    unfocusedBorderColor = Color(0xFF3A3A3F),
    focusedPlaceholderColor = MutedText,
    unfocusedPlaceholderColor = MutedText
)

private fun formatTime(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
private fun Modifier.navigationPaddingCompat(): Modifier = this.padding(bottom = 0.dp)
