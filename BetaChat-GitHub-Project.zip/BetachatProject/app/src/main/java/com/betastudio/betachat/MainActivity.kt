package com.betastudio.betachat

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val Bg = Color(0xFF080809)
private val Surface1 = Color(0xFF1C1C1E)
private val Surface2 = Color(0xFF29292C)
private val Orange = Color(0xFFF47721)
private val MainText = Color(0xFFF4F4F5)
private val MutedText = Color(0xFF9B9BA1)
private val DividerColor = Color(0xFF242427)
private val Green = Color(0xFF71D6AD)

class MainActivity : ComponentActivity() {
    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = android.graphics.Color.rgb(8, 8, 9)
        window.navigationBarColor = android.graphics.Color.BLACK
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Orange,
                onPrimary = Color.Black,
                background = Bg,
                onBackground = MainText,
                surface = Surface1,
                onSurface = MainText,
                secondary = Orange
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) { BetaChatApp(chatViewModel) }
            }
        }
    }
}

private data class NearbyPeer(
    val id: String,
    val name: String,
    val phone: String = "",
    val bio: String = "",
    val lastSeen: Long = System.currentTimeMillis()
)
private data class PendingRequest(val id: String, val name: String, val phone: String = "")
private enum class AppTab(val label: String, val icon: ImageVector) {
    PEOPLE("Personas", Icons.Default.Groups),
    CALLS("Llamadas", Icons.Default.Call),
    CHATS("Chats", Icons.Default.ChatBubbleOutline),
    SETTINGS("Ajustes", Icons.Default.Settings)
}

@Composable
private fun BetaChatApp(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profilePrefs = remember { context.getSharedPreferences("betachat_profile", Context.MODE_PRIVATE) }
    var nickname by remember { mutableStateOf(profilePrefs.getString("nickname", "") ?: "") }
    var phone by remember { mutableStateOf(profilePrefs.getString("phone", "") ?: "") }
    var bio by remember { mutableStateOf(profilePrefs.getString("bio", "") ?: "") }
    var phonePublic by remember { mutableStateOf(profilePrefs.getBoolean("phone_public", false)) }
    var photoUri by remember { mutableStateOf(profilePrefs.getString("photo_uri", "") ?: "") }
    var cropSourceUri by remember { mutableStateOf<Uri?>(null) }
    var profileDone by remember { mutableStateOf(profilePrefs.getBoolean("onboarding_done", false)) }
    val peers = remember { mutableStateMapOf<String, NearbyPeer>() }
    val requests = remember { mutableStateMapOf<String, PendingRequest>() }
    val sentRequests = remember { mutableStateMapOf<String, Boolean>() }
    var currentTab by remember { mutableStateOf(AppTab.CHATS) }
    var openedChat by remember { mutableStateOf<ChatEntity?>(null) }
    var newSmsDialog by remember { mutableStateOf((context as? MainActivity)?.intent?.action == Intent.ACTION_SENDTO) }
    var smsPhoneInput by remember { mutableStateOf((context as? MainActivity)?.intent?.data?.schemeSpecificPart.orEmpty()) }
    val chatList by viewModel.chats.collectAsStateWithLifecycle()
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        // Open a crop preview first; only the cropped, app-owned image is persisted.
        if (uri != null) cropSourceUri = uri
    }
    val requestPermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val btGranted = bluetoothPermissions().all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (btGranted) startMeshService(context)
        else Toast.makeText(context, "Permite Bluetooth para descubrir usuarios cercanos.", Toast.LENGTH_LONG).show()
    }
    val requestSmsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(context, if (granted) "Permiso de envío SMS concedido." else "Sin permiso SMS no se pueden enviar mensajes por el operador.", Toast.LENGTH_LONG).show()
    }
    val requestSmsAndReceivePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val canSend = results[Manifest.permission.SEND_SMS] == true || ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        Toast.makeText(context, if (canSend) "Permisos SMS actualizados." else "No se concedió el permiso para enviar SMS.", Toast.LENGTH_LONG).show()
    }

    LaunchedEffect(profileDone) {
        if (profileDone) {
            val needed = runtimeBluetoothPermissions(context).filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isEmpty()) startMeshService(context) else requestPermissions.launch(needed.toTypedArray())
            // Restore incoming chat requests that arrived while the UI was not visible.
            context.getSharedPreferences("betachat_requests", Context.MODE_PRIVATE).all.forEach { (key, value) ->
                if (key.startsWith("incoming:") && value is String) {
                    runCatching {
                        val obj = org.json.JSONObject(value)
                        val id = key.removePrefix("incoming:")
                        requests[id] = PendingRequest(id, obj.optString("name", "Usuario"), obj.optString("phone", ""))
                    }
                }
            }
        }
    }

    DisposableEffect(context, profileDone) {
        if (!profileDone) return@DisposableEffect onDispose { }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                val id = intent.getStringExtra(MeshBleService.EXTRA_PEER_ID).orEmpty()
                val name = intent.getStringExtra(MeshBleService.EXTRA_PEER_NAME).orEmpty().ifBlank { "Usuario" }
                val publicPhone = intent.getStringExtra(MeshBleService.EXTRA_PEER_PHONE).orEmpty()
                val peerBio = intent.getStringExtra(MeshBleService.EXTRA_PEER_BIO).orEmpty()
                when (intent.action) {
                    MeshBleService.ACTION_PEER -> if (id.isNotBlank()) peers[id] = NearbyPeer(id, name, publicPhone, peerBio, System.currentTimeMillis())
                    MeshBleService.ACTION_INCOMING_REQUEST -> if (id.isNotBlank()) {
                        val item = PendingRequest(id, name, publicPhone)
                        requests[id] = item
                    }
                    MeshBleService.ACTION_PEER_ACCEPTED -> if (id.isNotBlank()) {
                        sentRequests.remove(id)
                        scope.launch {
                            val phoneFromPeer = peers[id]?.phone.orEmpty()
                            openedChat = viewModel.ensureMeshChat(id, name, phoneFromPeer)
                            currentTab = AppTab.CHATS
                            Toast.makeText(context, "$name aceptó tu solicitud.", Toast.LENGTH_LONG).show()
                        }
                    }
                    MeshBleService.ACTION_PEER_REJECTED -> {
                        sentRequests.remove(id)
                        val reason = intent.getStringExtra("reason")
                        Toast.makeText(context, reason ?: "La solicitud no fue aceptada.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(MeshBleService.ACTION_PEER)
            addAction(MeshBleService.ACTION_INCOMING_REQUEST)
            addAction(MeshBleService.ACTION_PEER_ACCEPTED)
            addAction(MeshBleService.ACTION_PEER_REJECTED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    LaunchedEffect(profileDone) {
        while (profileDone) {
            delay(12_000)
            val cutoff = System.currentTimeMillis() - 50_000
            peers.entries.removeAll { it.value.lastSeen < cutoff }
        }
    }

    LaunchedEffect(openedChat?.id) { openedChat?.let { viewModel.markRead(it.id) } }

    cropSourceUri?.let { sourceUri ->
        PhotoCropDialog(
            sourceUri = sourceUri,
            onDismiss = { cropSourceUri = null },
            onUsePhoto = { zoom, panX, panY, viewportPx ->
                scope.launch {
                    val savedUri = withContext(Dispatchers.IO) {
                        cropAndSaveProfilePhoto(context, sourceUri, zoom, panX, panY, viewportPx)
                    }
                    if (savedUri != null) {
                        photoUri = savedUri.toString()
                        profilePrefs.edit().putString("photo_uri", photoUri).apply()
                    } else {
                        Toast.makeText(context, "No se pudo recortar esa imagen. Prueba con otra foto.", Toast.LENGTH_LONG).show()
                    }
                    cropSourceUri = null
                }
            }
        )
    }

    fun sendChatRequest(peer: NearbyPeer) {
        if (viewModel.isAccepted(peer.id)) {
            scope.launch { openedChat = viewModel.ensureMeshChat(peer.id, peer.name, peer.phone); currentTab = AppTab.CHATS }
            return
        }
        if (sentRequests[peer.id] == true) {
            Toast.makeText(context, "Ya enviaste una solicitud a ${peer.name}.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(context, MeshBleService::class.java)
            .setAction(MeshBleService.ACTION_REQUEST)
            .putExtra("to", peer.id)
            .putExtra(MeshBleService.EXTRA_REQUEST_KIND, "CHAT_REQUEST")
        runCatching { ContextCompat.startForegroundService(context, intent) }
            .onSuccess {
                sentRequests[peer.id] = true
                Toast.makeText(context, "Solicitud de chat enviada a ${peer.name}.", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(context, "No se pudo enviar la solicitud. Comprueba Bluetooth.", Toast.LENGTH_LONG).show() }
    }

    fun respondToRequest(request: PendingRequest, accept: Boolean) {
        val kind = if (accept) "REQUEST_ACCEPT" else "REQUEST_REJECT"
        val intent = Intent(context, MeshBleService::class.java)
            .setAction(MeshBleService.ACTION_REQUEST)
            .putExtra("to", request.id)
            .putExtra(MeshBleService.EXTRA_REQUEST_KIND, kind)
        runCatching { ContextCompat.startForegroundService(context, intent) }
        requests.remove(request.id)
        context.getSharedPreferences("betachat_requests", Context.MODE_PRIVATE).edit().remove("incoming:${request.id}").apply()
        if (accept) {
            context.getSharedPreferences("betachat_accepted_peers", Context.MODE_PRIVATE).edit().putBoolean(request.id, true).apply()
            scope.launch {
                openedChat = viewModel.ensureMeshChat(request.id, request.name, request.phone)
                currentTab = AppTab.CHATS
            }
        }
    }

    if (!profileDone) {
        WelcomeProfileScreen(
            nickname = nickname,
            phone = phone,
            bio = bio,
            phonePublic = phonePublic,
            photoUri = photoUri,
            onNickname = { nickname = it },
            onPhone = { phone = it },
            onBio = { bio = it },
            onPhonePublic = { phonePublic = it },
            onChoosePhoto = { pickPhoto.launch(arrayOf("image/*")) },
            onCreate = {
                val savedName = nickname.trim().ifBlank { "Usuario" }.take(32)
                val savedPhone = ChatViewModel.normalizePhone(phone)
                nickname = savedName
                phone = savedPhone
                profilePrefs.edit()
                    .putString("nickname", savedName)
                    .putString("phone", savedPhone)
                    .putString("bio", bio.trim().take(160))
                    .putBoolean("phone_public", phonePublic)
                    .putString("photo_uri", photoUri)
                    .putBoolean("onboarding_done", true)
                    .apply()
                profileDone = true
            }
        )
        return
    }

    if (openedChat != null) {
        ChatScreen(
            chat = openedChat!!,
            myNickname = nickname,
            nearby = peers.containsKey(openedChat!!.peerId),
            accepted = viewModel.isAccepted(openedChat!!.peerId),
            viewModel = viewModel,
            onBack = { openedChat = null },
            onRouteChange = { route -> viewModel.setRoute(openedChat!!, route); openedChat = openedChat!!.copy(route = route) }
        )
        return
    }

    if (newSmsDialog) {
        AlertDialog(
            onDismissRequest = { newSmsDialog = false },
            containerColor = Surface1,
            title = { Text("Nuevo chat por SMS", color = MainText) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Introduce un número telefónico con prefijo de país cuando sea necesario.", color = MutedText, fontSize = 13.sp)
                    OutlinedTextField(value = smsPhoneInput, onValueChange = { smsPhoneInput = it.take(24) }, label = { Text("Número de teléfono") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), colors = fieldColors())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { viewModel.ensureSmsChat(smsPhoneInput) }
                            .onSuccess { openedChat = it; currentTab = AppTab.CHATS; smsPhoneInput = ""; newSmsDialog = false }
                            .onFailure { Toast.makeText(context, it.message ?: "Número no válido", Toast.LENGTH_LONG).show() }
                    }
                }) { Text("Abrir chat", color = Orange) }
            },
            dismissButton = { TextButton(onClick = { newSmsDialog = false }) { Text("Cancelar", color = MutedText) } }
        )
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(
            Modifier.weight(1f).pointerInput(currentTab) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (abs(drag) > 110f) {
                            val order = listOf(AppTab.PEOPLE, AppTab.CALLS, AppTab.CHATS, AppTab.SETTINGS)
                            val index = order.indexOf(currentTab)
                            currentTab = order[(index + if (drag < 0) 1 else -1).coerceIn(0, order.lastIndex)]
                        }
                        drag = 0f
                    }
                )
            }
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    (slideInHorizontally(animationSpec = tween(210)) { it / 9 } + fadeIn(tween(180))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(180)) { -it / 12 } + fadeOut(tween(150)))
                }, label = "tab-transition"
            ) { tab ->
                when (tab) {
                    AppTab.CHATS -> ChatsScreen(
                        chats = chatList,
                        peers = peers.values.toList().sortedBy { it.name.lowercase() },
                        photoUri = photoUri,
                        nickname = nickname,
                        onOpenChat = { openedChat = it },
                        onNewSms = { newSmsDialog = true },
                        onCreateChat = { currentTab = AppTab.PEOPLE },
                        onSwipeRoute = { chat ->
                            val next = when (chat.route) { "AUTO" -> "MESH"; "MESH" -> "SMS"; else -> "AUTO" }
                            viewModel.setRoute(chat, next)
                            Toast.makeText(context, "Ruta: ${routeLabel(next)}", Toast.LENGTH_SHORT).show()
                        },
                        onLongRoute = { chat -> openedChat = chat }
                    )
                    AppTab.PEOPLE -> PeopleScreen(
                        peers = peers.values.toList().sortedBy { it.name.lowercase() },
                        requests = requests.values.toList().sortedBy { it.name.lowercase() },
                        accepted = { viewModel.isAccepted(it) },
                        onPeerClick = { sendChatRequest(it) },
                        onAccept = { respondToRequest(it, true) },
                        onReject = { respondToRequest(it, false) },
                        onRefresh = { startMeshService(context) },
                        onPermissionClick = {
                            val missing = runtimeBluetoothPermissions(context).filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                            if (missing.isNotEmpty()) requestPermissions.launch(missing.toTypedArray()) else startMeshService(context)
                        }
                    )
                    AppTab.CALLS -> CallsScreen()
                    AppTab.SETTINGS -> SettingsScreen(
                        nickname = nickname,
                        phone = phone,
                        bio = bio,
                        phonePublic = phonePublic,
                        photoUri = photoUri,
                        onNicknameChange = { nickname = it },
                        onPhoneChange = { phone = it },
                        onBioChange = { bio = it },
                        onPhonePublicChange = { phonePublic = it },
                        onChoosePhoto = { pickPhoto.launch(arrayOf("image/*")) },
                        onSave = {
                            val saved = nickname.trim().ifBlank { "Usuario" }.take(32)
                            val normalized = ChatViewModel.normalizePhone(phone)
                            nickname = saved
                            phone = normalized
                            profilePrefs.edit().putString("nickname", saved).putString("phone", normalized)
                                .putString("bio", bio.trim().take(160)).putBoolean("phone_public", phonePublic)
                                .putString("photo_uri", photoUri).apply()
                            val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_PROFILE)
                            runCatching { ContextCompat.startForegroundService(context, intent) }
                            Toast.makeText(context, "Perfil actualizado.", Toast.LENGTH_SHORT).show()
                        },
                        onRestartMesh = { startMeshService(context) },
                        onSmsPermission = {
                            val smsPerms = listOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS)
                            val missing = smsPerms.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                            if (missing.isNotEmpty()) requestSmsAndReceivePermissions.launch(missing.toTypedArray())
                            else Toast.makeText(context, "Permisos SMS concedidos.", Toast.LENGTH_SHORT).show()
                        },
                        onDefaultSms = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                val roleManager = context.getSystemService(RoleManager::class.java)
                                if (roleManager?.isRoleAvailable(RoleManager.ROLE_SMS) == true) {
                                    runCatching { context.startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)) }
                                        .onFailure { Toast.makeText(context, "Android no permite asignar ẞetaChat como app SMS en este dispositivo.", Toast.LENGTH_LONG).show() }
                                }
                            } else Toast.makeText(context, "Configura ẞetaChat como app de SMS predeterminada desde Ajustes de Android.", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        }
        BottomBar(selected = currentTab, onSelect = { currentTab = it })
    }
}

@Composable
private fun WelcomeProfileScreen(
    nickname: String, phone: String, bio: String, phonePublic: Boolean, photoUri: String,
    onNickname: (String) -> Unit, onPhone: (String) -> Unit, onBio: (String) -> Unit,
    onPhonePublic: (Boolean) -> Unit, onChoosePhoto: () -> Unit, onCreate: () -> Unit
) {
    var showExplanation by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedVisibility(visible = true, enter = fadeIn(tween(650)) + slideInVertically(tween(650)) { it / 6 }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(78.dp).clip(RoundedCornerShape(27.dp)).background(Orange), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Color.Black, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(13.dp))
                Text("ẞetaChat", color = MainText, fontSize = 31.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
                Text("Cerca por Bluetooth. Lejos por SMS.", color = MutedText, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ProfilePhoto(photoUri, nickname, 74)
            Column(Modifier.weight(1f)) {
                Text("Crea tu perfil", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Así te verán otros usuarios cuando tu perfil sea visible.", color = MutedText, fontSize = 12.sp, lineHeight = 17.sp)
            }
            IconButton(onClick = onChoosePhoto) { Icon(Icons.Default.Edit, contentDescription = "Elegir foto", tint = Orange) }
        }
        Spacer(Modifier.height(15.dp))
        OutlinedTextField(value = nickname, onValueChange = { onNickname(it.take(32)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Apodo") }, singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = phone, onValueChange = { onPhone(it.take(24)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Tu número de teléfono") }, placeholder = { Text("+1 555 123 4567") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = bio, onValueChange = { onBio(it.take(160)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Biografía (opcional)") }, minLines = 2, maxLines = 3, colors = fieldColors())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Surface1).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (phonePublic) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Orange)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Número público", color = MainText, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(if (phonePublic) "Los usuarios cercanos podrán verlo." else "Tu número no se compartirá en el descubrimiento.", color = MutedText, fontSize = 11.sp)
            }
            Switch(checked = phonePublic, onCheckedChange = onPhonePublic)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { showExplanation = !showExplanation }) {
            Icon(Icons.Default.Info, contentDescription = null, tint = Orange, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(if (showExplanation) "Ocultar cómo funciona" else "Cómo funciona ẞetaChat", color = Orange)
        }
        AnimatedVisibility(showExplanation, enter = fadeIn() + slideInVertically { it / 5 }, exit = fadeOut()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExplainRow(Icons.Default.Bluetooth, "Cerca", "Descubre perfiles por Bluetooth. El chat solo comienza cuando la otra persona acepta la solicitud.")
                ExplainRow(Icons.Default.Sms, "A distancia", "Puedes enviar SMS por la red móvil si tienes servicio y conoces el número del destinatario. No requiere Internet.")
                ExplainRow(Icons.Default.Lock, "Privacidad", "Con el número privado no se comparte durante el descubrimiento. SMS no tiene cifrado de extremo a extremo.")
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
            Text("Crear perfil y continuar", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, contentDescription = null)
        }
        Text("Tu perfil y tus mensajes se guardan localmente en este teléfono.", color = MutedText, fontSize = 10.sp, modifier = Modifier.padding(top = 9.dp))
    }
}

@Composable
private fun ExplainRow(icon: ImageVector, title: String, body: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(20.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(body, color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

private fun bluetoothPermissions(): List<String> = if (Build.VERSION.SDK_INT >= 31) {
    listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
} else listOf(Manifest.permission.ACCESS_FINE_LOCATION)

private fun runtimeBluetoothPermissions(context: Context): List<String> = buildList {
    addAll(bluetoothPermissions())
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.distinct()

private fun startMeshService(context: Context) {
    val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_START)
    runCatching { ContextCompat.startForegroundService(context, intent) }
        .onFailure { Toast.makeText(context, "No se pudo iniciar Bluetooth. Comprueba los permisos y que Bluetooth esté activado.", Toast.LENGTH_LONG).show() }
}

@Composable
private fun ChatsScreen(
    chats: List<ChatEntity>, peers: List<NearbyPeer>, photoUri: String, nickname: String,
    onOpenChat: (ChatEntity) -> Unit, onNewSms: () -> Unit, onCreateChat: () -> Unit,
    onSwipeRoute: (ChatEntity) -> Unit, onLongRoute: (ChatEntity) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var showRouteHelp by remember { mutableStateOf(false) }
    val filtered = chats.filter { it.title.contains(search, true) || it.lastMessage.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(top = 7.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 23.dp, end = 15.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Messages", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
                Text("Conversaciones híbridas", color = MutedText, fontSize = 12.sp)
            }
            IconButton(onClick = onNewSms, modifier = Modifier.size(42.dp)) { Icon(Icons.Default.Sms, contentDescription = "Nuevo SMS", tint = Orange, modifier = Modifier.size(23.dp)) }
            IconButton(onClick = onCreateChat, modifier = Modifier.size(42.dp)) { Icon(Icons.Default.Edit, contentDescription = "Descubrir personas", tint = Orange, modifier = Modifier.size(23.dp)) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
            Column(Modifier.width(68.dp).clickable(onClick = onCreateChat), horizontalAlignment = Alignment.CenterHorizontally) {
                Box {
                    ProfilePhoto(photoUri, nickname, 58)
                    Box(Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(Orange).border(2.dp, Bg, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                    }
                }
                Spacer(Modifier.height(5.dp)); Text("Tu perfil", color = MainText, fontSize = 11.sp, maxLines = 1)
            }
            peers.take(12).forEach { peer ->
                Column(Modifier.width(68.dp).clickable { onCreateChat() }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        Avatar(peer.name, 58, true)
                        Box(Modifier.align(Alignment.BottomEnd).size(10.dp).clip(CircleShape).background(Green).border(1.5.dp, Bg, CircleShape))
                    }
                    Spacer(Modifier.height(5.dp)); Text(peer.name, color = MainText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(15.dp)).background(Surface1).padding(horizontal = 13.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, contentDescription = null, tint = MutedText, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(9.dp))
            BasicTextField(value = search, onValueChange = { search = it }, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp), cursorBrush = SolidColor(Orange), singleLine = true, decorationBox = { inner -> Box { if (search.isEmpty()) Text("Buscar chats o números", color = MutedText, fontSize = 14.sp); inner() } })
            IconButton(onClick = { showRouteHelp = !showRouteHelp }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Info, contentDescription = "Información de las rutas", tint = Orange, modifier = Modifier.size(18.dp)) }
        }
        AnimatedVisibility(showRouteHelp, enter = fadeIn() + slideInVertically { -it / 4 }, exit = fadeOut()) {
            Text("Desliza una conversación horizontalmente para alternar su ruta: Automática → Bluetooth → SMS. Mantén pulsada una conversación para abrirla.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
        }
        Spacer(Modifier.height(13.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("MENSAJES", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.weight(1f))
            Text("${filtered.size}", color = MutedText, fontSize = 11.sp)
        }
        Spacer(Modifier.height(4.dp))
        if (filtered.isEmpty()) EmptyChats(onFindPeople = onCreateChat, hasSearch = search.isNotBlank(), onNewSms = onNewSms)
        else LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            items(filtered, key = { it.id }) { chat -> ChatRow(chat, onClick = { onOpenChat(chat) }, onSwipe = { onSwipeRoute(chat) }, onLongClick = { onLongRoute(chat) }) }
        }
    }
}

@Composable
private fun EmptyChats(onFindPeople: () -> Unit, hasSearch: Boolean, onNewSms: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(78.dp).clip(RoundedCornerShape(27.dp)).background(Surface1), contentAlignment = Alignment.Center) {
            Icon(if (hasSearch) Icons.Default.Search else Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Orange, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(17.dp))
        Text(if (hasSearch) "Sin resultados" else "Tu bandeja está vacía", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text(if (hasSearch) "Prueba con otro nombre o número." else "Descubre personas cercanas por Bluetooth o comienza una conversación SMS.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onFindPeople, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Icon(Icons.Default.BluetoothSearching, contentDescription = null); Spacer(Modifier.width(7.dp)); Text("Encontrar personas") }
        TextButton(onClick = onNewSms) { Text("Nuevo chat por SMS", color = Orange) }
    }
}

@Composable
private fun ChatRow(chat: ChatEntity, onClick: () -> Unit, onSwipe: () -> Unit, onLongClick: () -> Unit) {
    var drag by remember(chat.id) { mutableStateOf(0f) }
    Row(
        Modifier.fillMaxWidth()
            .pointerInput(chat.id, chat.route) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = { if (abs(drag) > 85f) onSwipe(); drag = 0f }
                )
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .animateContentSize()
            .padding(horizontal = 19.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(chat.title, 55, false)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.title, color = MainText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(formatTime(chat.updatedAt), color = MutedText, fontSize = 10.sp)
            }
            Text(chat.lastMessage, color = MutedText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                RouteChip(chat.route)
                if (chat.recipientPhone.isNullOrBlank() && !chat.peerId.startsWith("sms:")) {
                    Icon(Icons.Default.Lock, contentDescription = "Número privado o no compartido", tint = MutedText, modifier = Modifier.size(12.dp))
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color(0xFF5F5F65), modifier = Modifier.size(16.dp))
    }
    Divider(color = DividerColor, modifier = Modifier.padding(start = 87.dp))
}

@Composable
private fun RouteChip(route: String) {
    val text = when (route) { "MESH" -> "BLUETOOTH"; "SMS" -> "SMS"; else -> "AUTO" }
    val icon = when (route) { "MESH" -> Icons.Default.Bluetooth; "SMS" -> Icons.Default.Sms; else -> Icons.Default.Refresh }
    Row(Modifier.clip(RoundedCornerShape(7.dp)).background(Surface1).padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(11.dp))
        Text(text, color = MutedText, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun PeopleScreen(
    peers: List<NearbyPeer>, requests: List<PendingRequest>, accepted: (String) -> Boolean,
    onPeerClick: (NearbyPeer) -> Unit, onAccept: (PendingRequest) -> Unit, onReject: (PendingRequest) -> Unit,
    onRefresh: () -> Unit, onPermissionClick: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = peers.filter { it.name.contains(search, true) || it.phone.contains(search, true) || it.bio.contains(search, true) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 14.dp, top = 18.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Personas", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
                Text("Descubrimiento cercano", color = MutedText, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "Volver a buscar", tint = Orange) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(17.dp)).background(Surface1).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF142D26)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Green, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Bluetooth Mesh", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("Sin Internet ni servicio móvil", color = MutedText, fontSize = 12.sp)
            }
            Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
        }
        if (requests.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text("SOLICITUDES DE CHAT · ${requests.size}", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, modifier = Modifier.padding(horizontal = 22.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 180.dp)) {
                items(requests, key = { it.id }) { request ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).clip(RoundedCornerShape(15.dp)).background(Surface1).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(request.name, 42, true); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(request.name, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Quiere iniciar un chat", color = MutedText, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onReject(request) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Close, contentDescription = "Rechazar", tint = MutedText) }
                        IconButton(onClick = { onAccept(request) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Check, contentDescription = "Aceptar", tint = Green) }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedText) }, placeholder = { Text("Buscar personas cercanas") }, singleLine = true, shape = RoundedCornerShape(15.dp), colors = fieldColors())
        Spacer(Modifier.height(16.dp))
        Text("CERCA DE TI", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 5.dp))
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.BluetoothSearching, contentDescription = null, tint = MutedText, modifier = Modifier.size(43.dp))
                Spacer(Modifier.height(12.dp))
                Text(if (search.isBlank()) "Buscando dispositivos" else "No hay coincidencias", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Ambos teléfonos deben tener ẞetaChat activo y Bluetooth habilitado. La presencia cercana no significa que el chat esté aceptado.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
                Spacer(Modifier.height(14.dp))
                TextButton(onClick = onPermissionClick) { Text("Revisar permisos", color = Orange) }
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.id }) { peer ->
                Row(Modifier.fillMaxWidth().clickable { onPeerClick(peer) }.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(peer.name, 52, true); Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(peer.name, color = MainText, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (peer.phone.isNotBlank()) peer.phone else peer.bio.ifBlank { "ID ${peer.id.take(8)}… · Bluetooth" }, color = MutedText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (peer.phone.isNotBlank() && peer.bio.isNotBlank()) Text(peer.bio, color = MutedText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    TextButton(onClick = { onPeerClick(peer) }) { Text(if (accepted(peer.id)) "Abrir" else "Solicitar", color = Orange, fontWeight = FontWeight.SemiBold) }
                }
                Divider(color = DividerColor, modifier = Modifier.padding(start = 85.dp))
            }
        }
    }
}

@Composable
private fun CallsScreen() {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(Surface1), contentAlignment = Alignment.Center) { Icon(Icons.Default.Call, contentDescription = null, tint = Orange, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.height(18.dp)); Text("Llamadas", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp)); Text("Las llamadas de voz todavía no están implementadas. Esta sección se conserva para una fase posterior.", color = MutedText, fontSize = 14.sp, lineHeight = 21.sp)
    }
}

@Composable
private fun SettingsScreen(
    nickname: String, phone: String, bio: String, phonePublic: Boolean, photoUri: String,
    onNicknameChange: (String) -> Unit, onPhoneChange: (String) -> Unit, onBioChange: (String) -> Unit,
    onPhonePublicChange: (Boolean) -> Unit, onChoosePhoto: () -> Unit, onSave: () -> Unit,
    onRestartMesh: () -> Unit, onSmsPermission: () -> Unit, onDefaultSms: () -> Unit
) {
    var showSmsRoleWarning by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 17.dp)) {
        Text("Ajustes", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(19.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box { ProfilePhoto(photoUri, nickname, 66); Box(Modifier.align(Alignment.BottomEnd).clip(CircleShape).background(Orange).size(22.dp).clickable(onClick = onChoosePhoto), contentAlignment = Alignment.Center) { Icon(Icons.Default.Edit, contentDescription = "Cambiar foto", tint = Color.Black, modifier = Modifier.size(13.dp)) } }
            Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
                Text(nickname.ifBlank { "Usuario" }, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(if (phonePublic && phone.isNotBlank()) "Número visible para usuarios cercanos" else "Número oculto en el descubrimiento", color = MutedText, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(22.dp)); Text("TU PERFIL", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = nickname, onValueChange = { onNicknameChange(it.take(32)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Apodo") }, singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(value = phone, onValueChange = { onPhoneChange(it.take(24)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Número telefónico") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), colors = fieldColors())
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(value = bio, onValueChange = { onBioChange(it.take(160)) }, modifier = Modifier.fillMaxWidth(), label = { Text("Biografía") }, minLines = 1, maxLines = 3, colors = fieldColors())
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface1).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (phonePublic) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Orange)
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
                Text("Número público", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(if (phonePublic) "Se anuncia a usuarios Bluetooth cercanos." else "No se incluye en tu anuncio Bluetooth.", color = MutedText, fontSize = 10.sp)
            }
            Switch(checked = phonePublic, onCheckedChange = onPhonePublicChange)
        }
        Spacer(Modifier.height(11.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) { Icon(Icons.Default.Check, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Guardar perfil", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(19.dp)); Text("PRIVACIDAD Y CONEXIÓN", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        SettingInfoRow(Icons.Default.Shield, "Identidad Mesh", "Claves locales; mensajes Bluetooth cifrados y firmados")
        SettingInfoRow(Icons.Default.Sms, "SMS tradicionales", "Pasan por el operador y no ofrecen cifrado E2E")
        TextButton(onClick = onSmsPermission) { Icon(Icons.Default.Sms, contentDescription = null, tint = Orange); Spacer(Modifier.width(7.dp)); Text("Autorizar envío SMS", color = Orange) }
        TextButton(onClick = { showSmsRoleWarning = true }) { Icon(Icons.Default.Phone, contentDescription = null, tint = Orange); Spacer(Modifier.width(7.dp)); Text("Solicitar app SMS predeterminada", color = Orange) }
        TextButton(onClick = onRestartMesh) { Icon(Icons.Default.Refresh, contentDescription = null, tint = Orange); Spacer(Modifier.width(7.dp)); Text("Reiniciar búsqueda Bluetooth", color = Orange) }
        Spacer(Modifier.height(12.dp))
        Text("ẞetaChat 0.2.0 · Híbrido experimental", color = MutedText, fontSize = 11.sp)
        Text("Las funciones de telefonía y Mesh deben probarse en dispositivos reales.", color = MutedText, fontSize = 10.sp)
    }
    if (showSmsRoleWarning) {
        AlertDialog(
            onDismissRequest = { showSmsRoleWarning = false }, containerColor = Surface1,
            title = { Text("SMS predeterminado experimental", color = MainText) },
            text = { Text("ẞetaChat envía y guarda SMS de texto, pero MMS (fotos y medios por la red móvil) todavía no está implementado. Si dependes de MMS, no cambies la aplicación SMS predeterminada todavía.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp) },
            confirmButton = { TextButton(onClick = { showSmsRoleWarning = false; onDefaultSms() }) { Text("Continuar", color = Orange) } },
            dismissButton = { TextButton(onClick = { showSmsRoleWarning = false }) { Text("Cancelar", color = MutedText) } }
        )
    }
}

@Composable
private fun SettingInfoRow(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(12.dp)).background(Surface1), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.width(11.dp)); Column { Text(title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.Medium); Text(subtitle, color = MutedText, fontSize = 10.sp) }
    }
}

@Composable
private fun ChatScreen(chat: ChatEntity, myNickname: String, nearby: Boolean, accepted: Boolean, viewModel: ChatViewModel, onBack: () -> Unit, onRouteChange: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val messages by viewModel.messages(chat.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var input by remember { mutableStateOf("") }
    var queuedSmsText by remember { mutableStateOf<String?>(null) }
    var showRouteDialog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val requestSms = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val text = queuedSmsText
        queuedSmsText = null
        if (granted && !text.isNullOrBlank()) viewModel.sendMessage(chat, text, myNickname, chat.route, nearby)
        else if (!granted) Toast.makeText(context, "Autoriza SMS para enviar por la red móvil.", Toast.LENGTH_LONG).show()
        if (granted && !text.isNullOrBlank()) input = ""
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    fun sendCurrent() {
        if (input.isBlank()) return
        if (viewModel.willUseSms(chat, chat.route, nearby) && !viewModel.canUseSms(chat)) {
            Toast.makeText(context, "Este perfil no ha compartido su número. Pídele que lo comparta o crea un chat SMS con el número.", Toast.LENGTH_LONG).show()
            return
        }
        if (viewModel.willUseSms(chat, chat.route, nearby) && ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            queuedSmsText = input.trim()
            requestSms.launch(Manifest.permission.SEND_SMS)
        } else {
            if (chat.route == "MESH" && !accepted) {
                Toast.makeText(context, "Debes tener una solicitud de chat aceptada para usar Bluetooth.", Toast.LENGTH_LONG).show()
                return
            }
            viewModel.sendMessage(chat, input, myNickname, chat.route, nearby)
            input = ""
        }
    }
    if (showRouteDialog) {
        AlertDialog(onDismissRequest = { showRouteDialog = false }, containerColor = Surface1,
            title = { Text("Ruta de la conversación", color = MainText) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Automática elige Bluetooth si la persona está cerca y aceptó el chat; si no, usa SMS cuando existe un número disponible.", color = MutedText, fontSize = 12.sp)
                listOf("AUTO" to "Automática", "MESH" to "Solo Bluetooth", "SMS" to "Solo SMS").forEach { (route, label) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (chat.route == route) Color(0xFF392416) else Surface2).clickable { onRouteChange(route); showRouteDialog = false }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, color = if (chat.route == route) Orange else MainText, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        if (chat.route == route) Icon(Icons.Default.Check, contentDescription = null, tint = Orange)
                    }
                }
            } }, confirmButton = { TextButton(onClick = { showRouteDialog = false }) { Text("Cerrar", color = MutedText) } })
    }
    Column(Modifier.fillMaxSize().background(Bg).pointerInput(chat.id) {
        var drag = 0f
        detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = { if (drag > 100f) onBack(); drag = 0f })
    }) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 11.dp, top = 7.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = MainText) }
            Avatar(chat.title, 42, false); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.title, color = MainText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(when (chat.route) { "SMS" -> "SMS · Red del operador"; "MESH" -> if (nearby) "Bluetooth · ${if (accepted) "Chat aceptado" else "Sin aceptación"}" else "Bluetooth · Sin conexión cercana"; else -> if (nearby && accepted) "Cerca · Bluetooth disponible" else if (!chat.recipientPhone.isNullOrBlank()) "A distancia · SMS disponible" else "Sin número SMS compartido" }, color = if (chat.route == "SMS") Orange else if (nearby && accepted) Green else MutedText, fontSize = 10.sp)
            }
            IconButton(onClick = { showRouteDialog = true }) { Icon(Icons.Default.Refresh, contentDescription = "Cambiar ruta", tint = Orange) }
            Icon(Icons.Default.Shield, contentDescription = "Identidad Mesh", tint = Orange, modifier = Modifier.size(19.dp))
        }
        Divider(color = DividerColor)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("AUTO", "MESH", "SMS").forEach { route ->
                val selected = chat.route == route
                Surface(shape = RoundedCornerShape(10.dp), color = if (selected) Color(0xFF3A2416) else Surface1, border = if (selected) BorderStroke(1.dp, Orange.copy(alpha = 0.65f)) else null, modifier = Modifier.clickable { onRouteChange(route) }) {
                    Text(routeLabel(route), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = if (selected) Orange else MutedText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (chat.recipientPhone.isNullOrBlank() && !chat.peerId.startsWith("sms:")) Text("Número privado", color = MutedText, fontSize = 10.sp, modifier = Modifier.padding(vertical = 7.dp))
        }
        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(68.dp).clip(RoundedCornerShape(24.dp)).background(Surface1), contentAlignment = Alignment.Center) { Icon(if (chat.id.startsWith("sms:")) Icons.Default.Sms else Icons.Default.Shield, contentDescription = null, tint = Orange, modifier = Modifier.size(31.dp)) }
                Spacer(Modifier.height(12.dp)); Text(if (chat.id.startsWith("sms:")) "Conversación SMS" else "Conversación protegida", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp)); Text(if (chat.id.startsWith("sms:")) "Los mensajes SMS pasan por tu operador. No requieren Internet, pero sí servicio móvil compatible." else "Los mensajes Bluetooth están cifrados. La persona debe aceptar tu solicitud antes de conversar.", color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { message -> MessageBubble(message, onLongClick = {
                clipboard.setText(AnnotatedString(message.text)); Toast.makeText(context, "Mensaje copiado.", Toast.LENGTH_SHORT).show()
            }) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 8.dp).navigationPaddingCompat(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Surface2).padding(horizontal = 16.dp, vertical = 13.dp)) {
                BasicTextField(value = input, onValueChange = { input = it.take(1000) }, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp), cursorBrush = SolidColor(Orange), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { sendCurrent() }), decorationBox = { inner -> Box { if (input.isEmpty()) Text("Mensaje", color = MutedText, fontSize = 15.sp); inner() } })
            }
            IconButton(onClick = { sendCurrent() }, modifier = Modifier.size(48.dp).clip(CircleShape).background(Orange)) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.Black, modifier = Modifier.size(22.dp)) }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageEntity, onLongClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.outgoing) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 292.dp).combinedClickable(onClick = {}, onLongClick = onLongClick).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (message.outgoing) 18.dp else 5.dp, bottomEnd = if (message.outgoing) 5.dp else 18.dp)).background(if (message.outgoing) Color(0xFF4E2B19) else Surface1).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(message.text, color = MainText, fontSize = 15.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.align(Alignment.End)) {
                Icon(if (message.transport == "SMS") Icons.Default.Sms else Icons.Default.Bluetooth, contentDescription = if (message.transport == "SMS") "SMS" else "Bluetooth", tint = MutedText, modifier = Modifier.size(11.dp))
                Text(formatTime(message.timestamp), color = MutedText, fontSize = 9.sp)
                if (message.outgoing) Text(when (message.status) { "failed" -> "!"; "delivered" -> "✓✓"; "sent" -> "✓"; else -> "◷" }, color = if (message.status == "failed") Color(0xFFFF7A76) else MutedText, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun PhotoCropDialog(
    sourceUri: Uri,
    onDismiss: () -> Unit,
    onUsePhoto: (zoom: Float, panX: Float, panY: Float, viewportPx: Float) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val viewportPx = with(density) { 260.dp.toPx() }
    var bitmap by remember(sourceUri) { mutableStateOf<Bitmap?>(null) }
    var zoom by remember(sourceUri) { mutableStateOf(1f) }
    var panX by remember(sourceUri) { mutableStateOf(0f) }
    var panY by remember(sourceUri) { mutableStateOf(0f) }
    var loading by remember(sourceUri) { mutableStateOf(true) }

    LaunchedEffect(sourceUri) {
        loading = true
        bitmap = withContext(Dispatchers.IO) { decodeProfileImage(context, sourceUri) }
        loading = false
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFF171719),
            border = BorderStroke(1.dp, Color(0xFF343438)),
            tonalElevation = 8.dp
        ) {
            Column(
                Modifier.padding(horizontal = 22.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Ajustar foto", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Arrastra para centrar y pellizca para acercar.", color = MutedText, fontSize = 12.sp)
                Box(
                    Modifier.size(260.dp).shadow(15.dp, CircleShape, clip = false)
                        .clip(CircleShape).background(Color(0xFF242428))
                        .border(2.dp, Brush.linearGradient(listOf(Color(0xFFFFD5A5), Orange, Color(0xFF9B3B08))), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val image = bitmap
                    if (image != null) {
                        Image(
                            bitmap = image.asImageBitmap(),
                            contentDescription = "Vista previa de recorte de perfil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                                .graphicsLayer {
                                    scaleX = zoom
                                    scaleY = zoom
                                    translationX = panX
                                    translationY = panY
                                }
                                .pointerInput(image) {
                                    detectTransformGestures { _, pan, zoomChange, _ ->
                                        val nextZoom = (zoom * zoomChange).coerceIn(1f, 4f)
                                        zoom = nextZoom
                                        val baseScale = maxOf(viewportPx / image.width, viewportPx / image.height)
                                        val maxOffsetX = (image.width * baseScale * nextZoom - viewportPx).coerceAtLeast(0f) / 2f
                                        val maxOffsetY = (image.height * baseScale * nextZoom - viewportPx).coerceAtLeast(0f) / 2f
                                        panX = (panX + pan.x).coerceIn(-maxOffsetX, maxOffsetX)
                                        panY = (panY + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                                    }
                                }
                        )
                    } else {
                        Text(if (loading) "Cargando foto…" else "No se pudo abrir la imagen", color = MutedText, fontSize = 12.sp)
                    }
                }
                Text("La foto se guardará en formato cuadrado y se mostrará dentro del círculo.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancelar", color = MutedText)
                    }
                    Button(
                        onClick = { if (bitmap != null && !loading) onUsePhoto(zoom, panX, panY, viewportPx) },
                        enabled = bitmap != null && !loading,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                    ) {
                        Text("Usar foto", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun decodeProfileImage(context: Context, uri: Uri): Bitmap? {
    return runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 2048) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }.getOrNull()
}

private fun cropAndSaveProfilePhoto(
    context: Context,
    uri: Uri,
    zoom: Float,
    panX: Float,
    panY: Float,
    viewportPx: Float
): Uri? {
    return runCatching {
        val source = decodeProfileImage(context, uri) ?: return null
        val baseScale = maxOf(viewportPx / source.width, viewportPx / source.height)
        val effectiveScale = baseScale * zoom.coerceIn(1f, 4f)
        val side = (viewportPx / effectiveScale).toInt().coerceIn(1, minOf(source.width, source.height))
        val centerX = source.width / 2f - panX / effectiveScale
        val centerY = source.height / 2f - panY / effectiveScale
        val left = (centerX - side / 2f).toInt().coerceIn(0, source.width - side)
        val top = (centerY - side / 2f).toInt().coerceIn(0, source.height - side)
        val cropped = Bitmap.createBitmap(source, left, top, side, side)
        val output = if (cropped.width > 512) Bitmap.createScaledBitmap(cropped, 512, 512, true) else cropped
        val file = java.io.File(context.filesDir, "profile_avatar.jpg")
        file.outputStream().use { output.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (output !== cropped) output.recycle()
        if (cropped !== source) cropped.recycle()
        if (!source.isRecycled) source.recycle()
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
private fun ProfilePhoto(uri: String, name: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(avatarColor(name)), contentAlignment = Alignment.Center) {
        if (uri.isNotBlank()) AsyncImage(model = uri, contentDescription = "Foto de perfil", modifier = Modifier.fillMaxSize().clip(CircleShape))
        else Text(initials(name), color = Color.White, fontSize = (size / 3.2f).sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Avatar(name: String, size: Int, outlined: Boolean) {
    Box(Modifier.size(size.dp).then(if (outlined) Modifier.border(2.dp, Orange, CircleShape).padding(3.dp) else Modifier).clip(CircleShape).background(avatarColor(name)), contentAlignment = Alignment.Center) {
        Text(initials(name), color = Color.White, fontSize = (size / 3.2f).sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun initials(name: String) = name.trim().split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("").ifBlank { "?" }
private fun avatarColor(name: String): Color {
    val palette = listOf(Color(0xFF31434D), Color(0xFF40334D), Color(0xFF4B3829), Color(0xFF2E4940), Color(0xFF353D57), Color(0xFF4C3438))
    return palette[(name.hashCode().ushr(1) % palette.size).coerceAtLeast(0)]
}

@Composable
private fun BottomBar(selected: AppTab, onSelect: (AppTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF050506))
            .border(BorderStroke(1.dp, Color(0xFF19191D)))
            .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 9.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = selected == tab
            val scale by animateFloatAsState(if (isSelected) 1.04f else 1f, animationSpec = tween(220), label = "nav-scale")
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { onSelect(tab) }
                    .padding(vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    Modifier.size(44.dp).scale(scale)
                        .then(if (isSelected) Modifier.shadow(11.dp, CircleShape, clip = false) else Modifier)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) Brush.radialGradient(
                                colors = listOf(Color(0xFFFFD39D), Color(0xFFF47721), Color(0xFF783207)),
                                radius = 90f
                            ) else Brush.radialGradient(listOf(Color(0xFF151518), Color.Transparent))
                        )
                        .then(
                            if (isSelected) Modifier.border(
                                1.dp,
                                Brush.linearGradient(listOf(Color(0xFFFFE5C4), Color(0xFFB64B12), Color(0xFFFFB76D))),
                                CircleShape
                            ) else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Box(
                            Modifier.align(Alignment.TopCenter).padding(top = 4.dp)
                                .size(width = 15.dp, height = 2.dp).clip(CircleShape)
                                .background(Color(0xFFFFE9CE))
                        )
                    }
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        tint = if (isSelected) Color(0xFFFFF5E9) else Color(0xFF85858D),
                        modifier = Modifier.size(if (isSelected) 24.dp else 23.dp)
                            .graphicsLayer { shadowElevation = if (isSelected) 2.dp.toPx() else 0f }
                    )
                }
                Text(
                    tab.label,
                    color = if (isSelected) Color(0xFFFFAA61) else Color(0xFF85858D),
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Orange,
    focusedLabelColor = Orange,
    cursorColor = Orange,
    focusedTextColor = MainText,
    unfocusedTextColor = MainText,
    unfocusedBorderColor = Color(0xFF3A3A3F),
    focusedPlaceholderColor = MutedText,
    unfocusedPlaceholderColor = MutedText
)

private fun routeLabel(route: String): String = when (route) { "MESH" -> "Bluetooth"; "SMS" -> "SMS"; else -> "Automática" }
private fun formatTime(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
private fun Modifier.navigationPaddingCompat(): Modifier = this.padding(bottom = 0.dp)
