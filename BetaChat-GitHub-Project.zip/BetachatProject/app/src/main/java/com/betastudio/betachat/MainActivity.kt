package com.betastudio.betachat

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF080809)
private val Surface1 = Color(0xFF1C1C1E)
private val Surface2 = Color(0xFF29292C)
private val Orange = Color(0xFFF47721)
private val MainText = Color(0xFFF4F4F5)
private val MutedText = Color(0xFF9B9BA1)
private val DividerColor = Color(0xFF242427)

class MainActivity : ComponentActivity() {
    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = android.graphics.Color.rgb(8, 8, 9)
        window.navigationBarColor = android.graphics.Color.BLACK
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Orange,
                onPrimary = Color.Black,
                background = Bg,
                onBackground = MainText,
                surface = Surface1,
                onSurface = MainText,
                secondary = Orange
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    BetaChatApp(chatViewModel)
                }
            }
        }
    }
}

private data class NearbyPeer(val id: String, val name: String)
private enum class AppTab(val label: String, val icon: ImageVector) {
    PEOPLE("Personas", Icons.Default.Groups),
    CALLS("Llamadas", Icons.Default.Call),
    CHATS("Chats", Icons.Default.ChatBubbleOutline),
    SETTINGS("Ajustes", Icons.Default.Settings)
}

@Composable
private fun BetaChatApp(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profilePrefs = remember { context.getSharedPreferences("betachat_profile", Context.MODE_PRIVATE) }
    var nickname by remember { mutableStateOf(profilePrefs.getString("nickname", "Usuario") ?: "Usuario") }
    val peers = remember { mutableStateMapOf<String, NearbyPeer>() }
    var currentTab by remember { mutableStateOf(AppTab.CHATS) }
    var openedChat by remember { mutableStateOf<ChatEntity?>(null) }
    val chatList by viewModel.chats.collectAsStateWithLifecycle()

    val requestPermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val btGranted = bluetoothPermissions(context).all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (btGranted) startMeshService(context) else Toast.makeText(context, "Permite el acceso a dispositivos cercanos para activar ẞetaChat.", Toast.LENGTH_LONG).show()
    }

    LaunchedEffect(Unit) {
        val needed = runtimePermissions(context).filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) startMeshService(context) else requestPermissions.launch(needed.toTypedArray())
    }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == MeshBleService.ACTION_PEER) {
                    val id = intent.getStringExtra(MeshBleService.EXTRA_PEER_ID).orEmpty()
                    val name = intent.getStringExtra(MeshBleService.EXTRA_PEER_NAME).orEmpty()
                    if (id.isNotBlank()) peers[id] = NearbyPeer(id, name.ifBlank { "Usuario" })
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter(MeshBleService.ACTION_PEER), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    LaunchedEffect(openedChat?.id) { openedChat?.let { viewModel.markRead(it.id) } }

    if (openedChat != null) {
        ChatScreen(
            chat = openedChat!!,
            myNickname = nickname,
            viewModel = viewModel,
            onBack = { openedChat = null }
        )
        return
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.weight(1f)) {
            when (currentTab) {
                AppTab.CHATS -> ChatsScreen(
                    chats = chatList,
                    peers = peers.values.toList().sortedBy { it.name.lowercase() },
                    nickname = nickname,
                    onOpenChat = { openedChat = it },
                    onPeerClick = { peer ->
                        scope.launch {
                            openedChat = viewModel.ensureChat(peer.id, peer.name)
                            currentTab = AppTab.CHATS
                        }
                    },
                    onCreateChat = { currentTab = AppTab.PEOPLE }
                )
                AppTab.PEOPLE -> PeopleScreen(
                    peers = peers.values.toList().sortedBy { it.name.lowercase() },
                    onPeerClick = { peer ->
                        scope.launch {
                            openedChat = viewModel.ensureChat(peer.id, peer.name)
                            currentTab = AppTab.CHATS
                        }
                    },
                    onRefresh = { startMeshService(context) },
                    onPermissionClick = { requestPermissions.launch(runtimePermissions(context).toTypedArray()) }
                )
                AppTab.CALLS -> CallsScreen()
                AppTab.SETTINGS -> SettingsScreen(
                    nickname = nickname,
                    onNicknameChange = { nickname = it },
                    onSave = {
                        val saved = nickname.trim().ifBlank { "Usuario" }.take(32)
                        nickname = saved
                        profilePrefs.edit().putString("nickname", saved).apply()
                        val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_PROFILE)
                        runCatching { ContextCompat.startForegroundService(context, intent) }
                        Toast.makeText(context, "Perfil guardado", Toast.LENGTH_SHORT).show()
                    },
                    onRestartMesh = { startMeshService(context) }
                )
            }
        }
        BottomBar(selected = currentTab, onSelect = { currentTab = it })
    }
}

private fun bluetoothPermissions(context: Context): List<String> = if (Build.VERSION.SDK_INT >= 31) {
    listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
} else {
    listOf(Manifest.permission.ACCESS_FINE_LOCATION)
}

private fun runtimePermissions(context: Context): List<String> = buildList {
    addAll(bluetoothPermissions(context))
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.distinct()

private fun startMeshService(context: Context) {
    val intent = Intent(context, MeshBleService::class.java).setAction(MeshBleService.ACTION_START)
    runCatching { ContextCompat.startForegroundService(context, intent) }
        .onFailure { Toast.makeText(context, "No se pudo iniciar Bluetooth. Comprueba los permisos y que Bluetooth esté activado.", Toast.LENGTH_LONG).show() }
}

@Composable
private fun ChatsScreen(
    chats: List<ChatEntity>,
    peers: List<NearbyPeer>,
    nickname: String,
    onOpenChat: (ChatEntity) -> Unit,
    onPeerClick: (NearbyPeer) -> Unit,
    onCreateChat: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = chats.filter { it.title.contains(search, true) || it.lastMessage.contains(search, true) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 23.dp, end = 16.dp, top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Messages", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp)
            IconButton(onClick = onCreateChat, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Nuevo chat", tint = Orange, modifier = Modifier.size(25.dp))
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(Modifier.width(70.dp).clickable(onClick = onCreateChat), horizontalAlignment = Alignment.CenterHorizontally) {
                Box {
                    Avatar(nickname, 60, false)
                    Box(Modifier.align(Alignment.BottomEnd).size(23.dp).clip(CircleShape).background(Orange).border(2.dp, Bg, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Tu perfil", color = MainText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            peers.take(12).forEach { peer ->
                Column(Modifier.width(70.dp).clickable { onPeerClick(peer) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(peer.name, 60, true)
                    Spacer(Modifier.height(6.dp))
                    Text(peer.name, color = MainText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(54.dp).clip(RoundedCornerShape(19.dp)).background(Surface2).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = MutedText, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            BasicTextField(
                value = search,
                onValueChange = { search = it },
                singleLine = true,
                cursorBrush = SolidColor(Orange),
                textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 16.sp),
                decorationBox = { inner -> Box { if (search.isEmpty()) Text("Search", color = MutedText, fontSize = 16.sp); inner() } },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(18.dp))
        if (filtered.isEmpty()) {
            EmptyChats(onFindPeople = onCreateChat, hasSearch = search.isNotBlank())
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                items(filtered, key = { it.id }) { chat -> ChatRow(chat, onClick = { onOpenChat(chat) }) }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}

@Composable
private fun EmptyChats(onFindPeople: () -> Unit, hasSearch: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(Surface1), contentAlignment = Alignment.Center) {
            Icon(if (hasSearch) Icons.Default.Search else Icons.Default.BluetoothSearching, contentDescription = null, tint = Orange, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(if (hasSearch) "No se encontraron chats" else "Tu red empieza aquí", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text(
            if (hasSearch) "Prueba con otro nombre o mensaje." else "Busca personas cercanas por Bluetooth y empieza una conversación sin Internet.",
            color = MutedText, fontSize = 14.sp, lineHeight = 20.sp
        )
        if (!hasSearch) {
            Spacer(Modifier.height(18.dp))
            Button(onClick = onFindPeople, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black), shape = RoundedCornerShape(14.dp)) {
                Text("Buscar personas", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun ChatRow(chat: ChatEntity, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(chat.title, 62, false)
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(chat.title, color = MainText, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text(chat.lastMessage.ifBlank { "Inicia una conversación" }, color = MutedText, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(formatTime(chat.updatedAt), color = MutedText, fontSize = 12.sp)
            if (chat.unreadCount > 0) {
                Box(Modifier.size(23.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) {
                    Text(chat.unreadCount.coerceAtMost(99).toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    Divider(color = DividerColor, thickness = 0.7.dp, modifier = Modifier.padding(start = 94.dp))
}

@Composable
private fun PeopleScreen(
    peers: List<NearbyPeer>,
    onPeerClick: (NearbyPeer) -> Unit,
    onRefresh: () -> Unit,
    onPermissionClick: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 23.dp, end = 16.dp, top = 20.dp, bottom = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Personas", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                Text("Dispositivos cercanos", color = MutedText, fontSize = 13.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "Reiniciar búsqueda", tint = Orange) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(17.dp)).background(Surface1).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF142D26)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Color(0xFF71D6AD), modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Red local Bluetooth", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("Sin Internet ni número telefónico", color = MutedText, fontSize = 12.sp)
            }
            Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF71D6AD)))
        }
        Spacer(Modifier.height(18.dp))
        Text("DISPONIBLES", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp))
        if (peers.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.BluetoothSearching, contentDescription = null, tint = MutedText, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text("Buscando dispositivos", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Para que alguien aparezca, debe tener ẞetaChat abierto o activo y Bluetooth habilitado.", color = MutedText, fontSize = 14.sp, lineHeight = 20.sp)
                Spacer(Modifier.height(16.dp))
                TextButton(onClick = onPermissionClick) { Text("Revisar permisos", color = Orange) }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(peers, key = { it.id }) { peer ->
                    Row(Modifier.fillMaxWidth().clickable { onPeerClick(peer) }.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(peer.name, 52, true)
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(peer.name, color = MainText, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text("ID ${peer.id.take(8)}… · Detectado por Bluetooth", color = MutedText, fontSize = 12.sp)
                        }
                        TextButton(onClick = { onPeerClick(peer) }) { Text("Chatear", color = Orange) }
                    }
                    Divider(color = DividerColor, modifier = Modifier.padding(start = 85.dp))
                }
            }
        }
    }
}

@Composable
private fun CallsScreen() {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(Surface1), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Call, contentDescription = null, tint = Orange, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("Llamadas", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("La pestaña está preparada, pero las llamadas de voz todavía no están implementadas. Primero estamos estabilizando los mensajes Bluetooth y la red mesh.", color = MutedText, fontSize = 14.sp, lineHeight = 21.sp)
    }
}

@Composable
private fun SettingsScreen(nickname: String, onNicknameChange: (String) -> Unit, onSave: () -> Unit, onRestartMesh: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp)) {
        Text("Ajustes", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(nickname, 64, false)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(nickname.ifBlank { "Usuario" }, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Perfil local · Sin número telefónico", color = MutedText, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(26.dp))
        Text("TU PERFIL", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = nickname,
            onValueChange = onNicknameChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Apodo") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Guardar perfil", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(28.dp))
        Text("PRIVACIDAD Y CONEXIÓN", color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(10.dp))
        SettingInfoRow(Icons.Default.Shield, "Cifrado de extremo a extremo", "Claves locales y mensajes cifrados")
        SettingInfoRow(Icons.Default.Bluetooth, "Red Bluetooth", "Descubrimiento y retransmisión local")
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onRestartMesh) { Icon(Icons.Default.Refresh, contentDescription = null, tint = Orange); Spacer(Modifier.width(8.dp)); Text("Reiniciar búsqueda Bluetooth", color = Orange) }
        Spacer(Modifier.weight(1f))
        Text("ẞetaChat 0.1.0-alpha", color = MutedText, fontSize = 12.sp)
        Text("Mensajería local en desarrollo", color = MutedText, fontSize = 12.sp)
    }
}

@Composable
private fun SettingInfoRow(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Surface1), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = MainText, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = MutedText, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ChatScreen(chat: ChatEntity, myNickname: String, viewModel: ChatViewModel, onBack: () -> Unit) {
    val messages by viewModel.messages(chat.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 16.dp, top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = MainText) }
            Avatar(chat.title, 42, false)
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.title, color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Chat Bluetooth · Cifrado", color = Color(0xFF71D6AD), fontSize = 11.sp)
            }
            Icon(Icons.Default.Shield, contentDescription = "Cifrado", tint = Orange, modifier = Modifier.size(21.dp))
        }
        Divider(color = DividerColor)
        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = Orange, modifier = Modifier.size(38.dp))
                Spacer(Modifier.height(12.dp))
                Text("Conversación protegida", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp))
                Text("Los mensajes se guardan en este teléfono. Para enviarlos, la otra persona debe estar accesible a través de la red mesh.", color = MutedText, fontSize = 13.sp, lineHeight = 19.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { message -> MessageBubble(message) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp).navigationPaddingCompat(),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Surface2).padding(horizontal = 16.dp, vertical = 13.dp)) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it.take(250) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp),
                    cursorBrush = SolidColor(Orange),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (input.isNotBlank()) { viewModel.sendMessage(chat, input, myNickname); input = "" }
                    }),
                    decorationBox = { inner -> Box { if (input.isEmpty()) Text("Mensaje", color = MutedText, fontSize = 15.sp); inner() } }
                )
            }
            IconButton(
                onClick = { if (input.isNotBlank()) { viewModel.sendMessage(chat, input, myNickname); input = "" } },
                modifier = Modifier.size(48.dp).clip(CircleShape).background(Orange)
            ) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.Black, modifier = Modifier.size(22.dp)) }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageEntity) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.outgoing) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 280.dp).clip(
                RoundedCornerShape(
                    topStart = 18.dp, topEnd = 18.dp,
                    bottomStart = if (message.outgoing) 18.dp else 5.dp,
                    bottomEnd = if (message.outgoing) 5.dp else 18.dp
                )
            ).background(if (message.outgoing) Color(0xFF4E2B19) else Surface1).padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(message.text, color = MainText, fontSize = 15.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(formatTime(message.timestamp) + if (message.outgoing && message.status == "pending") "  ◷" else if (message.outgoing) "  ✓" else "", color = MutedText, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
        }
    }
}

@Composable
private fun Avatar(name: String, size: Int, outlined: Boolean) {
    val palette = listOf(Color(0xFF31434D), Color(0xFF40334D), Color(0xFF4B3829), Color(0xFF2E4940), Color(0xFF353D57), Color(0xFF4C3438))
    val bg = palette[(name.hashCode().ushr(1) % palette.size).coerceAtLeast(0)]
    Box(
        Modifier.size(size.dp).then(if (outlined) Modifier.border(2.dp, Orange, CircleShape).padding(3.dp) else Modifier)
            .clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.trim().split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("").ifBlank { "?" },
            color = Color.White, fontSize = (size / 3.2f).sp, fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun BottomBar(selected: AppTab, onSelect: (AppTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color.Black).padding(start = 8.dp, end = 8.dp, top = 7.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = selected == tab
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).clickable { onSelect(tab) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Icon(tab.icon, contentDescription = tab.label, tint = if (isSelected) Orange else Color(0xFF77777D), modifier = Modifier.size(26.dp))
                Text(tab.label, color = if (isSelected) Orange else Color(0xFF77777D), fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

private fun formatTime(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

private fun Modifier.navigationPaddingCompat(): Modifier = this.padding(bottom = 0.dp)
