package com.betastudio.betachat.network

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import android.Manifest

/** Handles Android's respond-via-message intent when the user explicitly chooses ẞetaChat. */
class SmsRespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val destination = intent?.data?.schemeSpecificPart.orEmpty()
        val body = intent?.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty()
        if (destination.isNotBlank() && body.isNotBlank() &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            runCatching {
                @Suppress("DEPRECATION")
                val manager = if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                val parts = manager.divideMessage(body.take(1000))
                if (parts.size > 1) manager.sendMultipartTextMessage(destination, null, parts, null, null)
                else manager.sendTextMessage(destination, null, parts.firstOrNull().orEmpty(), null, null)
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
