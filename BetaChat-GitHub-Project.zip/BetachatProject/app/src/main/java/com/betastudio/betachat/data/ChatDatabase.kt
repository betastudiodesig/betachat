package com.betastudio.betachat.data

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val peerId: String,
    val title: String,
    val lastMessage: String,
    val updatedAt: Long,
    val unreadCount: Int = 0,
    @ColumnInfo(defaultValue = "'AUTO'") val route: String = "AUTO",
    @ColumnInfo(defaultValue = "NULL") val recipientPhone: String? = null
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val text: String,
    val timestamp: Long,
    val outgoing: Boolean,
    val status: String = "sent",
    @ColumnInfo(defaultValue = "'MESH'") val transport: String = "MESH",
    @ColumnInfo(defaultValue = "'TEXT'") val type: String = "TEXT",
    @ColumnInfo(defaultValue = "NULL") val attachmentPath: String? = null,
    @ColumnInfo(defaultValue = "NULL") val attachmentName: String? = null,
    @ColumnInfo(defaultValue = "NULL") val attachmentMimeType: String? = null
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY updatedAt DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE id = :id LIMIT 1")
    suspend fun findChat(id: String): ChatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChat(chat: ChatEntity)

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun observeMessages(chatId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE chatId = :chatId AND outgoing = 0 AND status != 'read'")
    suspend fun unreadIncoming(chatId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun findMessage(id: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE chatId = :peerId AND outgoing = 1 AND type = 'TEXT' AND status IN ('pending', 'sent') ORDER BY timestamp ASC")
    suspend fun pendingTextForPeer(peerId: String): List<MessageEntity>

    @Query("UPDATE chats SET lastMessage = :preview, updatedAt = :updatedAt WHERE id = :chatId")
    suspend fun updatePreview(chatId: String, preview: String, updatedAt: Long)

    @Query("UPDATE chats SET unreadCount = 0 WHERE id = :chatId")
    suspend fun clearUnread(chatId: String)

    @Query("UPDATE chats SET recipientPhone = :phone WHERE peerId = :peerId")
    suspend fun updateRecipientPhone(peerId: String, phone: String?)

    @Query("UPDATE messages SET status = :status WHERE id = :messageId")
    suspend fun updateMessageStatus(messageId: String, status: String)
}

@Database(entities = [ChatEntity::class, MessageEntity::class], version = 3, exportSchema = false)
abstract class ChatDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chats ADD COLUMN route TEXT NOT NULL DEFAULT 'AUTO'")
                db.execSQL("ALTER TABLE chats ADD COLUMN recipientPhone TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE messages ADD COLUMN transport TEXT NOT NULL DEFAULT 'MESH'")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE messages ADD COLUMN type TEXT NOT NULL DEFAULT 'TEXT'")
                db.execSQL("ALTER TABLE messages ADD COLUMN attachmentPath TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE messages ADD COLUMN attachmentName TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE messages ADD COLUMN attachmentMimeType TEXT DEFAULT NULL")
                db.execSQL("UPDATE chats SET route = 'MESH' WHERE route != 'MESH'")
                db.execSQL("DELETE FROM chats WHERE id LIKE 'sms:%'")
                db.execSQL("DELETE FROM messages WHERE chatId LIKE 'sms:%' OR transport = 'SMS'")
            }
        }

        @Volatile private var INSTANCE: ChatDatabase? = null
        fun get(context: Context): ChatDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ChatDatabase::class.java,
                "betachat-local.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}
