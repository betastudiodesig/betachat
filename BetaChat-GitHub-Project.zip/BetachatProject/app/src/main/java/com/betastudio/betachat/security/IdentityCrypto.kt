package com.betastudio.betachat.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Local ECDH + AES-GCM message encryption and ECDSA packet authentication.
 * The EC private key is stored encrypted by an AES key held in Android Keystore.
 */
class IdentityCrypto(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("betachat_identity", Context.MODE_PRIVATE)
    private val keyAlias = "betachat.identity.wrapper.v1"
    private val pair: KeyPair by lazy { loadOrCreatePair() }
    val publicKeyBase64: String by lazy { b64(pair.public.encoded) }
    val deviceId: String by lazy { idForPublicKey(pair.public.encoded) }

    fun helloPacket(nickname: String): JSONObject = JSONObject()
        .put("id", java.util.UUID.randomUUID().toString())
        .put("kind", "HELLO")
        .put("from", deviceId)
        .put("fromName", nickname.ifBlank { "Usuario" }.take(32))
        .put("pub", publicKeyBase64)
        .put("ttl", 6)

    fun createEncryptedChat(recipientId: String, recipientPublicBase64: String, nickname: String, text: String): JSONObject {
        val recipientPublic = decodePublic(recipientPublicBase64)
        require(idForPublicKey(recipientPublic.encoded) == recipientId) { "La identidad del destinatario no coincide." }
        val ivAndCipher = encryptFor(recipientPublic, text.toByteArray(Charsets.UTF_8))
        val id = java.util.UUID.randomUUID().toString()
        val packet = JSONObject()
            .put("id", id)
            .put("kind", "CHAT")
            .put("from", deviceId)
            .put("fromName", nickname.ifBlank { "Usuario" }.take(32))
            .put("to", recipientId)
            .put("ttl", 6)
            .put("iv", b64(ivAndCipher.first))
            .put("body", b64(ivAndCipher.second))
            .put("pub", publicKeyBase64)
        packet.put("sig", sign(canonical(packet)))
        return packet
    }

    fun verifyPacket(packet: JSONObject): Boolean = runCatching {
        if (packet.optString("kind") != "CHAT") return false
        val publicEncoded = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        if (idForPublicKey(publicEncoded) != packet.getString("from")) return false
        val publicKey = decodePublic(b64(publicEncoded))
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(publicKey)
        verifier.update(canonical(packet).toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(packet.getString("sig"), Base64.DEFAULT))
    }.getOrDefault(false)

    fun decryptChat(packet: JSONObject): String {
        require(verifyPacket(packet)) { "Firma del mensaje no válida." }
        val senderPublic = decodePublic(packet.getString("pub"))
        val iv = Base64.decode(packet.getString("iv"), Base64.DEFAULT)
        val cipherText = Base64.decode(packet.getString("body"), Base64.DEFAULT)
        val secret = sharedSecret(senderPublic)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(cipherText), Charsets.UTF_8)
    }

    fun isValidHello(packet: JSONObject): Boolean = runCatching {
        val pub = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        idForPublicKey(pub) == packet.getString("from")
    }.getOrDefault(false)

    private fun encryptFor(publicKey: PublicKey, data: ByteArray): Pair<ByteArray, ByteArray> {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, sharedSecret(publicKey))
        return cipher.iv to cipher.doFinal(data)
    }

    private fun sharedSecret(peer: PublicKey): SecretKeySpec {
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(pair.private)
        agreement.doPhase(peer, true)
        val material = agreement.generateSecret()
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update("BetaChat-E2E-v1".toByteArray(Charsets.UTF_8))
        digest.update(material)
        return SecretKeySpec(digest.digest(), "AES")
    }

    private fun sign(value: String): String {
        val signer = Signature.getInstance("SHA256withECDSA")
        signer.initSign(pair.private)
        signer.update(value.toByteArray(Charsets.UTF_8))
        return b64(signer.sign())
    }

    private fun canonical(packet: JSONObject): String = listOf(
        packet.optString("id"), packet.optString("from"), packet.optString("to"),
        packet.optString("iv"), packet.optString("body"), packet.optString("pub")
    ).joinToString("|")

    private fun loadOrCreatePair(): KeyPair {
        val savedPub = prefs.getString("pub", null)
        val savedWrapped = prefs.getString("private_wrapped", null)
        if (savedPub != null && savedWrapped != null) {
            runCatching {
                val packed = Base64.decode(savedWrapped, Base64.DEFAULT)
                val nonce = packed.copyOfRange(0, 12)
                val encrypted = packed.copyOfRange(12, packed.size)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateWrappingKey(), GCMParameterSpec(128, nonce))
                val privateBytes = cipher.doFinal(encrypted)
                val publicBytes = Base64.decode(savedPub, Base64.DEFAULT)
                val factory = KeyFactory.getInstance("EC")
                return KeyPair(
                    factory.generatePublic(X509EncodedKeySpec(publicBytes)),
                    factory.generatePrivate(PKCS8EncodedKeySpec(privateBytes))
                )
            }
        }
        val generator = KeyPairGenerator.getInstance("EC")
        generator.initialize(ECGenParameterSpec("secp256r1"))
        val created = generator.generateKeyPair()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateWrappingKey())
        val encrypted = cipher.doFinal(created.private.encoded)
        val packed = cipher.iv + encrypted
        prefs.edit()
            .putString("pub", b64(created.public.encoded))
            .putString("private_wrapped", b64(packed))
            .apply()
        return created
    }

    private fun getOrCreateWrappingKey(): SecretKey {
        val store = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun decodePublic(encoded: String): PublicKey = KeyFactory.getInstance("EC")
        .generatePublic(X509EncodedKeySpec(Base64.decode(encoded, Base64.DEFAULT)))

    private fun idForPublicKey(encoded: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(encoded).take(12).joinToString("") { String.format(Locale.US, "%02x", it) }

    private fun b64(value: ByteArray): String = Base64.encodeToString(value, Base64.NO_WRAP)
}
