package com.betastudio.betachat.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Local identity and end-to-end packet protection for the Bluetooth-only alpha.
 * P-256 ECDH derives a per-packet AES-256-GCM key via HKDF-SHA-256. ECDSA signatures
 * authenticate the full immutable envelope. The private identity key is wrapped by Android Keystore.
 *
 * Security note: this static-identity design does not provide Signal-style forward secrecy or a
 * Double Ratchet. Do not market it as a complete Signal protocol replacement; an audited ratchet
 * implementation should be adopted before handling high-risk conversations.
 */
class IdentityCrypto(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("betachat_identity", Context.MODE_PRIVATE)
    private val keyAlias = "betachat.identity.wrapper.v1"
    private val pair: KeyPair by lazy { loadOrCreatePair() }
    val publicKeyBase64: String by lazy { b64(pair.public.encoded) }
    val deviceId: String by lazy { idForPublicKey(pair.public.encoded) }

    fun helloPacket(
        nickname: String,
        phone: String = "",
        phonePublic: Boolean = false,
        bio: String = "",
        avatarBase64: String = "",
        statusText: String = "",
        statusAt: Long = 0L
    ): JSONObject {
        val packet = JSONObject()
            .put("protocolVersion", 3)
            .put("id", java.util.UUID.randomUUID().toString())
            .put("kind", "HELLO")
            .put("from", deviceId)
            .put("fromName", nickname.ifBlank { "Usuario" }.take(32))
            .put("bio", bio.trim().take(160))
            .put("avatar", avatarBase64.take(1500))
            .put("status", statusText.trim().take(180))
            .put("statusAt", statusAt.coerceAtLeast(0L))
            .put("pub", publicKeyBase64)
            .put("ttl", 1)
        if (phonePublic && phone.isNotBlank()) packet.put("phone", phone.trim().take(24))
        packet.put("sig", sign(canonicalHello(packet)))
        return packet
    }

    fun createControlPacket(kind: String, recipientId: String, nickname: String, reference: String = ""): JSONObject {
        require(kind in setOf("CHAT_REQUEST", "REQUEST_ACCEPT", "REQUEST_REJECT", "MESSAGE_ACK", "MESSAGE_READ"))
        val packet = JSONObject()
            .put("protocolVersion", 3)
            .put("id", java.util.UUID.randomUUID().toString())
            .put("kind", kind)
            .put("from", deviceId)
            .put("to", recipientId)
            .put("fromName", nickname.ifBlank { "Usuario" }.take(32))
            .put("pub", publicKeyBase64)
            .put("ref", reference.take(64))
            .put("maxTtl", 3)
            .put("ttl", 3)
        packet.put("sig", sign(canonicalControl(packet)))
        return packet
    }

    fun verifyControlPacket(packet: JSONObject): Boolean = runCatching {
        if (packet.optInt("protocolVersion", 0) != 3) return false
        if (packet.optString("kind") !in setOf("CHAT_REQUEST", "REQUEST_ACCEPT", "REQUEST_REJECT", "MESSAGE_ACK", "MESSAGE_READ")) return false
        val publicEncoded = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        if (idForPublicKey(publicEncoded) != packet.getString("from")) return false
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(decodePublic(b64(publicEncoded)))
        verifier.update(canonicalControl(packet).toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(packet.getString("sig"), Base64.DEFAULT))
    }.getOrDefault(false)

    fun createEncryptedChat(
        recipientId: String,
        recipientPublicBase64: String,
        nickname: String,
        text: String,
        messageId: String = java.util.UUID.randomUUID().toString()
    ): JSONObject {
        val recipientPublic = decodePublic(recipientPublicBase64)
        require(idForPublicKey(recipientPublic.encoded) == recipientId) { "La identidad del destinatario no coincide." }
        val context = "chat|$deviceId|$recipientId|$messageId"
        val encrypted = encryptFor(recipientPublic, text.toByteArray(Charsets.UTF_8), context)
        val packet = JSONObject()
            .put("id", messageId)
            .put("kind", "CHAT")
            .put("from", deviceId)
            .put("fromName", nickname.ifBlank { "Usuario" }.take(32))
            .put("to", recipientId)
            .put("maxTtl", 6)
            .put("ttl", 6)
            .put("salt", b64(encrypted.salt))
            .put("iv", b64(encrypted.iv))
            .put("body", b64(encrypted.cipherText))
            .put("cryptoVersion", 3)
            .put("pub", publicKeyBase64)
        packet.put("sig", sign(canonical(packet)))
        return packet
    }

    fun verifyPacket(packet: JSONObject): Boolean = runCatching {
        if (packet.optString("kind") != "CHAT" || packet.optInt("cryptoVersion", 0) != 3) return false
        val publicEncoded = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        if (idForPublicKey(publicEncoded) != packet.getString("from")) return false
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(decodePublic(b64(publicEncoded)))
        verifier.update(canonical(packet).toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(packet.getString("sig"), Base64.DEFAULT))
    }.getOrDefault(false)

    fun decryptChat(packet: JSONObject): String {
        require(verifyPacket(packet)) { "Firma del mensaje no válida." }
        val senderPublic = decodePublic(packet.getString("pub"))
        val context = "chat|${packet.getString("from")}|${packet.getString("to")}|${packet.getString("id")}" 
        val plaintext = decryptFrom(
            senderPublic,
            Base64.decode(packet.getString("salt"), Base64.DEFAULT),
            Base64.decode(packet.getString("iv"), Base64.DEFAULT),
            Base64.decode(packet.getString("body"), Base64.DEFAULT),
            context
        )
        return String(plaintext, Charsets.UTF_8)
    }

    fun createEncryptedMediaChunk(
        recipientId: String,
        recipientPublicBase64: String,
        nickname: String,
        transferId: String,
        fileName: String,
        mimeType: String,
        index: Int,
        total: Int,
        sha256: String,
        bytes: ByteArray
    ): JSONObject {
        val recipientPublic = decodePublic(recipientPublicBase64)
        require(idForPublicKey(recipientPublic.encoded) == recipientId) { "La identidad del destinatario no coincide." }
        require(total in 1..100 && index in 0 until total && bytes.size <= 1600)
        val packetId = "$transferId:$index:${java.util.UUID.randomUUID()}"
        val context = "media|$deviceId|$recipientId|$transferId|$index"
        val encrypted = encryptFor(recipientPublic, bytes, context)
        val packet = JSONObject()
            .put("id", packetId).put("kind", "MEDIA")
            .put("from", deviceId).put("fromName", nickname.ifBlank { "Usuario" }.take(32))
            .put("to", recipientId).put("transfer", transferId.take(64))
            .put("fileName", fileName.take(100)).put("mime", mimeType.take(120))
            .put("idx", index).put("total", total).put("sha256", sha256.take(64))
            .put("salt", b64(encrypted.salt)).put("iv", b64(encrypted.iv))
            .put("body", b64(encrypted.cipherText)).put("cryptoVersion", 3)
            .put("pub", publicKeyBase64).put("maxTtl", 6).put("ttl", 6)
        packet.put("sig", sign(canonicalMedia(packet)))
        return packet
    }

    fun verifyMediaPacket(packet: JSONObject): Boolean = runCatching {
        if (packet.optString("kind") != "MEDIA" || packet.optInt("cryptoVersion", 0) != 3) return false
        if (packet.optInt("total") !in 1..100 || packet.optInt("idx") !in 0 until packet.optInt("total")) return false
        val pub = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        if (idForPublicKey(pub) != packet.getString("from")) return false
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(decodePublic(b64(pub)))
        verifier.update(canonicalMedia(packet).toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(packet.getString("sig"), Base64.DEFAULT))
    }.getOrDefault(false)

    fun decryptMediaChunk(packet: JSONObject): ByteArray {
        require(verifyMediaPacket(packet)) { "Firma del archivo no válida." }
        val senderId = packet.getString("from")
        val recipientId = packet.getString("to")
        require(recipientId == deviceId) { "El archivo no está destinado a este dispositivo." }
        val context = "media|$senderId|$recipientId|${packet.getString("transfer")}|${packet.getInt("idx")}" 
        return decryptFrom(
            decodePublic(packet.getString("pub")),
            Base64.decode(packet.getString("salt"), Base64.DEFAULT),
            Base64.decode(packet.getString("iv"), Base64.DEFAULT),
            Base64.decode(packet.getString("body"), Base64.DEFAULT),
            context
        )
    }

    fun isValidHello(packet: JSONObject): Boolean = runCatching {
        if (packet.optInt("protocolVersion", 0) != 3 || packet.optString("kind") != "HELLO") return false
        val pub = Base64.decode(packet.getString("pub"), Base64.DEFAULT)
        if (idForPublicKey(pub) != packet.getString("from")) return false
        if (packet.optString("avatar").length > 1500 || packet.optString("status").length > 180) return false
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(decodePublic(b64(pub)))
        verifier.update(canonicalHello(packet).toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(packet.getString("sig"), Base64.DEFAULT))
    }.getOrDefault(false)

    private data class EncryptedPayload(val salt: ByteArray, val iv: ByteArray, val cipherText: ByteArray)

    private fun encryptFor(peer: PublicKey, data: ByteArray, context: String): EncryptedPayload {
        val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveMessageKey(peer, salt, context))
        cipher.updateAAD(context.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(salt, cipher.iv, cipher.doFinal(data))
    }

    private fun decryptFrom(peer: PublicKey, salt: ByteArray, iv: ByteArray, cipherText: ByteArray, context: String): ByteArray {
        require(salt.size == 16 && iv.size == 12) { "Parámetros de cifrado no válidos." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deriveMessageKey(peer, salt, context), GCMParameterSpec(128, iv))
        cipher.updateAAD(context.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(cipherText)
    }

    private fun deriveMessageKey(peer: PublicKey, salt: ByteArray, context: String): SecretKeySpec {
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(pair.private)
        agreement.doPhase(peer, true)
        val shared = agreement.generateSecret()
        // RFC 5869-style HKDF-SHA-256: extract with a per-packet salt, then expand with context.
        val extract = Mac.getInstance("HmacSHA256")
        extract.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = extract.doFinal(shared)
        val expand = Mac.getInstance("HmacSHA256")
        expand.init(SecretKeySpec(prk, "HmacSHA256"))
        val input = "ẞetaChat-E2E-v3|$context".toByteArray(Charsets.UTF_8) + byteArrayOf(1)
        val key = expand.doFinal(input).copyOf(32)
        shared.fill(0)
        prk.fill(0)
        return SecretKeySpec(key, "AES")
    }

    private fun sign(value: String): String {
        val signer = Signature.getInstance("SHA256withECDSA")
        signer.initSign(pair.private)
        signer.update(value.toByteArray(Charsets.UTF_8))
        return b64(signer.sign())
    }

    /** Length-prefix UTF-8 fields to prevent delimiter-injection / ambiguous signed envelopes. */
    private fun canonicalFields(fields: List<String>): String = buildString {
        fields.forEach { field ->
            append(field.toByteArray(Charsets.UTF_8).size)
            append(':')
            append(field)
        }
    }

    private fun canonical(packet: JSONObject): String = canonicalFields(listOf(
        packet.optString("kind"), packet.optString("id"), packet.optString("from"),
        packet.optString("to"), packet.optString("fromName"), packet.optString("salt"),
        packet.optString("iv"), packet.optString("body"), packet.optString("pub"),
        packet.optString("maxTtl"), packet.optString("cryptoVersion")
    ))

    private fun canonicalMedia(packet: JSONObject): String = canonicalFields(listOf(
        packet.optString("kind"), packet.optString("id"), packet.optString("from"),
        packet.optString("to"), packet.optString("fromName"), packet.optString("transfer"),
        packet.optString("fileName"), packet.optString("mime"), packet.optString("idx"),
        packet.optString("total"), packet.optString("sha256"), packet.optString("salt"),
        packet.optString("iv"), packet.optString("body"), packet.optString("pub"),
        packet.optString("maxTtl"), packet.optString("cryptoVersion")
    ))

    private fun canonicalHello(packet: JSONObject): String = canonicalFields(listOf(
        packet.optString("protocolVersion"), packet.optString("kind"), packet.optString("id"),
        packet.optString("from"), packet.optString("fromName"), packet.optString("bio"),
        packet.optString("phone"), packet.optString("avatar"), packet.optString("status"),
        packet.optString("statusAt"), packet.optString("pub")
    ))

    private fun canonicalControl(packet: JSONObject): String = canonicalFields(listOf(
        packet.optString("protocolVersion"), packet.optString("kind"), packet.optString("id"),
        packet.optString("from"), packet.optString("to"), packet.optString("fromName"),
        packet.optString("pub"), packet.optString("ref"), packet.optString("maxTtl")
    ))

    private fun loadOrCreatePair(): KeyPair {
        val savedPub = prefs.getString("pub", null)
        val savedWrapped = prefs.getString("private_wrapped", null)
        if (savedPub != null && savedWrapped != null) {
            runCatching {
                val packed = Base64.decode(savedWrapped, Base64.DEFAULT)
                val nonce = packed.copyOfRange(0, 12)
                val encrypted = packed.copyOfRange(12, packed.size)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateWrappingKey(), GCMParameterSpec(128, nonce))
                val privateBytes = cipher.doFinal(encrypted)
                val publicBytes = Base64.decode(savedPub, Base64.DEFAULT)
                val factory = KeyFactory.getInstance("EC")
                return KeyPair(
                    factory.generatePublic(X509EncodedKeySpec(publicBytes)),
                    factory.generatePrivate(PKCS8EncodedKeySpec(privateBytes))
                )
            }
        }
        val generator = KeyPairGenerator.getInstance("EC")
        generator.initialize(ECGenParameterSpec("secp256r1"))
        val created = generator.generateKeyPair()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateWrappingKey())
        val encrypted = cipher.doFinal(created.private.encoded)
        prefs.edit().putString("pub", b64(created.public.encoded))
            .putString("private_wrapped", b64(cipher.iv + encrypted)).apply()
        return created
    }

    private fun getOrCreateWrappingKey(): SecretKey {
        val store = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun decodePublic(encoded: String): PublicKey = KeyFactory.getInstance("EC")
        .generatePublic(X509EncodedKeySpec(Base64.decode(encoded, Base64.DEFAULT)))

    private fun idForPublicKey(encoded: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(encoded).take(12).joinToString("") { String.format(Locale.US, "%02x", it) }

    private fun b64(value: ByteArray): String = Base64.encodeToString(value, Base64.NO_WRAP)
}
