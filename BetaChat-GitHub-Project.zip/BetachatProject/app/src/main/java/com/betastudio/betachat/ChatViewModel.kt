package com.betastudio.betachat

import android.Manifest
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import com.betastudio.betachat.network.SmsStatusReceiver
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val dao = ChatDatabase.get(context).chatDao()

    val chats = dao.observeChats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    suspend fun ensureMeshChat(peerId: String, peerName: String, publicPhone: String = ""): ChatEntity {
        val existing = dao.findChat(peerId)
        if (existing != null) {
            val updated = existing.copy(
                title = peerName.ifBlank { existing.title },
                recipientPhone = publicPhone.takeIf { it.isNotBlank() } ?: existing.recipientPhone
            )
            dao.upsertChat(updated)
            return updated
        }
        val chat = ChatEntity(
            id = peerId,
            peerId = peerId,
            title = peerName.ifBlank { "Usuario" },
            lastMessage = "Solicitud aceptada · inicia una conversación",
            updatedAt = System.currentTimeMillis(),
            route = "AUTO",
            recipientPhone = publicPhone.takeIf { it.isNotBlank() }
        )
        dao.upsertChat(chat)
        return chat
    }

    suspend fun ensureSmsChat(phone: String): ChatEntity {
        val normalized = normalizePhone(phone)
        require(normalized.length >= 5) { "Introduce un número de teléfono válido." }
        val id = "sms:$normalized"
        val existing = dao.findChat(id)
        if (existing != null) return existing.copy(recipientPhone = normalized, route = "SMS").also { dao.upsertChat(it) }
        return ChatEntity(
            id = id,
            peerId = id,
            title = normalized,
            lastMessage = "SMS · nueva conversación",
            updatedAt = System.currentTimeMillis(),
            route = "SMS",
            recipientPhone = normalized
        ).also { dao.upsertChat(it) }
    }

    fun setRoute(chat: ChatEntity, route: String) {
        if (route !in setOf("AUTO", "MESH", "SMS")) return
        viewModelScope.launch { dao.upsertChat(chat.copy(route = route, updatedAt = System.currentTimeMillis())) }
    }

    fun willUseSms(chat: ChatEntity, selectedRoute: String, nearby: Boolean): Boolean = when (selectedRoute) {
        "SMS" -> true
        "MESH" -> false
        else -> !(nearby && !chat.peerId.startsWith("sms:") && isAccepted(chat.peerId))
    }

    fun canUseSms(chat: ChatEntity): Boolean = !chat.recipientPhone.isNullOrBlank()

    fun isAccepted(peerId: String): Boolean =
        context.getSharedPreferences("betachat_accepted_peers", Context.MODE_PRIVATE).getBoolean(peerId, false)

    fun sendMessage(chat: ChatEntity, text: String, myNickname: String, selectedRoute: String, nearby: Boolean) {
        val body = text.trim().take(1000)
        if (body.isBlank()) return
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val useSms = willUseSms(chat, selectedRoute, nearby)
        val transport = if (useSms) "SMS" else "MESH"
        viewModelScope.launch {
            val savedChat = chat.copy(lastMessage = body, updatedAt = now, unreadCount = 0)
            dao.insertMessage(MessageEntity(id, chat.id, "me", body, now, true, "pending", transport))
            dao.upsertChat(savedChat)
            if (useSms) sendSms(chat, id, body) else sendMesh(chat, id, body, myNickname)
        }
    }

    private suspend fun sendSms(chat: ChatEntity, messageId: String, body: String) {
        val phone = chat.recipientPhone ?: chat.peerId.removePrefix("sms:").takeIf { chat.peerId.startsWith("sms:") }
        if (phone.isNullOrBlank()) {
            dao.updateMessageStatus(messageId, "failed")
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            dao.updateMessageStatus(messageId, "failed")
            return
        }
        try {
            @Suppress("DEPRECATION")
            val smsManager = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = smsManager.divideMessage(body)
            val pendingPrefs = context.getSharedPreferences("betachat_sms_pending", Context.MODE_PRIVATE)
            pendingPrefs.edit().putInt("total:$messageId", parts.size).putInt("done:$messageId", 0)
                .putBoolean("failed:$messageId", false).apply()
            val sentIntents = ArrayList<PendingIntent>(parts.size)
            parts.forEachIndexed { index, _ ->
                val intent = Intent(context, SmsStatusReceiver::class.java)
                    .setAction(SmsStatusReceiver.ACTION_SENT)
                    .putExtra(SmsStatusReceiver.EXTRA_MESSAGE_ID, messageId)
                    .putExtra(SmsStatusReceiver.EXTRA_PHONE, phone)
                    .putExtra(SmsStatusReceiver.EXTRA_BODY, body)
                    .putExtra(SmsStatusReceiver.EXTRA_PART_COUNT, parts.size)
                sentIntents.add(PendingIntent.getBroadcast(
                    context, 31 * messageId.hashCode() + index, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                ))
            }
            if (parts.size == 1) smsManager.sendTextMessage(phone, null, body, sentIntents.first(), null)
            else smsManager.sendMultipartTextMessage(phone, null, parts, sentIntents, null)
            // The status receiver updates the message only when Android reports all SMS parts.
        } catch (_: Exception) {
            dao.updateMessageStatus(messageId, "failed")
        }
    }

    private fun sendMesh(chat: ChatEntity, messageId: String, body: String, nickname: String) {
        if (chat.peerId.startsWith("sms:")) {
            viewModelScope.launch { dao.updateMessageStatus(messageId, "failed") }
            return
        }
        val intent = Intent(context, MeshBleService::class.java)
            .setAction(MeshBleService.ACTION_SEND)
            .putExtra("to", chat.peerId)
            .putExtra("name", chat.title)
            .putExtra("body", body)
            .putExtra("message_id", messageId)
            .putExtra("nickname", nickname)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) androidx.core.content.ContextCompat.startForegroundService(context, intent)
            else context.startService(intent)
        }.onFailure {
            viewModelScope.launch { dao.updateMessageStatus(messageId, "failed") }
        }
    }

    fun markRead(chatId: String) {
        viewModelScope.launch { dao.clearUnread(chatId) }
    }

    companion object {
        fun normalizePhone(phone: String): String = phone.trim().replace("[\\s().-]".toRegex(), "").take(24)
    }
}
