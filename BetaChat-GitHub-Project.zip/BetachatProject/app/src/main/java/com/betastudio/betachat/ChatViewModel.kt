package com.betastudio.betachat

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val dao = ChatDatabase.get(context).chatDao()

    val chats = dao.observeChats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    suspend fun ensureMeshChat(peerId: String, peerName: String, publicPhone: String = ""): ChatEntity {
        require(peerId.isNotBlank())
        val existing = dao.findChat(peerId)
        if (existing != null) {
            val updated = existing.copy(
                title = peerName.ifBlank { existing.title },
                recipientPhone = publicPhone.takeIf { it.isNotBlank() } ?: existing.recipientPhone,
                route = "MESH"
            )
            dao.upsertChat(updated)
            return updated
        }
        return ChatEntity(
            id = peerId,
            peerId = peerId,
            title = peerName.ifBlank { "Usuario" },
            lastMessage = "Chat Bluetooth listo",
            updatedAt = System.currentTimeMillis(),
            route = "MESH",
            recipientPhone = publicPhone.takeIf { it.isNotBlank() }
        ).also { dao.upsertChat(it) }
    }

    fun setRoute(chat: ChatEntity, route: String) {
        if (route != "MESH") return
        viewModelScope.launch { dao.upsertChat(chat.copy(route = "MESH", updatedAt = System.currentTimeMillis())) }
    }

    fun isAccepted(peerId: String): Boolean =
        context.getSharedPreferences("betachat_accepted_peers", android.content.Context.MODE_PRIVATE).getBoolean(peerId, false)

    fun sendMessage(chat: ChatEntity, text: String, myNickname: String) {
        val body = text.trim().take(1000)
        if (body.isBlank()) return
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertMessage(MessageEntity(id, chat.id, "me", body, now, true, "pending", "MESH"))
            dao.upsertChat(chat.copy(lastMessage = body, updatedAt = now, unreadCount = 0, route = "MESH"))
            val intent = Intent(context, MeshBleService::class.java)
                .setAction(MeshBleService.ACTION_SEND)
                .putExtra("to", chat.peerId)
                .putExtra("name", chat.title)
                .putExtra("body", body)
                .putExtra("message_id", id)
                .putExtra("nickname", myNickname)
            runCatching { ContextCompat.startForegroundService(context, intent) }
                .onSuccess { dao.updateMessageStatus(id, "sent") }
                .onFailure { dao.updateMessageStatus(id, "failed") }
        }
    }

    /** Bluetooth media is intentionally bounded to 128 KiB per transfer to avoid unbounded BLE queues. */
    fun sendMedia(chat: ChatEntity, uri: Uri, myNickname: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                var reportedSize: Long? = null
                val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        reportedSize = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else null
                        if (nameIndex >= 0) cursor.getString(nameIndex) else null
                    } else null
                }?.take(100) ?: "archivo"
                if (reportedSize != null && reportedSize!! > MAX_MEDIA_BYTES.toLong()) {
                    throw IllegalArgumentException("Por Bluetooth, el tamaño máximo por archivo es 128 KiB en esta versión.")
                }
                val mime = resolver.getType(uri)?.take(120) ?: "application/octet-stream"
                val stream = resolver.openInputStream(uri) ?: throw IllegalStateException("No se pudo leer el archivo seleccionado.")
                val bytes = stream.use { input ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > MAX_MEDIA_BYTES) throw IllegalArgumentException("Por Bluetooth, el tamaño máximo por archivo es 128 KiB en esta versión.")
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                if (bytes.isEmpty()) throw IllegalArgumentException("El archivo está vacío.")
                

                val transferId = UUID.randomUUID().toString()
                val outgoingDir = File(context.filesDir, "sent_media").apply { mkdirs() }
                val file = File(outgoingDir, transferId + safeExtension(name))
                file.writeBytes(bytes)
                val now = System.currentTimeMillis()
                dao.insertMessage(MessageEntity(
                    id = transferId, chatId = chat.id, senderId = "me", text = name,
                    timestamp = now, outgoing = true, status = "pending", transport = "MESH",
                    type = "MEDIA", attachmentPath = file.absolutePath, attachmentName = name,
                    attachmentMimeType = mime
                ))
                dao.upsertChat(chat.copy(lastMessage = "Archivo · $name", updatedAt = now, unreadCount = 0, route = "MESH"))
                val intent = Intent(context, MeshBleService::class.java)
                    .setAction(MeshBleService.ACTION_SEND_MEDIA)
                    .putExtra("to", chat.peerId)
                    .putExtra("name", chat.title)
                    .putExtra("nickname", myNickname)
                    .putExtra("transfer_id", transferId)
                    .putExtra("file_name", name)
                    .putExtra("mime_type", mime)
                    .putExtra("media_bytes", bytes)
                runCatching { ContextCompat.startForegroundService(context, intent) }
                    .onSuccess { dao.updateMessageStatus(transferId, "sent") }
                    .onFailure { dao.updateMessageStatus(transferId, "failed") }
            } catch (error: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, error.message ?: "No se pudo preparar el archivo.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun markRead(chatId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearUnread(chatId)
            dao.unreadIncoming(chatId).forEach { message ->
                dao.updateMessageStatus(message.id, "read")
                val chat = dao.findChat(chatId) ?: return@forEach
                val intent = Intent(context, MeshBleService::class.java)
                    .setAction(MeshBleService.ACTION_CONTROL)
                    .putExtra("to", chat.peerId)
                    .putExtra("control_kind", "MESSAGE_READ")
                    .putExtra("reference", message.id)
                runCatching { ContextCompat.startForegroundService(context, intent) }
            }
        }
    }

    private fun safeExtension(name: String): String {
        val extension = name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(8)
        return if (extension.isBlank()) ".bin" else ".$extension"
    }

    companion object {
        const val MAX_MEDIA_BYTES = 128 * 1024

        /** Keeps an optional international phone number in a predictable display/storage form. */
        fun normalizePhone(value: String): String {
            val input = value.trim()
            if (input.isBlank()) return ""
            val result = StringBuilder()
            input.forEach { character ->
                when {
                    character.isDigit() -> result.append(character)
                    character == '+' && result.isEmpty() -> result.append(character)
                }
            }
            return result.toString().take(24)
        }
    }
}
