package com.betastudio.betachat

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.betastudio.betachat.data.ChatDatabase
import com.betastudio.betachat.data.ChatEntity
import com.betastudio.betachat.data.MessageEntity
import com.betastudio.betachat.network.MeshBleService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val dao = ChatDatabase.get(context).chatDao()

    val chats = dao.observeChats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun messages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    suspend fun ensureChat(peerId: String, peerName: String): ChatEntity {
        val existing = dao.findChat(peerId)
        if (existing != null) {
            if (existing.title != peerName) {
                val updated = existing.copy(title = peerName)
                dao.upsertChat(updated)
                return updated
            }
            return existing
        }
        val chat = ChatEntity(peerId, peerId, peerName.ifBlank { "Usuario" }, "Inicia una conversación", System.currentTimeMillis())
        dao.upsertChat(chat)
        return chat
    }

    fun sendMessage(chat: ChatEntity, text: String, myNickname: String) {
        val body = text.trim().take(250)
        if (body.isBlank()) return
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            dao.insertMessage(MessageEntity(UUID.randomUUID().toString(), chat.id, "me", body, now, true, "pending"))
            dao.upsertChat(chat.copy(lastMessage = body, updatedAt = now, unreadCount = 0))
            val intent = Intent(context, MeshBleService::class.java)
                .setAction(MeshBleService.ACTION_SEND)
                .putExtra("to", chat.peerId)
                .putExtra("name", chat.title)
                .putExtra("body", body)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(context, intent)
                else context.startService(intent)
            }
        }
    }

    fun markRead(chatId: String) {
        viewModelScope.launch { dao.clearUnread(chatId) }
    }
}
