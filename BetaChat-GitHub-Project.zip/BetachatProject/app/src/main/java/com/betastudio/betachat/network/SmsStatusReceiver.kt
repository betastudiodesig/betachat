package com.betastudio.betachat.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.Activity
import android.content.ContentValues
import android.provider.Telephony
import com.betastudio.betachat.data.ChatDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_SENT) return
        val id = intent.getStringExtra(EXTRA_MESSAGE_ID).orEmpty()
        if (id.isBlank()) return
        val partCount = intent.getIntExtra(EXTRA_PART_COUNT, 1).coerceIn(1, 100)
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        val body = intent.getStringExtra(EXTRA_BODY).orEmpty()
        val pendingPrefs = context.getSharedPreferences("betachat_sms_pending", Context.MODE_PRIVATE)
        val completedKey = "done:$id"
        val totalKey = "total:$id"
        val failedKey = "failed:$id"
        val total = pendingPrefs.getInt(totalKey, partCount).coerceAtLeast(1)
        val failed = pendingPrefs.getBoolean(failedKey, false) || resultCode != Activity.RESULT_OK
        val done = pendingPrefs.getInt(completedKey, 0) + 1
        pendingPrefs.edit().putInt(completedKey, done).putBoolean(failedKey, failed).apply()
        if (done < total) return
        val state = if (failed) "failed" else "sent"
        pendingPrefs.edit().remove(completedKey).remove(totalKey).remove(failedKey).apply()
        val isDefaultSms = Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
        if (state == "sent" && isDefaultSms && phone.isNotBlank()) {
            runCatching {
                val values = ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, phone)
                    put(Telephony.Sms.BODY, body)
                    put(Telephony.Sms.DATE, System.currentTimeMillis())
                    put(Telephony.Sms.READ, 1)
                    put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
                }
                context.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, values)
            }
        }
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try { ChatDatabase.get(context).chatDao().updateMessageStatus(id, state) }
            finally { pending.finish() }
        }
    }

    companion object {
        const val ACTION_SENT = "com.betastudio.betachat.action.SMS_SENT"
        const val EXTRA_MESSAGE_ID = "message_id"
        const val EXTRA_PHONE = "phone"
        const val EXTRA_BODY = "body"
        const val EXTRA_PART_COUNT = "part_count"
    }
}
