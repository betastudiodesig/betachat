package com.betastudio.betachat

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Minimal crash diagnostics for alpha builds. The report stays in app-private storage and
 * deliberately records only the exception/stack trace, never profile or message contents.
 */
class BetaChatApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val trace = StringWriter().also { writer ->
                    error.printStackTrace(PrintWriter(writer))
                }.toString()
                Log.e("BetaChat/Crash", "Uncaught exception on thread ${thread.name}", error)
                File(filesDir, "last_crash.txt").writeText(
                    "time=${System.currentTimeMillis()}\nthread=${thread.name}\n$trace".take(120_000)
                )
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
