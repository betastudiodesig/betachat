# ẞetaChat Android — Bluetooth-only 0.3.0

Proyecto Android nativo en Kotlin y Jetpack Compose. Esta versión elimina la función SMS y se concentra en chats directos por Bluetooth Low Energy (BLE). El proyecto es una **vista previa experimental**, no una versión lista para uso sensible ni una implementación equivalente a WhatsApp/Signal.

## Funciones incluidas en esta revisión

- Onboarding independiente de los permisos: completar el perfil no inicia Bluetooth ni fuerza permisos.
- Perfiles cercanos firmados con identidad del dispositivo, nombre, foto de perfil reducida, biografía y teléfono opcional que el propietario puede decidir publicar.
- Conversaciones con solicitud/aceptación; los chats se limitan a interlocutores que aceptaron la solicitud.
- Navegación Personas / Estados / Chats / Ajustes con transiciones direccionales que coinciden con el sentido del cambio de pestaña, gesto horizontal para navegar y gesto para volver al chat.
- Ajuste de insets del sistema para que la interfaz no quede debajo de la barra de estado ni de navegación.
- Estados de texto locales compartidos en el anuncio BLE, con expiración lógica de 24 horas. Solo se ven cuando hay alcance Bluetooth; no existe una nube que los distribuya globalmente.
- Mensajes de texto cifrados y autenticados, con marcas: `✓` enviado/pendiente de entrega, `✓✓` recibido por el otro dispositivo y `✓✓✓` leído. `!` indica fallo local.
- Adjuntos de chat de cualquier tipo MIME, con límite de 128 KiB por archivo, cifrado por bloques, verificación SHA-256 y almacenamiento interno privado al recibir.
- Cifrado de paquetes mediante ECDH P-256, HKDF-SHA-256, AES-256-GCM y firmas ECDSA; la clave privada de identidad queda envuelta por una clave de Android Keystore.
- Migración Room de v1/v2 a v3. La migración retira del historial local las conversaciones heredadas de SMS y deja todas las rutas existentes en BLE.
- `BetaChatApplication` guarda una traza privada para diagnosticar cierres; no se afirma que el fallo previo haya sido reproducido ni que ya esté confirmado.

## Restricciones que es importante conocer

1. **Bluetooth no es Internet.** Los dispositivos necesitan estar dentro del alcance de la red BLE y tener ẞetaChat ejecutándose con Bluetooth y los permisos necesarios. El prototipo usa una red store-and-forward limitada por saltos. Los mensajes de texto pendientes se conservan en Room y se reintentan al volver a descubrir al destinatario; aun así, no se garantiza entrega si se pierde cobertura o un relay abandona la red. Las colas temporales de BLE son en memoria.
2. **Límite actual de adjuntos: 128 KiB.** Es una protección para controlar la memoria y la cola BLE. No es adecuado para vídeos grandes. Las transferencias se hacen por bloques cifrados, pero no hay todavía recuperación selectiva/reanudación de bloques perdidos ni progreso detallado.
3. **Estados en esta fase solo son texto.** Expiran después de 24 horas y se anuncian a través de BLE mientras el dispositivo está disponible. Fotos/vídeos como estado, audiencia de contactos y visualizaciones de estado aún no están implementados.
4. **El cifrado es experimental.** El diseño de esta versión deriva una clave de cada paquete con ECDH de claves de identidad estáticas y HKDF, usa AES-GCM y firma los envelopes. Sin embargo, no implementa Double Ratchet, prekeys ni secreto hacia adelante (*forward secrecy*). Si una clave privada de identidad se compromete, mensajes antiguos capturados podrían quedar expuestos. La implementación no ha pasado una auditoría criptográfica independiente. No se debe presentar como “Signal-level”, “indescifrable” ni usar para conversaciones de alto riesgo.
5. **Verificación de identidad.** El identificador deriva de una clave pública, pero aún no hay un flujo de comparación de huella/fingerprint entre usuarios. Antes de uso sensible habría que implementar verificación fuera de banda y rotación/revocación de claves.
6. **Dos dispositivos deben actualizarse a esta versión juntos.** El protocolo de paquetes cifrados marca `cryptoVersion=3`; versiones anteriores pueden no entender mensajes, datos de perfil ni adjuntos recientes.
7. **Distribución.** No hace falta publicar en Google Play para instalar una compilación de depuración en un dispositivo propio. Android puede mostrar advertencias de instalación para APK distribuidos por fuera de Play; el proyecto no intenta evadir Play Protect.

## Cómo compilar

### GitHub Actions

1. Sube el contenido de esta carpeta al repositorio (no hace falta subir un ZIP dentro de otro ZIP).
2. Abre **Actions** y ejecuta **Build Android APK** o **Compilar BetaChat Android APK**.
3. Descarga el artefacto `betachat-debug-apk` o `BetaChat-Android-APK` si la ejecución termina correctamente.
4. Instala `app-debug.apk` en dos teléfonos para probar el protocolo entre dispositivos.

Los workflows configuran Java 17, Gradle 8.13 y Android SDK Platform 36. El código de esta entrega se ha revisado estáticamente; este entorno no incluye Gradle ni Android SDK, por lo que no se afirma que el proyecto haya compilado aquí.

### Android Studio

Abre la carpeta `BetachatProject` como proyecto Gradle. Si Android Studio no detecta un wrapper, selecciona Gradle 8.13 en la configuración de Gradle. Se requiere Android SDK Platform 36.

## Pruebas mínimas en dos teléfonos

1. Instala la misma versión en ambos. Crea perfiles distintos; comprueba que el onboarding finaliza incluso si se deniegan permisos Bluetooth.
2. Concede los permisos Bluetooth y activa la búsqueda en ambos móviles. Comprueba que aparecen perfiles cercanos, que la foto se ve y que el teléfono solo se muestra si se activó la opción pública.
3. Envía una solicitud y prueba aceptar/rechazar. Confirma que los mensajes no se envían antes de aceptar.
4. Envía texto con ambos dispositivos cerca: debe verse `✓`, después `✓✓` al confirmar entrega y `✓✓✓` cuando se abre el chat receptor y se marca como leído.
5. Envía una imagen pequeña y un archivo de menos de 128 KiB; comprueba que se descifran, la suma SHA-256 coincide y el archivo se abre.
6. Publica un estado de texto y confirma que se anuncia a un dispositivo cercano y deja de mostrarse una vez superadas 24 horas.
7. Repite con Bluetooth apagado, permisos denegados, cierre forzado y reconexión. Comprueba que los textos pendientes se vuelven a intentar; la reanudación de archivos multimedia tras pérdida de proceso sigue pendiente.

## Estructura principal

```text
BetachatProject/
├── app/src/main/AndroidManifest.xml
├── app/src/main/java/com/betastudio/betachat/
│   ├── MainActivity.kt
│   ├── ChatViewModel.kt
│   ├── data/ChatDatabase.kt
│   ├── network/MeshBleService.kt
│   └── security/IdentityCrypto.kt
├── app/src/main/res/xml/file_paths.xml
└── .github/workflows/
```
