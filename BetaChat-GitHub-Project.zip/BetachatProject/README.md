# ẞetaChat — proyecto Android

Aplicación nativa Android en Kotlin + Jetpack Compose, con interfaz oscura y acento naranja basada en la referencia visual entregada. El proyecto está organizado para subirse a GitHub y compilarse con GitHub Actions.

> **Estado:** alpha técnica (0.1.0). Es una base implementada, no una aplicación de producción certificada. El transporte BLE y la retransmisión mesh requieren pruebas con varios modelos reales de Android; no se han podido validar dispositivos físicos desde este entorno.

## Qué incluye este código

- Interfaz Compose: lista de chats, búsqueda, avatares, Personas, Llamadas y Ajustes.
- Perfil local mediante apodo, sin registro ni número telefónico.
- Historial de mensajes persistido con Room.
- Descubrimiento BLE mediante anuncios y escaneo GATT, con servicio en primer plano.
- Protocolo de paquetes con ID único, TTL, deduplicación, fragmentación/reensamblado y cola temporal.
- Cifrado de mensajes de texto mediante ECDH + AES-GCM y firma ECDSA; clave de identidad cifrada localmente con una clave de Android Keystore.
- Workflow de GitHub Actions que compila `assembleDebug` y publica el APK como artefacto de la ejecución.

## Limitaciones conocidas de esta alpha

- Las llamadas de voz, archivos/fotos, mensajes de voz y chats de grupo todavía no están implementados.
- La entrega mesh por Bluetooth no está garantizada en todos los teléfonos: Android y los fabricantes limitan el número de conexiones GATT, el escaneo y las operaciones en segundo plano. El protocolo debe probarse en al menos tres dispositivos para validar rutas de varios saltos.
- El cifrado protege el contenido de los mensajes, pero la autenticación de los apodos/metadatos, la gestión de bloqueos, los controles antispam y una auditoría independiente del protocolo aún requieren trabajo.
- Los mensajes que no se hayan podido enviar se guardan en el historial local; la cola de transporte pendiente vive en el proceso del servicio y no debe considerarse almacenamiento durable todavía.
- La app no utiliza Internet ni servidores de mensajería. Para descubrirse, los dispositivos deben tener Bluetooth habilitado y permisos concedidos. Las restricciones del sistema pueden limitar el funcionamiento con la app forzada a detenerse o con ahorro de batería estricto.
- La pestaña “Llamadas” se muestra como sección informativa y no realiza llamadas.

## Compilar el APK desde GitHub

1. Crea un repositorio vacío en GitHub.
2. Descomprime este proyecto y sube **el contenido** de la carpeta `BetachatProject` a la raíz del repositorio, incluyendo `.github/workflows/android.yml`.
3. Abre la pestaña **Actions**. La acción **Build Android APK** se ejecuta al hacer push a `main`/`master`, en pull requests o manualmente con **Run workflow**.
4. Cuando el trabajo termine correctamente, abre la ejecución y descarga el artefacto `betachat-debug-apk`. Dentro está `app-debug.apk`.

El workflow instala Java 17, Gradle 8.13 y Android SDK 36. No necesita secretos ni credenciales.

## Compilar localmente

- Instala Android Studio con JDK 17 y Android SDK Platform 36.
- Abre la carpeta raíz que contiene `settings.gradle.kts`.
- Deja que Android Studio sincronice las dependencias y selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Alternativamente, si tienes Gradle 8.13 instalado, ejecuta `gradle assembleDebug` desde la raíz.

## Prueba de campo sugerida

1. Instala el APK debug en dos teléfonos Android con Bluetooth activado y permisos concedidos.
2. Configura apodos distintos en Ajustes.
3. Deja ẞetaChat abierto en ambos y verifica que cada dispositivo aparece en Personas.
4. Envía mensajes en ambos sentidos y verifica que sobreviven a cerrar/abrir la pantalla de chat.
5. Añade un tercer teléfono entre los dos extremos y prueba la retransmisión con los dispositivos fuera de alcance directo.
6. Repite con pantalla apagada, ahorro de batería y reinicio de la app; anota modelo, versión de Android, conexión y tiempo de entrega.

No declares la app lista para producción hasta completar esas pruebas y una auditoría de seguridad independiente.

## Estructura

```text
app/src/main/java/com/betastudio/betachat/
├── MainActivity.kt             # UI Compose y permisos
├── ChatViewModel.kt            # estado y operaciones de chat
├── data/ChatDatabase.kt        # Room: conversaciones y mensajes
├── network/MeshBleService.kt   # BLE GATT, protocolo, retransmisión
└── security/IdentityCrypto.kt  # ECDH, AES-GCM y firmas ECDSA
.github/workflows/android.yml  # compilación automática
```

## Licencia

El proyecto no declara una licencia de redistribución. Añade una licencia explícita antes de publicar o aceptar contribuciones públicas.
