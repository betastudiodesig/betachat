# ẞetaChat — híbrido SMS + Bluetooth Mesh

Proyecto Android nativo con Kotlin y Jetpack Compose. Conserva la dirección visual oscura con acento naranja y añade perfiles, descubrimiento BLE, solicitudes de conversación, selección de transporte, mensajería SMS y controles de privacidad. Está preparado para subirlo a GitHub y compilar un APK de depuración mediante GitHub Actions.

> **Estado: alpha experimental (0.2.0-hybrid).** El código de Android está preparado para la compilación en Actions, pero no se pudo ejecutar aquí una compilación Gradle real porque el entorno disponible no incluye Android SDK/Gradle ni puede descargar dependencias. El APK de GitHub será la primera comprobación de compilación; después es necesario probarlo en teléfonos reales. No es una versión certificada para producción.

## Funciones incorporadas

- Bienvenida con explicación del funcionamiento, creación de perfil, apodo, biografía, foto local y opción de número público/privado.
- Descubrimiento local de perfiles firmados por Bluetooth LE. Los anuncios de descubrimiento no se retransmiten a terceros; el número solo aparece en el paquete local cuando el propietario lo publica.
- Solicitudes de chat con aceptación o rechazo explícitos. Los mensajes Mesh se bloquean hasta que la solicitud sea aceptada en ambos lados.
- Identidad local mediante ECDSA, acuerdo de claves ECDH, cifrado AES-GCM y claves privadas protegidas con Android Keystore. El protocolo todavía requiere auditoría independiente.
- Rutas **Automática**, **SMS** y **ẞeta Mesh**. Cada mensaje almacena su transporte real y muestra un estado diferenciado.
- La ruta automática usa Mesh para una conversación aceptada cuando el usuario aparece cercano; en caso contrario utiliza SMS si se conoce el número y existen permisos/servicio móvil. No se cambia de transporte silenciosamente después de un fallo.
- Envío y recepción de SMS de texto, informes de envío de Android, historial local y notificaciones. Si un número público se vinculó previamente a una identidad ẞeta, los SMS entrantes pueden aparecer en la conversación existente.
- Gestos: deslizar horizontalmente para cambiar pestañas, deslizar una fila de chat para alternar la ruta, pulsación larga en un chat para abrirlo y pulsación larga en un mensaje para copiarlo. Transiciones entre páginas y animación de la navegación inferior.
- Base Room con migración desde el esquema anterior para añadir ruta, número destinatario y transporte de mensajes.
- Workflows GitHub Actions: `compilar-apk.yml` extrae `BetaChat-GitHub-Project.zip` y publica `BetaChat-Android-APK`; `android.yml` compila el proyecto si se sube su contenido a la raíz del repositorio.

## Limitaciones importantes

- **SMS no tiene cifrado de extremo a extremo** en esta implementación. El SMS pasa por la red móvil del operador y puede tener cargos. La aplicación no verifica que el número introducido o publicado pertenezca realmente a esa persona.
- **La cobertura Bluetooth y la entrega Mesh no están garantizadas.** Un dispositivo cercano debe ejecutar ẞetaChat, permitir Bluetooth y disponer de permisos. La retransmisión multi-salto y el comportamiento en segundo plano necesitan pruebas reales en varios teléfonos Android.
- La conversación Mesh no se convierte automáticamente a SMS al perder alcance. La ruta se puede cambiar explícitamente para evitar mensajes duplicados o revelar el número sin consentimiento.
- Si un usuario tiene el número privado, otros perfiles no lo reciben en el descubrimiento. Para escribirle por SMS será necesario que el propietario comparta el número por separado. Hacer público el número lo expone a los usuarios cercanos que reciban el perfil.
- El envío de SMS requiere el permiso de Android y servicio móvil. La recepción se integra con los broadcasts de SMS; el manejo de mensajes puede variar por versión del sistema y fabricante.
- **MMS, RCS, llamadas, adjuntos, mensajes de voz, grupos, importación del historial SMS previo y sincronización remota no están implementados.** La UI advierte que no se debe seleccionar ẞetaChat como aplicación SMS predeterminada si se necesita MMS completo. No se incluye decodificación de MMS.
- Las fotos de perfil se guardan localmente; todavía no se transfieren a perfiles cercanos.
- Los apodos, bloqueos, anti-spam, revocación/cambio de claves y protocolo de descubrimiento aún necesitan endurecimiento. No utilices esta alpha para información sensible ni la presentes como un mensajero auditado.
- La pestaña “Llamadas” es informativa y no hace llamadas.

## Compilar en GitHub con el ZIP

1. En la raíz del repositorio de GitHub debe existir el workflow `.github/workflows/compilar-apk.yml`.
2. Sube el ZIP con el nombre exacto **`BetaChat-GitHub-Project.zip`** a la raíz del repositorio. El workflow espera que dentro del ZIP exista `BetachatProject/settings.gradle.kts`.
3. Abre **Actions** y entra en **Compilar BetaChat Android APK**. También puedes ejecutarlo con **Run workflow**.
4. Si la ejecución termina correctamente, descarga el artefacto **`BetaChat-Android-APK`**. Dentro estará `app-debug.apk`.
5. Si Actions informa de un error, abre el registro de **Compilar APK debug** y utiliza el primer error real de Gradle/Kotlin para corregirlo. No se puede garantizar compilación hasta que ese workflow termine correctamente.

Si prefieres compilar desde la raíz del proyecto expandido, `android.yml` compila al hacer push a `main`/`master`, pull request o ejecución manual. Ambos workflows necesitan Java 17, Gradle 8.13 y Android SDK Platform 36; Actions los configura automáticamente.

## Plan de prueba básico

1. Instala el APK debug en dos teléfonos Android. Configura perfiles distintos y deja Bluetooth y los permisos requeridos activos.
2. Comprueba que se ven en Personas, publica el número solo en un perfil y verifica que el otro lo ve únicamente en ese caso.
3. Envía una solicitud. Comprueba rechazo y aceptación en ambos lados, y que no se pueda enviar un mensaje Mesh antes de aceptar.
4. Con ambos dispositivos cercanos, selecciona Mesh y comprueba envío, recepción y confirmación.
5. Con servicio móvil, prueba SMS con la ruta SMS y confirma que el estado indica envío, no lectura.
6. Vuelve a probar con datos móviles/Wi-Fi desactivados, pero con servicio de telefonía disponible; después prueba sin servicio móvil y con Bluetooth cercano.
7. Prueba cerrar y reabrir la app, permisos denegados, ahorro de batería y recepción de SMS con la pantalla apagada.
8. Antes de un uso real, completa pruebas de seguridad, manejo de bloqueo/spam, duplicados, reconexión y una auditoría independiente.

## Estructura

```text
BetachatProject/
├── app/src/main/AndroidManifest.xml
├── app/src/main/java/com/betastudio/betachat/
│   ├── MainActivity.kt
│   ├── ChatViewModel.kt
│   ├── data/ChatDatabase.kt
│   ├── network/MeshBleService.kt
│   ├── network/SmsReceiver.kt
│   ├── network/SmsStatusReceiver.kt
│   ├── network/SmsRespondViaMessageService.kt
│   ├── network/WapPushReceiver.kt
│   └── security/IdentityCrypto.kt
└── .github/workflows/
    ├── android.yml
    └── compilar-apk.yml
```


## Diagnóstico de cierres en la compilación profile-fix

- La finalización del onboarding ahora usa `SharedPreferences.commit()` y solo cambia a la pantalla principal si el guardado devuelve éxito. Se bloquean los dobles toques durante la transición.
- `BetaChatApplication` registra la excepción no capturada y su stack trace en el archivo privado `files/last_crash.txt`; también escribe el error en Logcat con la etiqueta `BetaChat/Crash`. El registro no incluye intencionadamente mensajes ni datos del perfil.
- `MeshBleService` registra excepciones de inicialización, comandos y promoción a servicio en primer plano bajo `BetaChat/BLE` en vez de descartarlas silenciosamente.
- Estos cambios mejoran la persistencia y la captura de evidencia, pero **no demuestran por sí solos la causa original del cierre**. Hace falta reproducirlo en el teléfono y revisar el stack trace.

### Capturar evidencia con ADB

Conecta el teléfono con depuración USB autorizada y ejecuta:

```bash
adb logcat -c
adb shell am force-stop com.betastudio.betachat
adb shell monkey -p com.betastudio.betachat 1
adb logcat -v threadtime -s BetaChat/Crash BetaChat/BLE AndroidRuntime
```

Repite el onboarding y guarda toda la salida, especialmente `FATAL EXCEPTION`, `Caused by` y las primeras líneas que señalen archivos del proyecto. Para exportar Logcat completo:

```bash
adb logcat -d -v threadtime > betachat-logcat.txt
```

El archivo privado `last_crash.txt` puede extraerse con `adb shell run-as com.betastudio.betachat cat files/last_crash.txt` en una compilación debug instalable. No publiques registros sin revisar que no contengan información personal del sistema.
