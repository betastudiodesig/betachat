# Auditoría técnica estática — ẞetaChat Bluetooth-only 0.3.0

## Alcance

Se tomó `BetaChat-ProfileFix-PermissionSafe.zip` como base y se revisaron y modificaron el manifiesto, la navegación Compose, el ViewModel, las entidades Room, el servicio BLE, la identidad criptográfica, el proveedor seguro de archivos y los workflows de compilación. Esta es una auditoría estática de la revisión; no equivale a una prueba de ejecución.

## Cambios en esta revisión

- Eliminadas declaraciones SMS/MMS, receptores, servicios, ruta de transporte SMS y solicitudes de permiso SMS. Los archivos de componentes SMS heredados se eliminaron del árbol fuente.
- El manifiesto contiene permisos Bluetooth y de notificación/servicio necesarios para BLE, pero no permisos READ_SMS/RECEIVE_SMS/SEND_SMS ni rol SMS. El onboarding no solicita ni inicia BLE por sí mismo.
- Añadida migración Room 2→3 para tipo de mensaje y metadatos de adjunto, normaliza rutas a `MESH` y elimina filas heredadas de conversaciones SMS. El valor por defecto de la entidad `route` se conserva como `AUTO` en el esquema para que coincida con el valor por defecto creado por la migración 1→2; los nuevos chats eligen `MESH` explícitamente.
- Mejorados insets de ventana e interpolación direccional de las transiciones entre pestañas; se revisó el gesto horizontal para avanzar/retroceder en el orden visual de pestañas.
- Añadido intercambio de foto de perfil reducida, biografía, número opcional de publicación y texto de estado con timestamp y caducidad lógica de 24 horas en el paquete HELLO firmado.
- Añadidos adjuntos de chat por bloques cifrados (límite 128 KiB), verificación SHA-256, validación del identificador UUID de transferencia, sanitización de nombre de archivo, tope del número de ensamblados y proveedor `FileProvider` de solo lectura para abrir archivos.
- Añadidos ACK de entrega y `MESSAGE_READ`; el mensaje local pasa a `delivered` al recibir ACK y a `read` al recibir confirmación de lectura. La UI muestra `✓`, `✓✓` o `✓✓✓` respectivamente. Desde la conversación se puede abrir la ficha pública guardada del interlocutor.
- Ajustado el búfer acotado de paquetes pendientes a 256 elementos para dejar margen a transferencias multimedia (la reanudación duradera de archivos no está implementada). Los textos pendientes se consultan desde Room y se reintentan tras volver a descubrir el contacto; los ACK duplicados se reenvían para recuperar recibos perdidos.
- Fortalecida la representación firmada de campos mediante prefijos de longitud UTF-8 para evitar ambigüedades si un campo incluye separadores; HELLO y controles usan `protocolVersion=3`, y chat/medios usan `cryptoVersion=3`.
- El cargador de adjuntos limita la lectura en streaming a 128 KiB para no leer un archivo gigantesco en memoria antes de comprobar el tamaño.
- Nueva versión declarada: `versionCode 4`, `versionName 0.3.0-bluetooth`.

## Seguridad criptográfica — limitaciones abiertas

La implementación usa ECDH P-256 de clave estática por identidad, una derivación HKDF-SHA-256 por paquete, AES-256-GCM con datos autenticados (AAD) y firmas ECDSA de sobres. Esto autentica mensajes y cifra el contenido contra relays que no tienen claves privadas de los extremos, en el diseño previsto. No obstante:

- no hay Double Ratchet ni prekeys efímeras de destinatario, por lo que **no hay forward secrecy**;
- no hay una auditoría independiente, análisis formal, ni pruebas de penetración;
- no hay verificación/rotación/revocación interactiva de claves;
- algunos metadatos (identificadores, tamaño, saltos, nombre y tipo de archivo, emisor/destinatario) siguen visibles para nodos BLE que reenvían paquetes; el contenido de los mensajes/fragmentos va cifrado;
- los estados de perfil se envían como información pública a dispositivos BLE cercanos, firmados pero no cifrados a un único contacto.

No debe anunciarse como equivalente a Signal/WhatsApp, ni como “imposible de descifrar”. Antes de producción, conviene integrar una implementación de protocolo revisada/auditada, definir un modelo de amenazas y probar la autenticación de claves.

## Limitaciones funcionales abiertas

- Los estados son solo texto; no hay foto/vídeo de estado, audiencia, recibos de visualización ni sincronización de estados fuera del alcance BLE.
- Adjuntos limitados a 128 KiB, sin recuperación/reanudación por fragmento ni progreso de transferencia.
- La red BLE puede perder mensajes o fragmentos. Los textos pendientes se guardan en Room y se reintentan al volver a descubrir al destinatario; las colas BLE son temporales y el envío de multimedia aún no tiene reanudación duradera.
- Ambos teléfonos deben ejecutar el mismo protocolo `cryptoVersion=3`.
- No se ejecutaron pruebas reales de BLE, ni pruebas de cifrado frente a intermediario, ni de disponibilidad entre fabricantes.

## Comprobaciones realizadas / no realizadas

Realizadas: lectura estática de fuentes y configuración; revisión de condiciones de autorización y permisos; coherencia del esquema Room/migraciones; inspección de los límites de tamaño de adjuntos, verificación de digest y exposición del proveedor de archivos.

No realizadas: compilación Gradle, pruebas unitarias/instrumentadas, instalación, prueba en dos teléfonos, validación del flujo BLE en segundo plano ni auditoría criptográfica. Este entorno no tiene Gradle ni Android SDK. Los workflows de GitHub Actions están preparados para generar la primera compilación de verificación.

## Cómo obtener un diagnóstico de compilación

Ejecuta el workflow **Build Android APK**. Si falla, adjunta el primer error `e:` o `Execution failed for task` completo, además de unas 20 líneas de contexto. Para fallos durante la ejecución en un teléfono, usa Logcat:

```bash
adb logcat -c
adb shell monkey -p com.betastudio.betachat 1
adb logcat -v threadtime -s BetaChat/Crash BetaChat/BLE AndroidRuntime
```
