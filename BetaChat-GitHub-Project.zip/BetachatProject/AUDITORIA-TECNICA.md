# Auditoría técnica de ẞetaChat — revisión estática

## Resultado y alcance

Se inspeccionó el contenido del ZIP original (42 entradas), incluyendo configuración Gradle, manifiesto, `MainActivity.kt`, `ChatViewModel.kt`, `ChatDatabase.kt`, `MeshBleService.kt`, `IdentityCrypto.kt` y workflows de GitHub Actions.

**No se pudo confirmar la causa raíz del cierre**: el paquete no incluye Logcat/stack trace y este entorno no dispone de Gradle, Android SDK ni wrapper `gradlew`. No se afirma que el proyecto haya compilado ni que se haya reproducido en un dispositivo.

## Evidencia y cambios

1. `MainActivity.kt`, flujo `BetaChatApp` / `onCreate` del onboarding: el perfil se marcaba como completado con `SharedPreferences.apply()` y se navegaba inmediatamente. Ahora se utiliza `commit()` y la navegación solo ocurre si la persistencia devuelve éxito; se evita completar dos veces por doble toque.
2. Nuevo `BetaChatApplication.kt`: registra las excepciones no capturadas y guarda el stack trace en almacenamiento privado (`files/last_crash.txt`), además de Logcat. No captura mensajes ni claves deliberadamente.
3. `network/MeshBleService.kt`: las excepciones que antes se descartaban en inicialización y arranque del servicio ahora se registran bajo `BetaChat/BLE` antes de cerrar el servicio de forma segura.
4. `AndroidManifest.xml`: registra la clase de aplicación para activar el diagnóstico.
5. `README.md`: añade instrucciones ADB/Logcat y recalca que el cierre debe reproducirse para confirmar su causa.

## Riesgos observados en la revisión estática

- El flujo inicial activa el servicio BLE después de completar el perfil y solicita permisos en el mismo flujo de composición. El servicio tiene varias protecciones, pero deben probarse en las versiones reales de Android/fabricantes.
- `ChatViewModel` obtiene el DAO de Room al inicializarse; cualquier excepción de apertura/migración de Room puede aparecer al iniciar la pantalla y debe comprobarse con stack trace.
- `ChatDatabase` tiene migración explícita 1→2. No se observó una estrategia de recuperación para bases dañadas o versiones de esquema desconocidas; no se añadió borrado destructivo automático para no perder historial.
- El manifiesto declara permisos SMS y componentes de elegibilidad SMS/MMS. La funcionalidad SMS debe revisarse con los requisitos actuales de Google Play si se distribuye por Play Store; no se desactivaron funciones legítimas automáticamente.
- El servicio BLE todavía contiene capturas de excepciones para tolerar callbacks/APIs de fabricantes. Este cambio instrumenta los puntos críticos principales, pero no sustituye una auditoría completa de cada callback.
- Las fotos se guardan en almacenamiento privado como JPEG; el código de decodificación existente no aplica explícitamente orientación EXIF. Debe validarse con fotos de distintas cámaras antes de considerar la fase de imágenes cerrada.

## Validación realizada

- Inventario y lectura estática de archivos fuente y configuración.
- Comprobación sintáctica XML del manifiesto y verificación de integridad del ZIP final.
- No se ejecutó compilación Gradle, pruebas unitarias, instalación ni pruebas físicas: no hay `gradle`, `kotlinc`, Android SDK ni `gradlew` en este entorno.
